package com.albaqiyat.app;

import android.app.Notification;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

/** خدمة أمامية خفيفة تحمل إشعار «الصلاة القادمة» الدائم.
 *  لا تستهلك المعالج (لا مؤقتات ولا قفل إيقاظ)؛ العدّ التنازلي يرسمه النظام،
 *  ووجودها يمنع نظام توفير الطاقة من إيقاف التطبيق وحذف منبّهات الأذان وإشعاره. */
public class StatusService extends Service {
    static volatile boolean running = false;

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Notification n = StatusNotice.build(this);
        if (n == null) { running = false; stopSelf(); return START_NOT_STICKY; }
        try {
            if (Build.VERSION.SDK_INT >= 34) startForeground(StatusNotice.NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            else startForeground(StatusNotice.NID, n);
            running = true;
        } catch (Exception e) {
            running = false;
            stopSelf();
            return START_NOT_STICKY;
        }
        // إعادة الجدولة احتياطاً كلما أعاد النظام تشغيل الخدمة بعد إيقافها
        if (intent == null) { try { AlarmScheduler.scheduleAll(this); } catch (Exception ignored) {} }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        super.onDestroy();
    }
}
