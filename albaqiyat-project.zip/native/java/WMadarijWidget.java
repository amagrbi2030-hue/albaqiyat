package com.albaqiyat.app;

public class WMadarijWidget extends BaseWidget {
    @Override
    protected String kind() { return "madarij"; }
}
