package com.albaqiyat.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import org.json.JSONObject;

/** يستقبل منبّه وقت الصلاة، وكذلك إعادة تشغيل الهاتف أو تغيير الوقت لإعادة الجدولة */
public class AdhanReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent in) {
        String a = in.getAction();
        if (a == null || !AlarmScheduler.ACTION_ADHAN.equals(a)) {
            AlarmScheduler.scheduleAll(c);
            WidgetHub.updateAll(c);
            return;
        }
        // قفل إيقاظ قصير حتى يبدأ تشغيل الأذان حتى لو كان الهاتف في سكون عميق
        try {
            android.os.PowerManager pm = (android.os.PowerManager) c.getSystemService(Context.POWER_SERVICE);
            if (pm != null) pm.newWakeLock(android.os.PowerManager.PARTIAL_WAKE_LOCK, "albaqiyat:adhan").acquire(15000);
        } catch (Exception ignored) {}
        try { WidgetHub.updateAll(c); } catch (Exception ignored) {}
        JSONObject ev = AlarmScheduler.find(c, in.getIntExtra("id", -1));
        if (ev == null) return;
        String kind = ev.optString("kind", "adhan");
        if ("pre".equals(kind)) IqamaNotice.postPre(c, ev);  // المتبقي للأذان
        else if ("adhan".equals(kind)) { IqamaNotice.cancel(c, IqamaNotice.NID_PRE); IqamaNotice.post(c, ev); } // المتبقي للإقامة
        else if ("iqama".equals(kind)) IqamaNotice.cancel(c);
        if (AlarmScheduler.prefs(c).getBoolean("muted", false)) return; // كتم من زر الودجت
        if (System.currentTimeMillis() - ev.optLong("at", 0) > 20 * 60 * 1000L) return;
        Intent s = new Intent(c, AdhanService.class);
        s.putExtra("ev", ev.toString());
        try {
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(s);
            else c.startService(s);
        } catch (Exception ignored) {}
    }
}
