package com.albaqiyat.app;

import android.content.SharedPreferences;
import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(AdhanPlugin.class);
        super.onCreate(savedInstanceState);
        // عند تثبيت نسخة جديدة من التطبيق: مسح أي نسخة قديمة محفوظة من الواجهة حتى تظهر التعديلات فوراً
        try {
            long installed = getPackageManager().getPackageInfo(getPackageName(), 0).lastUpdateTime;
            SharedPreferences p = getSharedPreferences("app_meta", MODE_PRIVATE);
            if (p.getLong("last_update", 0) != installed) {
                p.edit().putLong("last_update", installed).apply();
                if (getBridge() != null && getBridge().getWebView() != null) {
                    getBridge().getWebView().clearCache(true);
                    getBridge().getWebView().reload();
                }
            }
        } catch (Exception ignored) {}
    }
}
