package com.albaqiyat.app;

import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import java.util.Calendar;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * ويدجت «فوائد ابن القيم» و«مدارج السالكين»: نص اليوم يُقرأ من بيانات الويدجت التي يكتبها التطبيق
 * (days[].faw / days[].mad) — نفس اختيار بطاقات الصفحة الرئيسية، ويتجدد تلقائياً كل يوم.
 * الخلفية والألوان والخط والحجم من خصائص هذا الشكل وحده في «نظام المظاهر».
 */
final class WQuoteArt {
    private WQuoteArt() {}

    /** نص اليوم: يختار يوم البيانات الذي يوافق تاريخ اليوم (من وقت الفجر المخزّن) */
    static JSONObject today(Context c, String key) {
        try {
            JSONObject w = new JSONObject(AlarmScheduler.prefs(c).getString("widget", "{}"));
            JSONArray days = w.optJSONArray("days");
            if (days == null || days.length() == 0) return null;
            Calendar now = Calendar.getInstance();
            for (int d = 0; d < days.length(); d++) {
                JSONObject dd = days.optJSONObject(d);
                if (dd == null) continue;
                JSONArray it = dd.optJSONArray("items");
                long at = 0;
                if (it != null) for (int i = 0; i < it.length() && at == 0; i++) { JSONObject o = it.optJSONObject(i); if (o != null) at = o.optLong("at", 0); }
                if (at <= 0) continue;
                Calendar x = Calendar.getInstance(); x.setTimeInMillis(at);
                if (x.get(Calendar.YEAR) == now.get(Calendar.YEAR) && x.get(Calendar.DAY_OF_YEAR) == now.get(Calendar.DAY_OF_YEAR)) {
                    JSONObject q = dd.optJSONObject(key); if (q != null) return q;
                }
            }
            JSONObject d0 = days.optJSONObject(0);
            return d0 == null ? null : d0.optJSONObject(key);
        } catch (Exception e) { return null; }
    }

    static String desc(Context c, String kind) {
        JSONObject q = today(c, "madarij".equals(kind) ? "mad" : "faw");
        String h = q == null ? "" : q.optString("h", ""), t = q == null ? "افتح التطبيق مرة لتحميل نص اليوم" : q.optString("t", "");
        return ("madarij".equals(kind) ? "مدارج السالكين: " : "فائدة من كتاب الفوائد: ") + (h.isEmpty() ? "" : h + " — ") + t;
    }

    static Bitmap render(Context c, Bundle o, WidgetModel m, String kind) {
        boolean mad = "madarij".equals(kind);
        Bitmap b = WidgetHub.plainBg(c, o, 320, 160, m, WidgetArt.THEME);
        Canvas cv = new Canvas(b);
        int wdp = o == null ? 0 : o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0);
        if (wdp <= 0) wdp = 320;
        float k = b.getWidth() / (float) wdp, W = b.getWidth(), H = b.getHeight();
        float pad = Math.max(12 * k, (m.sk ? m.pad : 14) * k);
        int TX = m.sk ? m.text : 0xFFFFFFFF, T2 = m.sk ? m.text2 : 0xC8FFFFFF, AC = m.sk ? m.accent : WidgetArt.mix(m.gold, 0xFFFFFFFF, .15f);
        float fsz = m.sk ? m.fsize : 1f;
        JSONObject q = today(c, mad ? "mad" : "faw");
        String head = q == null ? "" : q.optString("h", "");
        String body = q == null ? "افتح التطبيق مرة واحدة ليُحمَّل نص اليوم" : q.optString("t", "");
        int idx = q == null ? -1 : q.optInt("i", -1), n = q == null ? 0 : q.optInt("n", 0);
        WNotchArt.text(cv, c, m, mad ? "من «مدارج السالكين»" : "من «الفوائد» لابن القيم", W - pad, pad + 7 * k, 10.5f * k, T2, WNotchArt.RIGHT, false, W * .62f);
        if (idx >= 0 && n > 0) WNotchArt.text(cv, c, m, (idx + 1) + " / " + n, pad, pad + 7 * k, 10.5f * k, T2, WNotchArt.LEFT, false, W * .3f);
        float top = pad + 18 * k;
        // العنوان (لمدارج السالكين) بخط أميري
        if (!head.isEmpty()) {
            Paint hp = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
            Typeface amiri = null;
            try { if (Build.VERSION.SDK_INT >= 26) amiri = c.getResources().getFont(c.getResources().getIdentifier("amiri_bold", "font", c.getPackageName())); } catch (Throwable ignored) {}
            hp.setTypeface(amiri != null ? amiri : Typeface.SERIF);
            float hs = Math.min(H * .14f, 19 * k) * fsz;
            hp.setTextSize(hs);
            while (hs > 8 && hp.measureText(head) > W - pad * 2) { hs *= .93f; hp.setTextSize(hs); }
            hp.setColor(AC); hp.setTextAlign(Paint.Align.CENTER);
            if (m.sk && m.tshadow) hp.setShadowLayer(hs * .15f, 0, hs * .05f, 0x88000000);
            Paint.FontMetrics fm = hp.getFontMetrics();
            float hy = top + hs * .7f;
            cv.drawText(head, W / 2f, hy - (fm.ascent + fm.descent) / 2f, hp);
            top = hy + hs * .75f;
        } else {
            Paint lp = new Paint(Paint.ANTI_ALIAS_FLAG);
            lp.setColor(WSkinArt.alpha(AC, 0x99)); lp.setStrokeWidth(Math.max(1f, k)); lp.setStrokeCap(Paint.Cap.ROUND);
            float ly = top;
            cv.drawLine(W / 2f - 22 * k, ly, W / 2f + 22 * k, ly, lp);
            top = ly + 6 * k;
        }
        // النص: تصغير تلقائي حتى يتسع، ثم قصّ بعلامة … إن طال جداً
        float src = 10 * k * fsz;
        float bot = H - pad * .7f - src * 1.4f, avail = bot - top, maxW = W - pad * 2;
        Paint mp = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
        mp.setTypeface(WNotchArt.face(c, m));
        float ms = 13.5f * k * fsz;
        List<String> lines;
        while (true) {
            mp.setTextSize(ms);
            lines = WAsmaArt.wrap(mp, body, maxW);
            if (lines.size() * ms * 1.4f <= avail || ms < 8 * k) break;
            ms *= .94f;
        }
        int maxL = Math.max(1, (int) (avail / (ms * 1.4f)));
        if (lines.size() > maxL) {
            lines = lines.subList(0, maxL);
            String last = lines.get(maxL - 1);
            while (last.length() > 1 && mp.measureText(last + " …") > maxW) last = last.substring(0, last.lastIndexOf(' ') > 0 ? last.lastIndexOf(' ') : last.length() - 1);
            lines.set(maxL - 1, last + " …");
        }
        mp.setColor(TX); mp.setTextAlign(Paint.Align.CENTER);
        if (m.sk && m.tshadow) mp.setShadowLayer(ms * .2f, 0, ms * .06f, 0x88000000);
        Paint.FontMetrics f2 = mp.getFontMetrics();
        float y = top + (avail - lines.size() * ms * 1.4f) / 2f + ms * 1.4f / 2f;
        for (String l : lines) { cv.drawText(l, W / 2f, y - (f2.ascent + f2.descent) / 2f, mp); y += ms * 1.4f; }
        WNotchArt.text(cv, c, m, mad ? "ابن القيم — مدارج السالكين" : "ابن القيم — الفوائد", W / 2f, H - pad * .7f - src * .5f, src, T2, WNotchArt.CENTER, false, W * .8f);
        return b;
    }
}
