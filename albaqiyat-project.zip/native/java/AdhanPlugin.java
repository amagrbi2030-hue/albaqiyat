package com.albaqiyat.app;

import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;
import com.getcapacitor.JSArray;
import org.json.JSONArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import org.json.JSONObject;

/** جسر بين التطبيق ونظام أندرويد: جدولة الأذان، الودجت، الأذونات */
@CapacitorPlugin(name = "Adhan")
public class AdhanPlugin extends Plugin {
    static final int TEST_ID = 999990;

    /** تجربة حقيقية: منبّه فعلي بعد عدة دقائق بنفس طريقة الأذان (لاختبار وضع الطيران والشاشة مقفلة) */
    @PluginMethod
    public void testLater(PluginCall call) {
        Context c = getContext();
        try {
            JSONObject ev = new JSONObject(call.getData().toString());
            long at = System.currentTimeMillis() + call.getInt("minutes", 2) * 60000L;
            ev.put("id", TEST_ID);
            ev.put("at", at);
            if (!ev.has("kind")) ev.put("kind", "adhan");
            AlarmScheduler.prefs(c).edit().putString("test_ev", ev.toString()).commit();
            // السماح بتكرار التجربة
            JSONArray f = new JSONArray(AlarmScheduler.prefs(c).getString("fired", "[]"));
            JSONArray out = new JSONArray();
            for (int i = 0; i < f.length(); i++) if (f.optInt(i) != TEST_ID) out.put(f.optInt(i));
            AlarmScheduler.prefs(c).edit().putString("fired", out.toString()).commit();
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            boolean exact = AlarmScheduler.canExact(c);
            String m = AlarmScheduler.setEventAlarm(c, am, at, AlarmScheduler.pi(c, TEST_ID), exact);
            try { AlarmScheduler.setAlarm(am, at, AlarmScheduler.piBackup(c, TEST_ID), exact); } catch (Exception ignored) {}
            JSObject r = new JSObject();
            r.put("at", at);
            r.put("method", m);
            call.resolve(r);
        } catch (Exception ex) {
            call.reject(String.valueOf(ex.getMessage()));
        }
    }

    @PluginMethod
    public void schedule(PluginCall call) {
        Context c = getContext();
        JSArray ev = call.getArray("events");
        JSObject w = call.getObject("widget");
        android.content.SharedPreferences.Editor e = AlarmScheduler.prefs(c).edit();
        e.putString("events", ev != null ? ev.toString() : "[]");
        if (w != null) e.putString("widget", w.toString());
        e.commit();
        int n = AlarmScheduler.scheduleAll(c);
        WidgetHub.updateAll(c);
        JSObject r = new JSObject();
        r.put("count", n);
        r.put("exact", AlarmScheduler.canExact(c));
        call.resolve(r);
    }

    @PluginMethod
    public void status(PluginCall call) {
        Context c = getContext();
        JSObject r = new JSObject();
        r.put("exact", AlarmScheduler.canExact(c));
        boolean fs = true;
        if (Build.VERSION.SDK_INT >= 34) {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            fs = nm != null && nm.canUseFullScreenIntent();
        }
        r.put("fullScreen", fs);
        r.put("overlay", Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(c));
        boolean bat = true;
        if (Build.VERSION.SDK_INT >= 23) {
            PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
            bat = pm != null && pm.isIgnoringBatteryOptimizations(c.getPackageName());
        }
        r.put("battery", bat);
        r.put("playing", AdhanService.isPlaying());
        r.put("method", AlarmScheduler.prefs(c).getString("method", ""));
        r.put("brand", Build.MANUFACTURER == null ? "" : Build.MANUFACTURER.toLowerCase());
        r.put("statusService", StatusService.running);
        r.put("log", AlarmScheduler.prefs(c).getString("log", "[]"));
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am != null && Build.VERSION.SDK_INT >= 21) {
            AlarmManager.AlarmClockInfo ni = am.getNextAlarmClock();
            r.put("nextClock", ni != null ? ni.getTriggerTime() : 0);
        }
        call.resolve(r);
    }

    @PluginMethod
    public void openSettings(PluginCall call) {
        Context c = getContext();
        String which = call.getString("which", "");
        Uri pkg = Uri.parse("package:" + c.getPackageName());
        Intent i = null;
        if ("exact".equals(which) && Build.VERSION.SDK_INT >= 31) i = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, pkg);
        else if ("fullscreen".equals(which) && Build.VERSION.SDK_INT >= 34) i = new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, pkg);
        else if ("overlay".equals(which) && Build.VERSION.SDK_INT >= 23) i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkg);
        else if ("battery".equals(which) && Build.VERSION.SDK_INT >= 23) i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkg);
        if ("autostart".equals(which)) {
            // إدارة تشغيل التطبيقات في هونر/هواوي وغيرها (لا يوجد إعداد موحّد في أندرويد)
            String[][] comps = {
                {"com.hihonor.systemmanager", "com.hihonor.systemmanager.startupmgr.ui.StartupNormalAppListActivity"},
                {"com.hihonor.systemmanager", "com.hihonor.systemmanager.optimize.process.ProtectActivity"},
                {"com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"},
                {"com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity"},
                {"com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"},
                {"com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"},
                {"com.oplus.battery", "com.oplus.powermanager.fuelgaue.PowerUsageModelActivity"},
                {"com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"},
                {"com.samsung.android.lool", "com.samsung.android.sm.battery.ui.BatteryActivity"}
            };
            for (String[] cp : comps) {
                Intent t = new Intent();
                t.setComponent(new android.content.ComponentName(cp[0], cp[1]));
                t.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                try { c.startActivity(t); call.resolve(); return; } catch (Exception ignored) {}
            }
        }
        if (i == null) i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            c.startActivity(i);
        } catch (Exception ex) {
            try {
                Intent d = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg);
                d.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                c.startActivity(d);
            } catch (Exception ignored) {}
        }
        call.resolve();
    }

    @PluginMethod
    public void stop(PluginCall call) {
        try {
            Intent s = new Intent(getContext(), AdhanService.class);
            s.setAction("STOP");
            getContext().startService(s);
        } catch (Exception ignored) {}
        call.resolve();
    }

    /** تجربة شاشة الأذان بعد ثوانٍ (لاختبار الصوت والشاشة) */
    @PluginMethod
    public void test(PluginCall call) {
        Context c = getContext();
        try {
            JSONObject ev = new JSONObject();
            long at = System.currentTimeMillis() + call.getInt("delay", 5) * 1000L;
            ev.put("id", 999999);
            ev.put("at", at);
            ev.put("kind", call.getString("kind", "adhan"));
            ev.put("prayer", call.getString("prayer", "fajr"));
            ev.put("name", call.getString("name", "الفجر"));
            ev.put("title", call.getString("title", "تجربة شاشة الأذان"));
            ev.put("body", call.getString("body", ""));
            ev.put("sound", call.getString("sound", "adhan_m1"));
            ev.put("time", call.getString("time", ""));
            ev.put("city", call.getString("city", ""));
            ev.put("who", call.getString("who", ""));
            ev.put("fadl", call.getString("fadl", ""));
            ev.put("iq", call.getDouble("iq", 0.0).longValue());
            ev.put("iqs", call.getString("iqs", ""));
            ev.put("fsrc", call.getString("fsrc", ""));
            ev.put("voice", call.getString("voice", "اقتربت الصلاة، الرجاء الاستعداد"));
            ev.put("adhanAt", call.getDouble("adhanAt", 0.0).longValue());
            ev.put("adhanS", call.getString("adhanS", ""));
            if ("adhan".equals(ev.optString("kind"))) IqamaNotice.post(c, ev);
            if ("pre".equals(ev.optString("kind"))) IqamaNotice.postPre(c, ev);
            Intent s = new Intent(c, AdhanService.class);
            s.putExtra("ev", ev.toString());
            // تشغيل فوري ما دام التطبيق مفتوحاً
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(s);
            else c.startService(s);
        } catch (Exception ex) {
            call.reject(ex.getMessage());
            return;
        }
        call.resolve();
    }
}
