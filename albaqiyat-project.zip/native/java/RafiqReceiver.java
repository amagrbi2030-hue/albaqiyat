package com.albaqiyat.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** منبّه الرفيق اليومي + أزرار الإشعار + إعادة الجدولة بعد إعادة التشغيل أو تغيير الوقت/المنطقة الزمنية */
public class RafiqReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent in) {
        String a = in.getAction();
        if (a == null) return;
        final PendingResult pr = goAsync();
        boolean async = false;
        try {
            if (RafiqEngine.A_FIRE.equals(a)) {
                try {
                    android.os.PowerManager pm = (android.os.PowerManager) c.getSystemService(Context.POWER_SERVICE);
                    if (pm != null) pm.newWakeLock(android.os.PowerManager.PARTIAL_WAKE_LOCK, "albaqiyat:rafiq").acquire(8000);
                } catch (Exception ignored) {}
                RafiqEngine.voice = null;
                RafiqEngine.fire(c);
                String say = RafiqEngine.voice;
                RafiqEngine.voice = null;
                if (say != null && !say.isEmpty()) {
                    // نُبقي المستقبِل حيّاً حتى ينتهي النطق (بحد أقصى ١٥ ثانية)
                    async = true;
                    RafiqVoice.speak(c, say, pr::finish);
                }
            } else if (RafiqEngine.A_DONE.equals(a)) {
                String occ = in.getStringExtra("occ");
                String src = in.getStringExtra("src");
                if (occ != null && !"test".equals(occ)) RafiqEngine.markDone(c, occ, src == null ? "notif" : src); else RafiqEngine.cancel(c, "test");
            } else if (RafiqWidgets.A_INC.equals(a)) {
                String occ = in.getStringExtra("occ");
                if (occ != null) RafiqWidgets.inc(c, occ, 1, "widget");
            } else if (RafiqWidgets.A_PICK.equals(a)) {
                RafiqWidgets.cyclePick(c, in.getIntExtra("wid", -1));
            } else if (RafiqWidgets.A_WREF.equals(a)) {
                RafiqWidgets.updateAll(c);
            } else if (RafiqEngine.A_SNOOZE.equals(a)) {
                String occ = in.getStringExtra("occ");
                if (occ != null && !"test".equals(occ)) RafiqEngine.snooze(c, occ, in.getStringExtra("title")); else RafiqEngine.cancel(c, "test");
            } else {
                // BOOT_COMPLETED / TIME_SET / TIMEZONE_CHANGED / MY_PACKAGE_REPLACED:
                // الأحداث مخزّنة بأوقات مطلقة؛ تُعاد جدولة الأقرب، والقديمة (>١٥ دقيقة) تُتجاهل ولا تُرسل.
                RafiqEngine.scheduleNext(c);
                RafiqWidgets.updateAll(c);
            }
        } finally {
            if (!async) pr.finish();
        }
    }
}
