package com.albaqiyat.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import org.json.JSONObject;

/** إشعار «اقترب خروج وقت الصلاة» قبل نهاية وقت الصلاة بعشر دقائق */
public class EndNotice {
    static final String CH = "prayer_end_v1";
    static final int NID = 4760;

    static void post(Context c, JSONObject ev) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(CH) == null) {
            NotificationChannel ch = new NotificationChannel(CH, "اقتراب خروج وقت الصلاة", NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("تنبيه قبل نهاية وقت الصلاة بعشر دقائق");
            ch.enableVibration(true);
            ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            nm.createNotificationChannel(ch);
        }
        Intent li = c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
        if (li == null) li = new Intent(c, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(c, 5, li, AlarmScheduler.piFlags());
        int icon = c.getResources().getIdentifier("ic_stat_salah", "drawable", c.getPackageName());
        if (icon == 0) icon = android.R.drawable.ic_lock_idle_alarm;
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, CH) : new Notification.Builder(c);
        b.setSmallIcon(icon)
                .setContentTitle(ev.optString("title", "اقترب خروج وقت الصلاة"))
                .setContentText(ev.optString("body", ""))
                .setStyle(new Notification.BigTextStyle().bigText(ev.optString("body", "")))
                .setColor(0xFFC69A3A)
                .setAutoCancel(true)
                .setCategory(Notification.CATEGORY_REMINDER)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setContentIntent(pi)
                .setTimeoutAfter(15 * 60 * 1000L);
        if (Build.VERSION.SDK_INT < 26) { b.setPriority(Notification.PRIORITY_HIGH); b.setDefaults(Notification.DEFAULT_ALL); }
        try { nm.notify(NID, b.build()); } catch (Exception ignored) {}
    }
}
