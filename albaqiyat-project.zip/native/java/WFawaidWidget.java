package com.albaqiyat.app;

public class WFawaidWidget extends BaseWidget {
    @Override
    protected String kind() { return "fawaid"; }
}
