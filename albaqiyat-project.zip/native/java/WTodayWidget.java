package com.albaqiyat.app;

public class WTodayWidget extends BaseWidget {
    @Override
    protected String kind() { return "today"; }
}
