package com.albaqiyat.app;

import android.content.Context;
import android.media.AudioAttributes;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import java.util.Locale;

/**
 * رسالة صوتية للرفيق اليومي عند خروج المهمة عن وقتها: «لقد تأخرت في إنجاز المهمة».
 * تُنطق بمحرّك النطق المثبّت في الهاتف (يعمل دون إنترنت إذا كانت العربية مثبّتة)،
 * مع اختيار صوت رجل إن توفّر، وإلا خفض طبقة الصوت ليقترب من صوت الرجل.
 */
final class RafiqVoice {
    private RafiqVoice() {}

    static void speak(Context ctx, String text, Runnable done) {
        final Context c = ctx.getApplicationContext();
        final Handler h = new Handler(Looper.getMainLooper());
        final boolean[] fin = {false};
        final TextToSpeech[] tts = {null};
        final Runnable finish = () -> {
            if (fin[0]) return;
            fin[0] = true;
            try { if (tts[0] != null) tts[0].shutdown(); } catch (Exception ignored) {}
            if (done != null) done.run();
        };
        h.postDelayed(finish, 15000);
        try {
            tts[0] = new TextToSpeech(c, status -> {
                if (status != TextToSpeech.SUCCESS) { finish.run(); return; }
                try {
                    TextToSpeech t = tts[0];
                    Locale ar = new Locale("ar");
                    t.setLanguage(ar);
                    Voice male = pickMale(t);
                    if (male != null) t.setVoice(male); else t.setPitch(0.78f);
                    t.setSpeechRate(0.92f);
                    t.setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());
                    t.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                        @Override public void onStart(String id) {}
                        @Override public void onDone(String id) { h.postDelayed(finish, 300); }
                        @Override public void onError(String id) { h.post(finish); }
                    });
                    Bundle b = new Bundle();
                    t.speak(text, TextToSpeech.QUEUE_FLUSH, b, "rafiq_late");
                } catch (Exception e) { finish.run(); }
            });
        } catch (Exception e) { finish.run(); }
    }

    /** صوت رجل عربي إن وُجد (أسماء أصوات Google وسامسونج وغيرها تختلف؛ نتحقق من الدلائل المعروفة) */
    static Voice pickMale(TextToSpeech t) {
        try {
            java.util.Set<Voice> vs = t.getVoices();
            if (vs == null) return null;
            Voice best = null;
            int bestScore = 0;
            for (Voice v : vs) {
                if (v == null || v.getLocale() == null || !"ar".equals(v.getLocale().getLanguage())) continue;
                String n = v.getName().toLowerCase(Locale.ROOT);
                int s = 0;
                if (n.contains("female") || n.contains("smtf") || n.contains("-arz-") || n.contains("-arc-")) continue;
                if (n.contains("male") || n.contains("smtm")) s = 5;
                else if (n.contains("-ard-") || n.contains("-are-")) s = 4;
                if (s > 0 && !v.isNetworkConnectionRequired()) s += 1;
                if (s > bestScore) { bestScore = s; best = v; }
            }
            return best;
        } catch (Exception e) { return null; }
    }
}
