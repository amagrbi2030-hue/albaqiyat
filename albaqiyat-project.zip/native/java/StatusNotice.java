package com.albaqiyat.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import org.json.JSONObject;

/** إشعار ثابت دائم في قائمة الإشعارات: الصلاة القادمة مع عدّ تنازلي،
 *  ويتحوّل تلقائياً إلى «الأذان بعد» قبل الوقت بعشر دقائق، ثم «الإقامة بعد» بعد الأذان. */
public class StatusNotice {
    static final String CH = "prayer_status_v1";
    static final int NID = 4750;
    static final long PRE = 10 * 60 * 1000L;

    /** يحدّث الإشعار الدائم. يعمل الإشعار ضمن «خدمة أمامية» حتى لا يحذفه نظام توفير الطاقة
     *  (هونر/هواوي وغيرها) عند وضع الطيران أو السكون العميق، وحتى يبقى التطبيق حيّاً لاستقبال الأذان. */
    static void update(Context c) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        Notification n = build(c);
        if (n == null) {
            nm.cancel(NID);
            try { c.stopService(new Intent(c, StatusService.class)); } catch (Exception ignored) {}
            return;
        }
        if (StatusService.running) {
            try { nm.notify(NID, n); } catch (Exception ignored) {}
            return;
        }
        try {
            Intent s = new Intent(c, StatusService.class);
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(s); else c.startService(s);
        } catch (Exception e) {
            // لا يُسمح ببدء الخدمة الآن (التطبيق في الخلفية) ← إشعار عادي، وتبدأ الخدمة عند أول فتح أو منبّه
            try { nm.notify(NID, n); } catch (Exception ignored) {}
        }
    }

    static Notification build(Context c) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return null;
        WidgetModel m = WidgetModel.load(c);
        if (!m.ok || m.next == null) return null;
        if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(CH) == null) {
            NotificationChannel ch = new NotificationChannel(CH, "الصلاة القادمة والعدّ التنازلي", NotificationManager.IMPORTANCE_DEFAULT);
            ch.setDescription("وقت الصلاة القادمة، والمتبقي للأذان قبل عشر دقائق، والمتبقي للإقامة");
            ch.setSound(null, null);
            ch.enableVibration(false);
            ch.setShowBadge(false);
            ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            nm.createNotificationChannel(ch);
        }
        long now = System.currentTimeMillis();
        String title, text;
        long target;
        JSONObject nx = m.next;
        String nn = nx.optString("name", "");
        if (m.iqPhase && m.cur != null) {
            String cn = m.cur.optString("name", "");
            target = m.cur.optLong("iq", 0);
            title = "⏱ الإقامة بعد — صلاة " + cn;
            text = "إقامة صلاة " + cn + " الساعة " + m.cur.optString("iqs", "") + "  •  ثم " + nn + " " + nx.optString("s", "");
        } else if (nx.optLong("at") - now <= PRE) {
            target = nx.optLong("at");
            title = "🕌 الأذان بعد — صلاة " + nn;
            text = "اقتربت الصلاة، الرجاء الاستعداد  •  الأذان " + nx.optString("s", "") + (nx.has("iqs") ? "  •  الإقامة " + nx.optString("iqs") : "");
        } else {
            target = nx.optLong("at");
            title = "🕌 الصلاة القادمة: " + nn + " " + nx.optString("s", "");
            text = (nx.has("iqs") ? "الإقامة " + nx.optString("iqs") + "  •  " : "") + m.city;
        }
        Intent li = c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
        if (li == null) li = new Intent(c, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(c, 4, li, AlarmScheduler.piFlags());
        int icon = c.getResources().getIdentifier("ic_stat_salah", "drawable", c.getPackageName());
        if (icon == 0) icon = android.R.drawable.ic_lock_idle_alarm;
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, CH) : new Notification.Builder(c);
        b.setSmallIcon(icon)
                .setContentTitle(title)
                .setContentText(text)
                .setColor(0xFFC69A3A)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setContentIntent(pi)
                .setWhen(target)
                .setShowWhen(true);
        if (Build.VERSION.SDK_INT >= 24) {
            b.setUsesChronometer(true);
            b.setChronometerCountDown(true);
        }
        if (Build.VERSION.SDK_INT < 26) b.setPriority(Notification.PRIORITY_DEFAULT);
        if (Build.VERSION.SDK_INT >= 31) b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        return b.build();
    }

    /** اللحظة التالية التي يتغيّر فيها الإشعار (قبل الأذان بعشر دقائق، الأذان، الإقامة) */
    static long nextChange(Context c) {
        WidgetModel m = WidgetModel.load(c);
        if (!m.ok || m.next == null) return 0;
        long now = System.currentTimeMillis();
        long best = Long.MAX_VALUE;
        long a = m.next.optLong("at");
        if (a - PRE > now) best = Math.min(best, a - PRE);
        if (a > now) best = Math.min(best, a);
        if (m.iqPhase && m.cur != null && m.cur.optLong("iq") > now) best = Math.min(best, m.cur.optLong("iq"));
        return best == Long.MAX_VALUE ? 0 : best;
    }
}
