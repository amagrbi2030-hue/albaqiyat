package com.albaqiyat.app;

import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.Bundle;

/** رسم خلفيات الودجت بألوان الثيم: تدرّج + زخرفة نجوم ثمانية شبه شفافة + هلال ذهبي رقيق */
public class WidgetArt {
    public static final int THEME = 0, GLASS = 1, SKY = 2, MINIMAL = 3, PHASE = 4, MIHRAB = 5, ROYAL = 6, SUN = 7;

    static int alpha(int c, int a) { return (c & 0x00FFFFFF) | (a << 24); }

    static int mix(int a, int b, float t) {
        int r = (int) (Color.red(a) + (Color.red(b) - Color.red(a)) * t);
        int g = (int) (Color.green(a) + (Color.green(b) - Color.green(a)) * t);
        int bl = (int) (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t);
        return Color.rgb(r, g, bl);
    }

    /** شفافية الخلفية حسب النمط: كلاسيكي (معتم) / زجاجي (شبه شفاف) / شفاف */
    static int lookAlpha(WidgetModel m) {
        if (m == null) return 0xFF;
        if ("glass".equals(m.look)) return 0xA6;
        if ("clear".equals(m.look)) return 0x48;
        return 0xFF;
    }

    static boolean classic(WidgetModel m) { return m == null || !( "glass".equals(m.look) || "clear".equals(m.look)); }

    /** تدرّج الألوان المختارة من المكتبة (لونان أو أكثر) — أو التدرّج الافتراضي */
    static Shader gradShader(WidgetModel m, float w, float h, Shader def, float darken) {
        if (m != null && m.grad != null && m.grad.length >= 2) {
            int[] g = new int[m.grad.length];
            for (int i = 0; i < g.length; i++) g[i] = darken > 0 ? mix(m.grad[i], 0xFF0A0C10, darken) : m.grad[i];
            return new LinearGradient(w, 0, 0, h, g, null, Shader.TileMode.CLAMP); // من أعلى اليمين (عربي)
        }
        return def;
    }

    /** يرسم الخلفية بالتظليل المعطى مع شفافية النمط */
    static void fillBase(Canvas cv, RectF rect, Paint p, WidgetModel m) {
        p.setAlpha(lookAlpha(m));
        cv.drawRect(rect, p);
        p.setAlpha(0xFF);
    }

    /** لمسات النمط الأخيرة: لمعة وإطار أبيض للزجاجي، إطار رقيق للشفاف */
    static void finishLook(Canvas cv, int w, int h, float rad, float k, WidgetModel m) {
        if (classic(m)) return;
        boolean glass = "glass".equals(m.look);
        if (glass) {
            Paint hi = new Paint(Paint.ANTI_ALIAS_FLAG);
            hi.setShader(new LinearGradient(0, 0, 0, h * 0.5f, 0x3AFFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
            cv.drawRect(0, 0, w, h, hi);
            Paint sh = new Paint(Paint.ANTI_ALIAS_FLAG);
            sh.setShader(new LinearGradient(w * 0.25f, 0, w * 0.6f, h, new int[]{0x00FFFFFF, 0x1CFFFFFF, 0x00FFFFFF}, new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
            cv.drawRect(0, 0, w, h, sh);
        }
        Paint bp = new Paint(Paint.ANTI_ALIAS_FLAG);
        bp.setStyle(Paint.Style.STROKE);
        bp.setStrokeWidth(Math.max(1f, (glass ? 1.4f : 1.1f) * k));
        bp.setColor(glass ? 0x8CFFFFFF : 0x66FFFFFF);
        float ins = bp.getStrokeWidth() / 2;
        cv.drawRoundRect(new RectF(ins, ins, w - ins, h - ins), rad - ins, rad - ins, bp);
    }

    static int[] sky(String k) {
        if ("fajr".equals(k)) return new int[]{0xFF1B2350, 0xFF6A4C7E};
        if ("dhuhr".equals(k)) return new int[]{0xFF1F5C8A, 0xFF4F8DB8};
        if ("asr".equals(k)) return new int[]{0xFF7A5222, 0xFFB98838};
        if ("maghrib".equals(k)) return new int[]{0xFF3A1E4A, 0xFFB0543C};
        return new int[]{0xFF07122A, 0xFF16304F};
    }

    /** زخرفة الخلفية حسب الاختيار: نجوم ثمانية، شبكة هندسية، دوائر متداخلة، أهلّة ونجوم، نقاط، أو بدون */
    static void ornament(Canvas cv, int w, int h, float k, WidgetModel m, int col, float stepDp) {
        String o = m == null ? "star" : m.orn;
        if ("none".equals(o)) return;
        Paint sp = new Paint(Paint.ANTI_ALIAS_FLAG);
        sp.setStyle(Paint.Style.STROKE);
        sp.setStrokeWidth(Math.max(1f, 1.05f * k));
        sp.setColor(col);
        float step = stepDp * k;
        if ("lattice".equals(o)) {
            for (float x = -h; x < w + h; x += step * 0.7f) { cv.drawLine(x, 0, x + h, h, sp); cv.drawLine(x + h, 0, x, h, sp); }
            return;
        }
        if ("circles".equals(o)) {
            float r = step * 0.5f;
            for (float y = 0; y < h + r; y += r) for (float x = 0; x < w + r; x += r) cv.drawCircle(x, y, r, sp);
            return;
        }
        if ("dots".equals(o)) {
            Paint dp = new Paint(Paint.ANTI_ALIAS_FLAG);
            dp.setColor(col);
            float s2 = step * 0.45f;
            for (float y = s2 / 2; y < h; y += s2) for (float x = s2 / 2; x < w; x += s2) cv.drawCircle(x, y, 1.3f * k, dp);
            return;
        }
        if ("crescent".equals(o)) {
            Paint fp = new Paint(Paint.ANTI_ALIAS_FLAG);
            fp.setColor(col);
            java.util.Random rnd = new java.util.Random(11);
            int n = (int) Math.max(8, (w * h) / (step * step) * 0.9f);
            for (int i = 0; i < n; i++) {
                float x = rnd.nextFloat() * w, y = rnd.nextFloat() * h, R = (4 + rnd.nextFloat() * 7) * k;
                if (i % 3 == 0) {
                    Path a = new Path(); a.addCircle(x, y, R, Path.Direction.CW);
                    Path b = new Path(); b.addCircle(x + R * 0.45f, y - R * 0.2f, R * 0.9f, Path.Direction.CW);
                    a.op(b, Path.Op.DIFFERENCE);
                    cv.drawPath(a, fp);
                } else cv.drawPath(star8(x, y, R * 0.55f), fp);
            }
            return;
        }
        for (float y = -step / 2; y < h + step; y += step)
            for (float x = (((int) (y / step)) % 2 == 0 ? 0 : step / 2); x < w + step; x += step)
                cv.drawPath(star8(x, y, step * 0.36f), sp);
    }

    static Path star8(float cx, float cy, float R) {
        Path p = new Path();
        float r = R * 0.72f;
        for (int i = 0; i < 16; i++) {
            double a = Math.PI / 8 * i - Math.PI / 2;
            float rad = i % 2 == 0 ? R : r;
            float x = (float) (cx + rad * Math.cos(a)), y = (float) (cy + rad * Math.sin(a));
            if (i == 0) p.moveTo(x, y); else p.lineTo(x, y);
        }
        p.close();
        return p;
    }

    static int[] phaseSky(String p) {
        if ("fajr".equals(p)) return new int[]{0xFF1B2452, 0xFF5B4A86, 0xFFD99A8C};
        if ("morning".equals(p)) return new int[]{0xFF3D7EC2, 0xFF7FB6E3, 0xFFF4D9A0};
        if ("dhuhr".equals(p)) return new int[]{0xFF1E6FB8, 0xFF4FA3DE, 0xFFA8D8F2};
        if ("sunset".equals(p)) return new int[]{0xFF3B2150, 0xFFB4513E, 0xFFF2A65A};
        return new int[]{0xFF050A1C, 0xFF0D1E3D, 0xFF1C3358};
    }

    /** خلفيات الويدجت الجديدة: سماء حسب الوقت، محراب، ملكي، شمس */
    public static Bitmap bg2(Context c, Bundle opts, int defWdp, int defHdp, int style, WidgetModel m) {
        float d = c.getResources().getDisplayMetrics().density;
        int wdp = 0, hdp = 0;
        if (opts != null) {
            wdp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0);
            hdp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0);
        }
        if (wdp <= 0) wdp = defWdp;
        if (hdp <= 0) hdp = defHdp;
        float scale = Math.min(1f, 900f / (Math.max(wdp, hdp) * d));
        float k = d * scale;
        int w = Math.max(40, (int) (wdp * k)), h = Math.max(40, (int) (hdp * k));
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        float rad = 24 * k;
        RectF rect = new RectF(0, 0, w, h);
        Path clip = new Path();
        clip.addRoundRect(rect, rad, rad, Path.Direction.CW);
        cv.clipPath(clip);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        int gold = m.gold;
        boolean night = "night".equals(m.phase);

        if (style == PHASE || style == SUN) {
            int[] sk = phaseSky(m.phase);
            p.setShader(new LinearGradient(0, 0, 0, h, sk, null, Shader.TileMode.CLAMP));
            fillBase(cv, rect, p, m);
            if (night) {
                Paint st = new Paint(Paint.ANTI_ALIAS_FLAG);
                java.util.Random rnd = new java.util.Random(7);
                for (int i = 0; i < 46; i++) {
                    st.setColor(alpha(0xFFFFFFFF, 60 + rnd.nextInt(140)));
                    cv.drawCircle(rnd.nextFloat() * w, rnd.nextFloat() * h * 0.75f, (0.6f + rnd.nextFloat() * 1.3f) * k, st);
                }
            }
        } else if (style == ROYAL) {
            if (m.grad != null) p.setShader(gradShader(m, w, h, null, 0f));
            else if (m.custom) p.setShader(new LinearGradient(0, 0, w, h, new int[]{mix(m.c2, 0xFF000000, 0.35f), m.c2, m.c1}, null, Shader.TileMode.CLAMP));
            else { p.setShader(new LinearGradient(0, 0, w, h, new int[]{0xFF06281B, 0xFF0B3A27, 0xFF125536}, null, Shader.TileMode.CLAMP)); gold = 0xFFD8B45A; }
            fillBase(cv, rect, p, m);
        } else { // MIHRAB
            p.setShader(gradShader(m, w, h, new LinearGradient(0, 0, w, h, mix(m.c2, 0xFF000000, 0.25f), m.c1, Shader.TileMode.CLAMP), 0f));
            fillBase(cv, rect, p, m);
        }

        // زخرفة نجوم ثمانية خافتة
        if (style == ROYAL || style == MIHRAB) ornament(cv, w, h, k, m, alpha(gold, 0x1A), 40);
        else if (!"star".equals(m.orn)) ornament(cv, w, h, k, m, alpha(0xFFFFFFFF, 0x12), 46);
        // توهّج
        Paint g = new Paint(Paint.ANTI_ALIAS_FLAG);
        g.setShader(new RadialGradient(w * 0.5f, h * 0.42f, Math.max(w, h) * 0.55f, alpha(night ? 0xFFFFFFFF : gold, night ? 0x10 : 0x2A), 0, Shader.TileMode.CLAMP));
        cv.drawRect(rect, g);

        if (style == MIHRAB) {
            // قوس المحراب المزدوج
            Paint ap = new Paint(Paint.ANTI_ALIAS_FLAG);
            ap.setStyle(Paint.Style.STROKE);
            ap.setStrokeWidth(Math.max(1.2f, 1.6f * k));
            ap.setColor(alpha(gold, 0xB0));
            for (int j = 0; j < 2; j++) {
                float in = (12 + j * 9) * k;
                float top = (20 + j * 9) * k;
                Path a = new Path();
                a.moveTo(in, h - in);
                a.lineTo(in, h * 0.42f);
                a.cubicTo(in, h * 0.2f, w * 0.38f, top + h * 0.06f, w / 2f, top);
                a.cubicTo(w * 0.62f, top + h * 0.06f, w - in, h * 0.2f, w - in, h * 0.42f);
                a.lineTo(w - in, h - in);
                if (j == 1) ap.setColor(alpha(gold, 0x55));
                cv.drawPath(a, ap);
            }
            Paint sf = new Paint(Paint.ANTI_ALIAS_FLAG);
            sf.setColor(alpha(gold, 0xC0));
            cv.drawPath(star8(w / 2f, 12 * k, 6 * k), sf);
        }

        if (style == ROYAL) {
            // هلال في الزاوية + إطار مزدوج
            float R = Math.min(w, h) * 0.13f;
            float cx = w - R * 1.6f, cy = R * 1.6f;
            Path a = new Path(); a.addCircle(cx, cy, R, Path.Direction.CW);
            Path bb = new Path(); bb.addCircle(cx - R * 0.42f, cy - R * 0.2f, R * 0.88f, Path.Direction.CW);
            a.op(bb, Path.Op.DIFFERENCE);
            Paint cp = new Paint(Paint.ANTI_ALIAS_FLAG);
            cp.setColor(alpha(gold, 0x99));
            cv.drawPath(a, cp);
            Paint ip = new Paint(Paint.ANTI_ALIAS_FLAG);
            ip.setStyle(Paint.Style.STROKE);
            ip.setStrokeWidth(Math.max(1f, 0.8f * k));
            ip.setColor(alpha(gold, 0x55));
            float ins2 = 7 * k;
            cv.drawRoundRect(new RectF(ins2, ins2, w - ins2, h - ins2), rad - ins2, rad - ins2, ip);
        }

        if (style == SUN) {
            // قوس الشمس من الشروق إلى الغروب
            float ax = 22 * k, ay = h * 0.62f, aw = w - 2 * ax, ah = h * 0.42f;
            RectF arc = new RectF(ax, ay - ah, ax + aw, ay + ah);
            Paint ap = new Paint(Paint.ANTI_ALIAS_FLAG);
            ap.setStyle(Paint.Style.STROKE);
            ap.setStrokeWidth(Math.max(1.2f, 1.5f * k));
            ap.setColor(alpha(0xFFFFFFFF, 0x66));
            ap.setPathEffect(new android.graphics.DashPathEffect(new float[]{5 * k, 5 * k}, 0));
            cv.drawArc(arc, 180, 180, false, ap);
            Paint hz = new Paint(Paint.ANTI_ALIAS_FLAG);
            hz.setColor(alpha(gold, 0x88));
            hz.setStrokeWidth(Math.max(1f, 1f * k));
            cv.drawLine(ax - 8 * k, ay, ax + aw + 8 * k, ay, hz);
            long now = System.currentTimeMillis();
            float f;
            boolean day = m.sunrise > 0 && m.sunset > m.sunrise && now >= m.sunrise && now <= m.sunset;
            if (day) f = (now - m.sunrise) / (float) (m.sunset - m.sunrise);
            else f = 0.5f;
            double ang = Math.PI * (1 - f); // من اليسار إلى اليمين
            float sx = (float) (ax + aw / 2 + Math.cos(ang) * aw / 2);
            float sy = (float) (ay - Math.sin(ang) * ah);
            Paint sun = new Paint(Paint.ANTI_ALIAS_FLAG);
            if (day) {
                sun.setShader(new RadialGradient(sx, sy, 22 * k, new int[]{0xFFFFF4C2, 0xFFF6C447, 0x00F6C447}, new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP));
                cv.drawCircle(sx, sy, 22 * k, sun);
            } else {
                Path mo = new Path(); mo.addCircle(sx, sy, 10 * k, Path.Direction.CW);
                Path cut = new Path(); cut.addCircle(sx + 5 * k, sy - 3 * k, 9 * k, Path.Direction.CW);
                mo.op(cut, Path.Op.DIFFERENCE);
                sun.setColor(0xFFF3E7B8);
                cv.drawPath(mo, sun);
            }
        }

        Paint bp = new Paint(Paint.ANTI_ALIAS_FLAG);
        bp.setStyle(Paint.Style.STROKE);
        bp.setStrokeWidth(Math.max(1f, 1.2f * k));
        bp.setColor(alpha(gold, style == PHASE || style == SUN ? 0x55 : 0x99));
        float ins = bp.getStrokeWidth() / 2;
        if (classic(m)) cv.drawRoundRect(new RectF(ins, ins, w - ins, h - ins), rad - ins, rad - ins, bp);
        finishLook(cv, w, h, rad, k, m);
        return b;
    }

    public static Bitmap bg(Context c, Bundle opts, int defWdp, int defHdp, int style, WidgetModel m, String skyKey, boolean crescent) {
        float d = c.getResources().getDisplayMetrics().density;
        int wdp = 0, hdp = 0;
        if (opts != null) {
            wdp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0);
            hdp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0);
        }
        if (wdp <= 0) wdp = defWdp;
        if (hdp <= 0) hdp = defHdp;
        float scale = Math.min(1f, 900f / (Math.max(wdp, hdp) * d));
        float k = d * scale;
        int w = Math.max(40, (int) (wdp * k)), h = Math.max(40, (int) (hdp * k));
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        float rad = 24 * k;
        RectF rect = new RectF(0, 0, w, h);
        Path clip = new Path();
        clip.addRoundRect(rect, rad, rad, Path.Direction.CW);
        cv.clipPath(clip);

        int c1, c2;
        if (style == GLASS) { c1 = alpha(mix(m.c2, 0xFF000000, 0.35f), 0xC8); c2 = alpha(mix(m.c1, 0xFF000000, 0.2f), 0xB0); }
        else if (style == SKY) { int[] s = sky(skyKey); c1 = s[0]; c2 = s[1]; }
        else if (style == MINIMAL) { c1 = m.c1; c2 = mix(m.c1, m.c2, 0.6f); }
        else { c1 = mix(m.c2, 0xFF000000, 0.15f); c2 = m.c1; }
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Shader def = new LinearGradient(0, 0, w, h, c1, c2, Shader.TileMode.CLAMP);
        p.setShader(style == SKY ? def : gradShader(m, w, h, def, style == GLASS ? 0.2f : 0f));
        fillBase(cv, rect, p, m);

        // توهّج ذهبي ناعم
        Paint g = new Paint(Paint.ANTI_ALIAS_FLAG);
        g.setShader(new RadialGradient(w * 0.85f, h * 0.1f, Math.max(w, h) * 0.6f, alpha(m.gold, style == MINIMAL ? 0x18 : 0x30), 0, Shader.TileMode.CLAMP));
        cv.drawRect(rect, g);

        // الزخرفة المختارة
        if (style != MINIMAL) ornament(cv, w, h, k, m, alpha(m.gold, style == GLASS ? 0x1C : 0x16), 54);

        // هلال ذهبي رقيق
        if (crescent && !"none".equals(m.orn)) {
            float R = Math.min(w, h) * 0.32f;
            float cx = w * 0.12f, cy = h * 0.22f;
            Path a = new Path(); a.addCircle(cx, cy, R, Path.Direction.CW);
            Path bb = new Path(); bb.addCircle(cx + R * 0.42f, cy - R * 0.18f, R * 0.92f, Path.Direction.CW);
            a.op(bb, Path.Op.DIFFERENCE);
            Paint cp = new Paint(Paint.ANTI_ALIAS_FLAG);
            cp.setColor(alpha(m.gold, 0x2E));
            cv.drawPath(a, cp);
        }

        // إطار ذهبي رقيق
        Paint bp = new Paint(Paint.ANTI_ALIAS_FLAG);
        bp.setStyle(Paint.Style.STROKE);
        bp.setStrokeWidth(Math.max(1f, 1.2f * k));
        bp.setColor(alpha(m.gold, style == MINIMAL ? 0x40 : 0x8C));
        float ins = bp.getStrokeWidth() / 2;
        if (classic(m)) cv.drawRoundRect(new RectF(ins, ins, w - ins, h - ins), rad - ins, rad - ins, bp);
        finishLook(cv, w, h, rad, k, m);
        if (style == GLASS && classic(m)) {
            Paint hi = new Paint(Paint.ANTI_ALIAS_FLAG);
            hi.setShader(new LinearGradient(0, 0, 0, h * 0.45f, 0x22FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
            cv.drawRect(rect, hi);
        }
        return b;
    }

    /** خلفية سماء ليلية بلون الثيم مع نجوم ولمعات خفيفة (للساعة النجمية) */
    public static Bitmap starBg(Context c, Bundle opts, int defWdp, int defHdp, WidgetModel m) {
        float d = c.getResources().getDisplayMetrics().density;
        int wdp = defWdp, hdp = defHdp;
        if (opts != null) {
            int a = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, 0), b = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 0);
            if (a > 0) wdp = a; if (b > 0) hdp = b;
        }
        int w = Math.max(1, Math.min(900, (int) (wdp * d * 0.75f))), h = Math.max(1, Math.min(700, (int) (hdp * d * 0.75f)));
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        int top = mix(m.c2, 0xFF000000, 0.25f), bot = mix(m.c1, 0xFF000000, 0.05f);
        p.setShader(gradShader(m, w, h, new LinearGradient(0, 0, w * 0.3f, h, top, bot, Shader.TileMode.CLAMP), 0.2f));
        float r = 22 * d * 0.75f;
        Path clipS = new Path();
        clipS.addRoundRect(new RectF(0, 0, w, h), r, r, Path.Direction.CW);
        cv.clipPath(clipS);
        fillBase(cv, new RectF(0, 0, w, h), p, m);
        p.setShader(new RadialGradient(w * 0.3f, h * 0.35f, Math.max(w, h) * 0.6f, alpha(m.gold, 40), 0, Shader.TileMode.CLAMP));
        cv.drawRoundRect(new RectF(0, 0, w, h), r, r, p);
        p.setShader(null);
        if (!"star".equals(m.orn)) ornament(cv, w, h, d * 0.75f, m, alpha(m.gold, 0x18), 50);
        java.util.Random rnd = new java.util.Random(7);
        for (int i = 0; i < 90; i++) {
            float x = rnd.nextFloat() * w, y = rnd.nextFloat() * h, s = (0.4f + rnd.nextFloat() * 1.1f) * d * 0.75f;
            p.setColor(alpha(0xFFFFFFFF, 60 + rnd.nextInt(150)));
            cv.drawCircle(x, y, s, p);
        }
        p.setStrokeWidth(1.1f * d);
        for (int i = 0; i < 6; i++) {
            float x = rnd.nextFloat() * w, y = rnd.nextFloat() * h, s = (3 + rnd.nextFloat() * 4) * d * 0.75f;
            p.setColor(alpha(0xFFFFFFFF, 170));
            cv.drawLine(x - s, y, x + s, y, p);
            cv.drawLine(x, y - s, x, y + s, p);
        }
        finishLook(cv, w, h, r, d * 0.75f, m);
        return bmp;
    }

    /** عمود التاريخ بالخط العربي (أميري) مع الرقم الكبير الشفاف خلف الشهر */
    public static Bitmap calliColumn(Context c, String wd, String grd, String grm, String hjd, String hjm) {
        int w = 360, h = 420;
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bmp);
        android.graphics.Typeface cal = android.graphics.Typeface.create(android.graphics.Typeface.SERIF, android.graphics.Typeface.BOLD);
        try { if (android.os.Build.VERSION.SDK_INT >= 26) cal = c.getResources().getFont(R.font.amiri_bold); } catch (Exception ignored) {}
        android.graphics.Typeface thin = android.graphics.Typeface.create("sans-serif-condensed", android.graphics.Typeface.BOLD);
        Paint num = new Paint(Paint.ANTI_ALIAS_FLAG);
        num.setTypeface(thin); num.setTextAlign(Paint.Align.CENTER); num.setTextSize(118); num.setColor(0x52FFFFFF);
        Paint tx = new Paint(Paint.ANTI_ALIAS_FLAG);
        tx.setTypeface(cal); tx.setTextAlign(Paint.Align.CENTER); tx.setColor(0xFFFFFFFF);
        tx.setShadowLayer(6, 0, 2, 0x55000000);
        float cx = w / 2f;
        String[] rows = {wd, grm, hjm};
        String[] nums = {"", grd, hjd};
        float[] ys = {h * 0.20f, h * 0.55f, h * 0.88f};
        for (int i = 0; i < 3; i++) {
            if (nums[i] != null && !nums[i].isEmpty()) cv.drawText(nums[i].replaceAll("[^0-9٠-٩]", ""), cx, ys[i] + 18, num);
            String s = rows[i] == null ? "" : rows[i];
            float size = 74;
            tx.setTextSize(size);
            while (tx.measureText(s) > w * 0.96f && size > 30) { size -= 4; tx.setTextSize(size); }
            cv.drawText(s, cx, ys[i], tx);
        }
        return bmp;
    }

    /** خلفية «حالة اليوم»: لوح داكن مائل للون الثيم */
    public static Bitmap todayBg(Context c, Bundle opts, WidgetModel m) {
        float d = c.getResources().getDisplayMetrics().density;
        int wdp = 300, hdp = 300;
        if (opts != null) {
            int a = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, 0), b = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0);
            if (a > 0) wdp = a; if (b > 0) hdp = b;
        }
        int w = Math.max(1, Math.min(900, (int) (wdp * d * 0.7f))), h = Math.max(1, Math.min(900, (int) (hdp * d * 0.7f)));
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        // لون الثيم أو التدرّج المختار، بدرجة داكنة تناسب النص الأبيض
        int top = mix(m.c2, 0xFF0A0C10, m.custom ? 0.35f : 0.55f), bot = mix(m.c1, 0xFF0A0C10, m.custom ? 0.45f : 0.65f);
        p.setShader(gradShader(m, w, h, new LinearGradient(0, 0, 0, h, top, bot, Shader.TileMode.CLAMP), 0.4f));
        float r = 26 * d * 0.7f;
        RectF rc = new RectF(0, 0, w, h);
        Path clipT = new Path();
        clipT.addRoundRect(rc, r, r, Path.Direction.CW);
        cv.clipPath(clipT);
        fillBase(cv, rc, p, m);
        p.setShader(null);
        Paint gl = new Paint(Paint.ANTI_ALIAS_FLAG);
        gl.setShader(new RadialGradient(w * 0.8f, h * 0.05f, Math.max(w, h) * 0.6f, alpha(m.gold, 0x26), 0, Shader.TileMode.CLAMP));
        cv.drawRect(rc, gl);
        ornament(cv, w, h, d * 0.7f, m, alpha(m.gold, 0x16), 56);
        if (classic(m)) {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1.2f * d);
            p.setColor(alpha(m.gold, 0x55));
            cv.drawRoundRect(new RectF(1, 1, w - 1, h - 1), r, r, p);
        }
        finishLook(cv, w, h, r, d * 0.7f, m);
        return bmp;
    }

    /** شريط تقدم مستدير */
    public static Bitmap bar(float frac, int color) {
        int w = 400, h = 22;
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(0x33FFFFFF);
        cv.drawRoundRect(new RectF(0, 0, w, h), h / 2f, h / 2f, p);
        p.setColor(color);
        float fw = Math.max(h, w * Math.max(0f, Math.min(1f, frac)));
        cv.drawRoundRect(new RectF(w - fw, 0, w, h), h / 2f, h / 2f, p); // يبدأ من اليمين (عربي)
        return bmp;
    }

    /** حلقة نسبة مئوية */
    public static Bitmap ring(float frac, int color) {
        int s = 300;
        Bitmap bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(22);
        p.setStrokeCap(Paint.Cap.ROUND);
        RectF rc = new RectF(24, 24, s - 24, s - 24);
        p.setColor(0x33FFFFFF);
        cv.drawArc(rc, 0, 360, false, p);
        p.setColor(color);
        cv.drawArc(rc, -90, 360 * Math.max(0f, Math.min(1f, frac)), false, p);
        Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);
        t.setColor(0xFFFFFFFF);
        t.setTextAlign(Paint.Align.CENTER);
        t.setFakeBoldText(true);
        t.setTextSize(74);
        String num = String.valueOf(Math.round(frac * 100));
        float tw = t.measureText(num);
        Paint sm = new Paint(t); sm.setTextSize(36);
        cv.drawText(num, s / 2f - 12, s / 2f + 26, t);
        cv.drawText("%", s / 2f - 12 + tw / 2f + 18, s / 2f + 26, sm);
        return bmp;
    }

    /** حلقة صلاة مع أيقونتها: past = مكتملة، next = تمتلئ مع الوقت، up = قادمة (خافتة) */
    public static Bitmap prayerRing(String k, float frac, String state, int accent) {
        int s = 200;
        Bitmap bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bmp);
        float cx = s / 2f, cy = s / 2f, R = 84, sw = "next".equals(state) ? 15 : 12;
        Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        fill.setColor("up".equals(state) ? 0x14FFFFFF : 0x22FFFFFF);
        cv.drawCircle(cx, cy, R, fill);
        Paint tr = new Paint(Paint.ANTI_ALIAS_FLAG);
        tr.setStyle(Paint.Style.STROKE);
        tr.setStrokeWidth(sw);
        tr.setColor(0x38FFFFFF);
        cv.drawCircle(cx, cy, R, tr);
        float f = "past".equals(state) ? 1f : "next".equals(state) ? Math.max(0.04f, Math.min(1f, frac)) : 0f;
        if (f > 0) {
            Paint ar = new Paint(Paint.ANTI_ALIAS_FLAG);
            ar.setStyle(Paint.Style.STROKE);
            ar.setStrokeWidth(sw);
            ar.setStrokeCap(Paint.Cap.ROUND);
            ar.setColor("next".equals(state) ? accent : 0xF0FFFFFF);
            cv.drawArc(new RectF(cx - R, cy - R, cx + R, cy + R), -90, 360 * f, false, ar);
        }
        Paint ic = new Paint(Paint.ANTI_ALIAS_FLAG);
        ic.setStyle(Paint.Style.STROKE);
        ic.setStrokeCap(Paint.Cap.ROUND);
        ic.setStrokeJoin(Paint.Join.ROUND);
        ic.setStrokeWidth(8);
        ic.setColor("up".equals(state) ? 0xC0FFFFFF : 0xFFFFFFFF);
        // شبكة الأيقونة 24×24 داخل مربع 96px في المنتصف
        float u = 4.2f, ox = cx - 12 * u, oy = cy - 12 * u;
        if ("fajr".equals(k) || "asr".equals(k) || "maghrib".equals(k)) {
            float hy = "maghrib".equals(k) ? 16 : ("asr".equals(k) ? 14 : 15);
            cv.drawArc(new RectF(ox + 7.5f * u, oy + (hy - 4.5f) * u, ox + 16.5f * u, oy + (hy + 4.5f) * u), 180, 180, false, ic);
            cv.drawLine(ox + 5 * u, oy + hy * u, ox + 19 * u, oy + hy * u, ic);
            if ("maghrib".equals(k)) {
                cv.drawLine(ox + 12 * u, oy + 4.5f * u, ox + 12 * u, oy + 10 * u, ic);
                Path a = new Path(); a.moveTo(ox + 9.6f * u, oy + 8 * u); a.lineTo(ox + 12 * u, oy + 10.4f * u); a.lineTo(ox + 14.4f * u, oy + 8 * u);
                cv.drawPath(a, ic);
                cv.drawLine(ox + 8 * u, oy + 19 * u, ox + 16 * u, oy + 19 * u, ic);
            } else {
                float ry = hy - 8.5f;
                cv.drawLine(ox + 12 * u, oy + ry * u, ox + 12 * u, oy + (ry + 2) * u, ic);
                cv.drawLine(ox + 6.3f * u, oy + (ry + 2.8f) * u, ox + 7.6f * u, oy + (ry + 4) * u, ic);
                cv.drawLine(ox + 17.7f * u, oy + (ry + 2.8f) * u, ox + 16.4f * u, oy + (ry + 4) * u, ic);
                if ("asr".equals(k)) {
                    cv.drawLine(ox + 7 * u, oy + 17 * u, ox + 17 * u, oy + 17 * u, ic);
                    cv.drawLine(ox + 9 * u, oy + 20 * u, ox + 15 * u, oy + 20 * u, ic);
                } else cv.drawLine(ox + 8 * u, oy + 18 * u, ox + 16 * u, oy + 18 * u, ic);
            }
        } else if ("isha".equals(k)) {
            Path mo = new Path(); mo.addCircle(cx - 4, cy + 2, 30, Path.Direction.CW);
            Path cut = new Path(); cut.addCircle(cx + 12, cy - 10, 26, Path.Direction.CW);
            mo.op(cut, Path.Op.DIFFERENCE);
            Paint mf = new Paint(Paint.ANTI_ALIAS_FLAG);
            mf.setColor(ic.getColor());
            cv.drawPath(mo, mf);
        } else { // الظهر: شمس كاملة
            cv.drawCircle(cx, cy, 3.6f * u, ic);
            for (int i = 0; i < 8; i++) {
                double a = Math.PI / 4 * i;
                float c1 = (float) Math.cos(a), s1 = (float) Math.sin(a);
                cv.drawLine(cx + c1 * 6.4f * u, cy + s1 * 6.4f * u, cx + c1 * 8.2f * u, cy + s1 * 8.2f * u, ic);
            }
        }
        return bmp;
    }
}
