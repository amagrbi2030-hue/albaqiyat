package com.albaqiyat.app;

public class WCalliWidget extends BaseWidget {
    @Override
    protected String kind() { return "calli"; }
}
