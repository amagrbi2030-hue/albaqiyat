package com.albaqiyat.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/** جدولة منبّهات الأذان والإقامة في نظام أندرويد (تعمل والتطبيق مغلق ودون إنترنت) */
public class AlarmScheduler {
    static final String PREFS = "adhan_prefs";
    static final String ACTION_ADHAN = "com.albaqiyat.app.ADHAN";
    static final String ACTION_TICK = "com.albaqiyat.app.WIDGET_TICK";

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static int piFlags() {
        return PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
    }

    static PendingIntent pi(Context c, int id) {
        Intent i = new Intent(c, AdhanReceiver.class);
        i.setAction(ACTION_ADHAN);
        i.putExtra("id", id);
        return PendingIntent.getBroadcast(c, id, i, piFlags());
    }

    static boolean canExact(Context c) {
        if (Build.VERSION.SDK_INT >= 31) {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            return am != null && am.canScheduleExactAlarms();
        }
        return true;
    }

    static void cancelAll(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        try {
            JSONArray ids = new JSONArray(prefs(c).getString("ids", "[]"));
            for (int i = 0; i < ids.length(); i++) am.cancel(pi(c, ids.getInt(i)));
        } catch (JSONException ignored) {}
    }

    static void setAlarm(AlarmManager am, long at, PendingIntent p, boolean exact) {
        if (Build.VERSION.SDK_INT >= 23) {
            if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p);
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p);
        } else {
            if (exact) am.setExact(AlarmManager.RTC_WAKEUP, at, p);
            else am.set(AlarmManager.RTC_WAKEUP, at, p);
        }
    }

    static int scheduleAll(Context c) {
        cancelAll(c);
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return 0;
        boolean exact = canExact(c);
        long now = System.currentTimeMillis();
        JSONArray ids = new JSONArray();
        int n = 0;
        try {
            JSONArray ev = new JSONArray(prefs(c).getString("events", "[]"));
            for (int i = 0; i < ev.length() && n < 450; i++) {
                JSONObject o = ev.optJSONObject(i);
                if (o == null) continue;
                long at = o.optLong("at", 0);
                if (at <= now) continue;
                int id = o.optInt("id", 0);
                try {
                    setAlarm(am, at, pi(c, id), exact);
                } catch (SecurityException se) {
                    setAlarm(am, at, pi(c, id), false);
                }
                ids.put(id);
                n++;
            }
        } catch (JSONException ignored) {}
        prefs(c).edit().putString("ids", ids.toString()).apply();
        scheduleWidgetTick(c);
        return n;
    }

    static JSONObject find(Context c, int id) {
        try {
            JSONArray ev = new JSONArray(prefs(c).getString("events", "[]"));
            for (int i = 0; i < ev.length(); i++) {
                JSONObject o = ev.optJSONObject(i);
                if (o != null && o.optInt("id", -1) == id) return o;
            }
        } catch (JSONException ignored) {}
        return null;
    }

    static void scheduleWidgetTick(Context c) {
        StatusNotice.update(c);
        long next = StatusNotice.nextChange(c);
        long wm = WidgetModel.nextChange(c);
        if (wm > 0) next = next > 0 ? Math.min(next, wm) : wm;
        if (WidgetHub.any(c)) {
            long soon = System.currentTimeMillis() + 10 * 60 * 1000L; // تحديث شريط التقدم كل ١٠ دقائق
            next = next > 0 ? Math.min(next, soon) : soon;
        }
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        Intent i = new Intent(c, PrayerWidget.class);
        i.setAction(ACTION_TICK);
        PendingIntent p = PendingIntent.getBroadcast(c, 99001, i, piFlags());
        am.cancel(p);
        if (next <= 0) return;
        try { setAlarm(am, next + 1500, p, canExact(c)); } catch (SecurityException se) { setAlarm(am, next + 1500, p, false); }
    }
}
