package com.albaqiyat.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/** جدولة منبّهات الأذان والإقامة في نظام أندرويد (تعمل والتطبيق مغلق ودون إنترنت) */
public class AlarmScheduler {
    static final String PREFS = "adhan_prefs";
    static final String ACTION_ADHAN = "com.albaqiyat.app.ADHAN";
    static final String ACTION_TICK = "com.albaqiyat.app.WIDGET_TICK";

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static int piFlags() {
        return PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
    }

    static PendingIntent pi(Context c, int id) {
        Intent i = new Intent(c, AdhanReceiver.class);
        i.setAction(ACTION_ADHAN);
        i.putExtra("id", id);
        return PendingIntent.getBroadcast(c, id, i, piFlags());
    }

    static boolean canExact(Context c) {
        if (Build.VERSION.SDK_INT >= 31) {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            return am != null && am.canScheduleExactAlarms();
        }
        return true;
    }

    static void cancelAll(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        try {
            JSONArray ids = new JSONArray(prefs(c).getString("ids", "[]"));
            for (int i = 0; i < ids.length(); i++) { am.cancel(pi(c, ids.getInt(i))); am.cancel(piBackup(c, ids.getInt(i))); }
        } catch (JSONException ignored) {}
    }

    static void setAlarm(AlarmManager am, long at, PendingIntent p, boolean exact) {
        if (Build.VERSION.SDK_INT >= 23) {
            if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p);
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p);
        } else {
            if (exact) am.setExact(AlarmManager.RTC_WAKEUP, at, p);
            else am.set(AlarmManager.RTC_WAKEUP, at, p);
        }
    }

    static final int BACKUP = 1000000000; // رمز المنبّه الاحتياطي = رمز الحدث + هذا الرقم

    static PendingIntent piBackup(Context c, int id) {
        Intent i = new Intent(c, AdhanReceiver.class);
        i.setAction(ACTION_ADHAN);
        i.putExtra("id", id);
        i.putExtra("backup", true);
        return PendingIntent.getBroadcast(c, BACKUP + id, i, piFlags());
    }

    /** منبّه الصلاة كـ«منبّه ساعة» (setAlarmClock): لا يؤخّره وضع السكون ولا وضع الطيران،
     *  ويوقظ الجهاز في الوقت الدقيق كمنبّه الساعة. نجرّبه دائماً أولاً، وإن رُفض نعود للطريقة الدقيقة ثم العادية.
     *  يعيد اسم الطريقة المستخدمة (للتشخيص). */
    static String setEventAlarm(Context c, AlarmManager am, long at, PendingIntent p, boolean exact) {
        if (Build.VERSION.SDK_INT >= 21) {
            try {
                Intent open = new Intent(c, MainActivity.class);
                open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                PendingIntent show = PendingIntent.getActivity(c, 99100, open, piFlags());
                am.setAlarmClock(new AlarmManager.AlarmClockInfo(at, show), p);
                return "clock";
            } catch (Exception ignored) {}
        }
        try { setAlarm(am, at, p, exact); return exact ? "exact" : "inexact"; }
        catch (SecurityException se) { setAlarm(am, at, p, false); return "inexact"; }
    }

    static int scheduleAll(Context c) {
        cancelAll(c);
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return 0;
        boolean exact = canExact(c);
        long now = System.currentTimeMillis();
        JSONArray ids = new JSONArray();
        int n = 0, backups = 0;
        String method = "";
        try {
            JSONArray ev = new JSONArray(prefs(c).getString("events", "[]"));
            for (int i = 0; i < ev.length() && n < 420; i++) {
                JSONObject o = ev.optJSONObject(i);
                if (o == null) continue;
                long at = o.optLong("at", 0);
                if (at <= now) continue;
                int id = o.optInt("id", 0);
                String m = setEventAlarm(c, am, at, pi(c, id), exact);
                if (method.isEmpty()) method = m;
                // منبّه احتياطي ثانٍ لنفس الوقت (للـ٣٦ ساعة القادمة) — إن تأخر أحدهما وصل الآخر، ولا يتكرر الأذان
                if (backups < 40 && at - now < 36 * 3600 * 1000L) {
                    try { setAlarm(am, at, piBackup(c, id), exact); backups++; }
                    catch (Exception e) { try { setAlarm(am, at, piBackup(c, id), false); backups++; } catch (Exception ignored) {} }
                }
                ids.put(id);
                n++;
            }
        } catch (JSONException ignored) {}
        prefs(c).edit().putString("ids", ids.toString()).putString("method", method).putLong("sched_at", now).apply();
        scheduleWidgetTick(c);
        return n;
    }

    /** منع تكرار الأذان إذا وصل المنبّه الأساسي والاحتياطي معاً */
    static synchronized boolean markFired(Context c, int id) {
        try {
            JSONArray f = new JSONArray(prefs(c).getString("fired", "[]"));
            for (int i = 0; i < f.length(); i++) if (f.optInt(i) == id) return false;
            JSONArray out = new JSONArray();
            int start = Math.max(0, f.length() - 30);
            for (int i = start; i < f.length(); i++) out.put(f.optInt(i));
            out.put(id);
            prefs(c).edit().putString("fired", out.toString()).commit();
        } catch (JSONException ignored) {}
        return true;
    }

    /** سجل آخر التنبيهات: الموعد ووقت الوصول الفعلي وحالة الشاشة (لتشخيص التأخير) */
    static void log(Context c, JSONObject ev, boolean backup, String note) {
        try {
            JSONArray l = new JSONArray(prefs(c).getString("log", "[]"));
            JSONObject e = new JSONObject();
            e.put("kind", ev.optString("kind"));
            e.put("name", ev.optString("name"));
            e.put("at", ev.optLong("at"));
            e.put("got", System.currentTimeMillis());
            e.put("backup", backup);
            e.put("note", note);
            try {
                android.os.PowerManager pm = (android.os.PowerManager) c.getSystemService(Context.POWER_SERVICE);
                e.put("screen", pm != null && pm.isInteractive());
                e.put("idle", Build.VERSION.SDK_INT >= 23 && pm != null && pm.isDeviceIdleMode());
            } catch (Exception ignored) {}
            JSONArray out = new JSONArray();
            int start = Math.max(0, l.length() - 11);
            for (int i = start; i < l.length(); i++) out.put(l.get(i));
            out.put(e);
            prefs(c).edit().putString("log", out.toString()).commit();
        } catch (Exception ignored) {}
    }

    static JSONObject find(Context c, int id) {
        try {
            JSONArray ev = new JSONArray(prefs(c).getString("events", "[]"));
            for (int i = 0; i < ev.length(); i++) {
                JSONObject o = ev.optJSONObject(i);
                if (o != null && o.optInt("id", -1) == id) return o;
            }
        } catch (JSONException ignored) {}
        return null;
    }

    static void scheduleWidgetTick(Context c) {
        StatusNotice.update(c);
        long next = StatusNotice.nextChange(c);
        long wm = WidgetModel.nextChange(c);
        if (wm > 0) next = next > 0 ? Math.min(next, wm) : wm;
        if (WidgetHub.any(c)) {
            long soon = System.currentTimeMillis() + 10 * 60 * 1000L; // تحديث شريط التقدم كل ١٠ دقائق
            next = next > 0 ? Math.min(next, soon) : soon;
        }
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        Intent i = new Intent(c, PrayerWidget.class);
        i.setAction(ACTION_TICK);
        PendingIntent p = PendingIntent.getBroadcast(c, 99001, i, piFlags());
        am.cancel(p);
        if (next <= 0) return;
        // تحديث الودجت والإشعار الدائم بمنبّه غير موقِظ: لا يستهلك حصة منبّهات وضع السكون
        // (كان يستهلكها فيتأخر الأذان نفسه في وضع الطيران/انقطاع الإنترنت حين يدخل الهاتف سكوناً عميقاً)
        try {
            if (canExact(c)) am.setExact(AlarmManager.RTC, next + 1500, p);
            else am.set(AlarmManager.RTC, next + 1500, p);
        } catch (Exception e) { try { am.set(AlarmManager.RTC, next + 1500, p); } catch (Exception ignored) {} }
    }
}
