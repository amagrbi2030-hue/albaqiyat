/**
 * خادم «المصمم الذكي» لاستوديو الويدجيت — Cloudflare Worker (مثال مرجعي)
 * ---------------------------------------------------------------
 * • المفتاح يبقى هنا فقط (secret: ANTHROPIC_API_KEY) ولا يوضع في التطبيق أبداً.
 * • يستقبل: POST {task:'generate'|'refine', prompt, opts?, spec?, palette?, image?(data URI), schema}
 * • يُرجع:  {designs:[spec,…≤3], palette?:[hex…], note?:string}
 * • التطبيق يتحقق من كل تصميم (mwValidate) ويتجاهل أي حقل غير معروف، ولا ينفّذ أي كود.
 *
 * النشر:
 *   npm i -g wrangler && wrangler init widget-ai && (انسخ هذا الملف إلى src/index.js)
 *   wrangler secret put ANTHROPIC_API_KEY
 *   wrangler deploy   ← ثم ضع رابط https الناتج في «إعدادات خادم الذكاء الاصطناعي» داخل التطبيق
 */
const MODEL = 'claude-sonnet-5-5';
const MAX_PER_IP_PER_DAY = 60;

export default {
  async fetch(req, env) {
    const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'POST, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type' };
    if (req.method === 'OPTIONS') return new Response(null, { headers: cors });
    if (req.method !== 'POST') return new Response('POST only', { status: 405, headers: cors });
    let body;
    try { body = await req.json(); } catch { return json({ error: 'bad json' }, 400, cors); }
    if (JSON.stringify(body).length > 900_000) return json({ error: 'payload too large' }, 413, cors);

    // حد بسيط لكل عنوان IP (يتطلب KV باسم RL؛ يُتجاهل إن لم يوجد)
    if (env.RL) {
      const ip = req.headers.get('CF-Connecting-IP') || 'x', k = ip + ':' + new Date().toISOString().slice(0, 10);
      const n = +(await env.RL.get(k) || 0);
      if (n >= MAX_PER_IP_PER_DAY) return json({ error: 'limit' }, 429, cors);
      await env.RL.put(k, String(n + 1), { expirationTtl: 90000 });
    }

    const task = body.task === 'refine' ? 'refine' : 'generate';
    const sys = [
      'أنت مصمم ويدجيت لتطبيق إسلامي عربي. أعد JSON صالحاً فقط دون أي نص آخر أو كود.',
      'البنية المسموحة موصوفة في schema. الإحداثيات x,y,w,h نسب مئوية من 0 إلى 100، وfs نسبة من ارتفاع الويدجيت.',
      'لا تكتب أي نص قرآني بنفسك: لعنصر الآية استخدم فقط s (رقم السورة) وa (رقم الآية) وfrom/to (أرقام الكلمات)، والتطبيق يأتي بالنص الحرفي من مصدره.',
      'لا تخترع أحاديث أو أذكاراً؛ للأذكار استخدم عنصر dhikr بمعرّف من قائمة التطبيق أو نصوصاً عامة مثل «سبحان الله».',
      'للبيانات الحية استخدم الرموز: {weekday} {hijri} {greg} {time} {next} {next_time} {iqama} {countdown} {city} {sunrise} {lastthird} {to_ramadan} {temp} {wdesc}.',
      task === 'generate' ? 'أنشئ ثلاثة تصاميم مختلفة فعلاً في التخطيط والألوان: {"designs":[…3]}' : 'عدّل التصميم المعطى وفق الطلب وأعده كاملاً: {"designs":[spec]}',
    ].join('\n');
    const content = [];
    if (typeof body.image === 'string' && /^data:image\/(png|jpeg|webp);base64,/.test(body.image)) {
      const [, mt, data] = body.image.match(/^data:(image\/\w+);base64,(.+)$/);
      content.push({ type: 'image', source: { type: 'base64', media_type: mt, data } });
      content.push({ type: 'text', text: 'هذه صورة مرجعية: أعد بناء تصميم مشابه لها في التخطيط والألوان باستخدام العناصر المسموحة فقط.' });
    }
    content.push({ type: 'text', text: JSON.stringify({ schema: body.schema, prompt: String(body.prompt || '').slice(0, 600), opts: body.opts || {}, palette: body.palette || null, spec: task === 'refine' ? body.spec : undefined }) });

    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'x-api-key': env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
      body: JSON.stringify({ model: env.MODEL || MODEL, max_tokens: 6000, system: sys, messages: [{ role: 'user', content }] }),
    });
    if (!r.ok) return json({ error: 'upstream ' + r.status }, 502, cors);
    const out = await r.json();
    const text = (out.content || []).filter(b => b.type === 'text').map(b => b.text).join('');
    const m = text.match(/\{[\s\S]*\}/);
    let j; try { j = JSON.parse(m ? m[0] : text); } catch { return json({ error: 'model returned invalid JSON' }, 502, cors); }
    // تمرير الحقول المعروفة فقط؛ التحقق الكامل يجري في التطبيق
    return json({ designs: Array.isArray(j.designs) ? j.designs.slice(0, 3) : [], palette: Array.isArray(j.palette) ? j.palette.slice(0, 6) : undefined, note: typeof j.note === 'string' ? j.note.slice(0, 200) : undefined }, 200, cors);
  },
};
const json = (o, s, h) => new Response(JSON.stringify(o), { status: s, headers: { ...h, 'Content-Type': 'application/json; charset=utf-8' } });
