package com.albaqiyat.app;

import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * ثلاثة أشكال «البطاقة ذات اللسان»: لسان (كبسولة) منفصل تلتفّ حوله البطاقة بفجوة وانحناءات ناعمة.
 *  • wxweek: الطقس الحالي في لسان علوي + اليوم والتاريخان + توقعات ٧ أيام
 *  • ptop:   وقت الصلاة القادمة في لسان علوي + التاريخ + المتبقي + الصلوات الست بأيقوناتها
 *  • pside:  لسان جانبي بأيقونة الصلاة القادمة ووقتها + اسمها والمتبقي + الصلوات الست
 * كل الألوان والخامة والتدرّج والشفافية والظل والتوهج والزخرفة والإطار من «نظام المظاهر» (WidgetModel).
 */
final class WNotchArt {
    private WNotchArt() {}

    // ── الشكل ──
    static final class Geo {
        Path body, tab; RectF tabR; float v0, nEnd, nStart, nDepth; boolean side;
    }

    static final float KAP = .5523f;

    /** مسار البطاقة مع التجويف حول اللسان. الإحداثيات (u على امتداد الحافة، v نحو الداخل) تُحوَّل إلى (x,y) */
    static Geo geo(RectF r, float k, WidgetModel m, boolean side, float tl, float td) {
        Geo g = new Geo(); g.side = side;
        final float L = side ? r.height() : r.width(), D = side ? r.width() : r.height();
        final float ox = r.left, oy = r.top;
        float gap = 4 * k, f = 8 * k, v0 = td / 2f;
        float cu = side ? L / 2f : L / 2f;
        float eu0 = cu - tl / 2f - gap, eu1 = cu + tl / 2f + gap, ev1 = td + gap;
        float R = Math.max(0, Math.min(WSkinArt.rad(m, k), Math.min((D - v0) / 2f, L / 4f)));
        float r2 = Math.max(0, Math.min((td + gap * 2) / 2f, ev1 - v0 - f));
        g.v0 = v0; g.nStart = eu0 - f; g.nEnd = eu1 + f; g.nDepth = ev1;
        PB p = new PB(side, ox, oy);
        p.m(R, v0);
        p.l(eu0 - f, v0);
        p.c(eu0 - f, v0, eu0, v0, eu0, v0 + f);
        p.l(eu0, ev1 - r2);
        p.c(eu0, ev1, eu0, ev1, eu0 + r2, ev1, true);
        p.l(eu1 - r2, ev1);
        p.c(eu1 - r2, ev1, eu1, ev1, eu1, ev1 - r2);
        p.l(eu1, v0 + f);
        p.c(eu1, v0 + f, eu1, v0, eu1 + f, v0);
        p.l(L - R, v0);
        p.c(L - R, v0, L, v0, L, v0 + R);
        p.l(L, D - R);
        p.c(L, D - R, L, D, L - R, D);
        p.l(R, D);
        p.c(R, D, 0, D, 0, D - R);
        p.l(0, v0 + R);
        p.c(0, v0 + R, 0, v0, R, v0);
        p.path.close();
        g.body = p.path;
        // اللسان: كبسولة
        float a = cu - tl / 2f, b = cu + tl / 2f;
        RectF tr = side ? new RectF(ox, oy + a, ox + td, oy + b) : new RectF(ox + a, oy, ox + b, oy + td);
        g.tabR = tr;
        g.tab = new Path();
        float rr = Math.min(tr.width(), tr.height()) / 2f;
        g.tab.addRoundRect(tr, rr, rr, Path.Direction.CW);
        return g;
    }

    /** باني مسار يحوّل (u,v) إلى (x,y)؛ الانحناءات زوايا ربع دائرة بنقطة الزاوية */
    static final class PB {
        final Path path = new Path(); final boolean side; final float ox, oy; float cu, cv;
        PB(boolean side, float ox, float oy) { this.side = side; this.ox = ox; this.oy = oy; }
        float X(float u, float v) { return side ? ox + v : ox + u; }
        float Y(float u, float v) { return side ? oy + u : oy + v; }
        void m(float u, float v) { path.moveTo(X(u, v), Y(u, v)); cu = u; cv = v; }
        void l(float u, float v) { path.lineTo(X(u, v), Y(u, v)); cu = u; cv = v; }
        /** زاوية: من (u0,v0) عبر نقطة الزاوية (u1,v1) إلى (u2,v2) */
        void c(float u0, float v0, float u1, float v1, float u2, float v2) { c(u0, v0, u1, v1, u2, v2, false); }
        void c(float u0, float v0, float u1, float v1, float u2, float v2, boolean fromCur) {
            if (fromCur) { u0 = cu; v0 = cv; }
            float a1 = u0 + (u1 - u0) * KAP, b1 = v0 + (v1 - v0) * KAP, a2 = u2 + (u1 - u2) * KAP, b2 = v2 + (v1 - v2) * KAP;
            path.cubicTo(X(a1, b1), Y(a1, b1), X(a2, b2), Y(a2, b2), X(u2, v2), Y(u2, v2));
            cu = u2; cv = v2;
        }
    }

    // ── الخطوط والنصوص ──
    static Typeface tfT, tfA;
    static Typeface face(Context c, WidgetModel m) {
        try {
            if (tfT == null && Build.VERSION.SDK_INT >= 26) {
                tfT = c.getResources().getFont(c.getResources().getIdentifier("tajawal_bold", "font", c.getPackageName()));
                tfA = c.getResources().getFont(c.getResources().getIdentifier("amiri_bold", "font", c.getPackageName()));
            }
        } catch (Throwable ignored) {}
        if (m != null && m.sk && "serif".equals(m.font) && tfA != null) return tfA;
        if (m != null && m.sk && "condensed".equals(m.font)) return Typeface.create("sans-serif-condensed", Typeface.BOLD);
        return tfT != null ? tfT : Typeface.DEFAULT_BOLD;
    }

    static final int RIGHT = 0, CENTER = 1, LEFT = 2;

    /** نص في سطر واحد يُصغَّر ليتّسع، y = منتصف السطر */
    static void text(Canvas cv, Context c, WidgetModel m, String s, float x, float y, float size, int color, int align, boolean bold, float maxW) {
        if (s == null || s.isEmpty()) return;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
        p.setTypeface(face(c, m));
        float fs = size * (m.sk ? m.fsize : 1f);
        p.setTextSize(fs);
        boolean light = m.sk && "light".equals(m.weight);
        p.setFakeBoldText(bold && m.sk && "bold".equals(m.weight));
        if (light && !bold) color = WSkinArt.alpha(color, Math.round((color >>> 24) * .85f));
        while (maxW > 0 && fs > 6 && p.measureText(s) > maxW) { fs *= .93f; p.setTextSize(fs); }
        p.setColor(color);
        if (m.sk && m.tshadow) p.setShadowLayer(fs * .2f, 0, fs * .06f, 0x88000000);
        p.setTextAlign(align == RIGHT ? Paint.Align.RIGHT : align == LEFT ? Paint.Align.LEFT : Paint.Align.CENTER);
        Paint.FontMetrics fm = p.getFontMetrics();
        cv.drawText(s, x, y - (fm.ascent + fm.descent) / 2f, p);
    }

    static void prayerIcon(Canvas cv, String key, float cx, float cy, float size, int color, WidgetModel m) {
        boolean filled = m.sk && "fill".equals(m.iconStyle);
        float sc = m.sk ? m.iconSize : 1f;
        float u = size / 24f * Math.max(.6f, Math.min(1.3f, sc));
        cv.save();
        cv.translate(cx - 12 * u, cy - 12 * u);
        WidgetArt.drawIcon(cv, key, u, color, filled, 1.7f * u);
        cv.restore();
    }

    static final java.util.HashMap<String, String> WX = new java.util.HashMap<>();
    static {
        WX.put("sun", "M16 12a4 4 0 1 1-8 0a4 4 0 1 1 8 0M12 2.5v2M12 19.5v2M2.5 12h2M19.5 12h2M5.3 5.3l1.4 1.4M17.3 17.3l1.4 1.4M5.3 18.7l1.4-1.4M17.3 6.7l1.4-1.4");
        WX.put("moon", "M19.5 14.5A8 8 0 0 1 9.5 4.5a8 8 0 1 0 10 10z");
        WX.put("part", "M11.5 8.5a3 3 0 1 1-6 0a3 3 0 1 1 6 0M8.5 2.5v1.3M2.5 8.5h1.3M4.3 4.3l.9.9M12.7 4.3l-.9.9M8 20h9a3.5 3.5 0 0 0 .3-7 4.5 4.5 0 0 0-8.6 1.3A2.9 2.9 0 0 0 8 20z");
        WX.put("cloud", "M7 19h10a4 4 0 0 0 .4-8 5.5 5.5 0 0 0-10.6 1.6A3.3 3.3 0 0 0 7 19z");
        WX.put("fog", "M4 9h16M3 13h18M5 17h14");
        WX.put("rain", "M7 15h10a4 4 0 0 0 .4-8 5.5 5.5 0 0 0-10.6 1.6A3.3 3.3 0 0 0 7 15zM9 18l-1 2.5M13 18l-1 2.5M17 18l-1 2.5");
        WX.put("snow", "M7 14h10a4 4 0 0 0 .4-8 5.5 5.5 0 0 0-10.6 1.6A3.3 3.3 0 0 0 7 14zM9 18.5h.2M13 19.5h.2M17 18.5h.2M11 21h.2M15 21h.2");
        WX.put("storm", "M7 14h10a4 4 0 0 0 .4-8 5.5 5.5 0 0 0-10.6 1.6A3.3 3.3 0 0 0 7 14zM12.5 14l-2 3.5h3l-2 3.5");
    }

    /** نفس تصنيف التطبيق (wxKind) */
    static String wxKind(int c, boolean day) {
        if (c == 0) return day ? "sun" : "moon";
        if (c == 1 || c == 2) return day ? "part" : "cloud";
        if (c == 3) return "cloud";
        if (c == 45 || c == 48) return "fog";
        if ((c >= 71 && c <= 77) || c == 85 || c == 86) return "snow";
        if (c >= 95) return "storm";
        if (c >= 51 && c <= 82) return "rain";
        return day ? "part" : "cloud";
    }

    static void wxIcon(Canvas cv, String kind, float cx, float cy, float size, int color, WidgetModel m) {
        Path p = MyRender.svgPath(WX.containsKey(kind) ? WX.get(kind) : WX.get("cloud"));
        if (p == null) return;
        float u = size / 24f * (m.sk ? Math.max(.6f, Math.min(1.3f, m.iconSize)) : 1f);
        android.graphics.Matrix mx = new android.graphics.Matrix();
        mx.setScale(u, u); mx.postTranslate(cx - 12 * u, cy - 12 * u);
        p.transform(mx);
        Paint ic = new Paint(Paint.ANTI_ALIAS_FLAG);
        if (m.sk && "fill".equals(m.iconStyle) && !"fog".equals(kind)) { ic.setColor(WSkinArt.alpha(color, 0x55)); cv.drawPath(p, ic); }
        ic.setStyle(Paint.Style.STROKE); ic.setStrokeCap(Paint.Cap.ROUND); ic.setStrokeJoin(Paint.Join.ROUND);
        ic.setStrokeWidth(1.8f * u); ic.setColor(color);
        cv.drawPath(p, ic);
    }

    static String left(WidgetModel m) {
        long ms = Math.max(0, m.target - System.currentTimeMillis());
        long mins = (ms + 59999) / 60000, h = mins / 60, mi = mins % 60;
        String t = h > 0 ? h + " س " + mi + " د" : mi + " د";
        return (m.iqPhase ? "الإقامة بعد " : "بعد ") + t;
    }

    static final String[] DAYN = {"", "أحد", "اثنين", "ثلاثاء", "أربعاء", "خميس", "جمعة", "سبت"};

    // ── الرسم ──
    static Bitmap render(Context c, Bundle o, WidgetModel m, String kind) {
        float d = c.getResources().getDisplayMetrics().density;
        int defW = 330, defH = "pside".equals(kind) ? 150 : 165;
        int wdp = 0, hdp = 0;
        if (o != null) { wdp = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0); hdp = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0); }
        if (wdp <= 0) wdp = defW;
        if (hdp <= 0) hdp = defH;
        float k = d * Math.min(1f, 1000f / (Math.max(wdp, hdp) * d));
        int w = Math.max(60, (int) (wdp * k)), h = Math.max(60, (int) (hdp * k));
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        RectF r = WSkinArt.inner(w, h, k, m);
        float fw = m.sk && m.frameW > 0 ? Math.max(1f, m.frameW * k) : (m.sk ? 0 : 1f * k);
        r.inset(fw / 2f, fw / 2f);
        boolean side = "pside".equals(kind);
        float td, tl;
        if (side) { td = Math.min(46 * k, r.width() * .16f); tl = Math.min(r.height() * .52f, 96 * k); }
        else { td = Math.min(38 * k, r.height() * .25f); tl = Math.min(r.width() * ("wxweek".equals(kind) ? .3f : .3f), 130 * k); }
        Geo g = geo(r, k, m, side, tl, td);
        Path all = new Path(g.body);
        all.addPath(g.tab);
        // الظل الخارجي
        if (m.sk && m.shOut > 0 || !m.sk) {
            int sh = m.sk ? m.shOut : 14;
            Paint sp = new Paint(Paint.ANTI_ALIAS_FLAG);
            sp.setColor(WSkinArt.alpha(0xFF000000, (int) (255 * Math.min(.45f, sh / 160f) * Math.max(.35f, m.alpha / 100f))));
            sp.setMaskFilter(new BlurMaskFilter(Math.max(1f, sh / 3f * k * .6f), BlurMaskFilter.Blur.NORMAL));
            cv.save(); cv.translate(0, sh / 8f * k); cv.drawPath(all, sp); cv.restore();
        }
        cv.save();
        cv.clipPath(all);
        WSkinArt.paint(cv, new RectF(r), k, m, null);
        cv.restore();
        // الإطار
        Paint fp = new Paint(Paint.ANTI_ALIAS_FLAG);
        fp.setStyle(Paint.Style.STROKE);
        fp.setStrokeWidth(fw > 0 ? fw : 1f * k);
        fp.setColor(m.sk ? (m.frameW > 0 ? m.frame : 0) : WSkinArt.alpha(m.gold, 0x80));
        if (fp.getColor() != 0) { cv.drawPath(g.body, fp); cv.drawPath(g.tab, fp); }
        // الألوان
        int TX = m.sk ? m.text : 0xFFFFFFFF, T2 = m.sk ? m.text2 : 0xC8FFFFFF, AC = m.sk ? m.accent : WidgetArt.mix(m.gold, 0xFFFFFFFF, .15f), IC = m.sk ? m.icon : 0xFFFFFFFF;
        float pad = Math.max(10 * k, (m.sk ? m.pad : 14) * k * .85f);
        JSONObject day = m.day;
        if ("wxweek".equals(kind)) drawWx(c, cv, m, g, r, k, pad, TX, T2, AC, IC);
        else if (m.ok) { if (side) drawSide(c, cv, m, g, r, k, pad, TX, T2, AC, IC); else drawTop(c, cv, m, g, r, k, pad, TX, T2, AC, IC); }
        return b;
    }

    static String sh(JSONObject p) { return p == null ? "" : p.optString("sh", p.optString("s", "")); }

    /** صف الصلوات الست: اسم + أيقونة + وقت، والقادمة بارزة مع علامة صغيرة */
    static void prayerRow(Context c, Canvas cv, WidgetModel m, float x0, float x1, float y0, float y1, float k, int TX, int T2, int AC, int IC) {
        JSONArray it = m.items();
        if (it == null) return;
        int n = Math.min(6, it.length()), hl = m.iqPhase ? m.curIdx : m.nextIdx;
        float cw = (x1 - x0) / n, H = y1 - y0;
        float fsN = Math.min(11.5f * k, H * .2f), fsT = Math.min(13 * k, H * .23f), ic = Math.min(20 * k, H * .3f);
        for (int i = 0; i < n; i++) {
            JSONObject p = it.optJSONObject(i);
            boolean on = i == hl;
            float cx = x1 - cw * (i + .5f);
            text(cv, c, m, WidgetHub.nm(p), cx, y0 + H * .14f, fsN, on ? TX : T2, CENTER, on, cw * .96f);
            prayerIcon(cv, p == null ? "" : p.optString("k"), cx, y0 + H * .47f, ic, on ? AC : IC, m);
            text(cv, c, m, sh(p), cx, y0 + H * .8f, fsT, on ? TX : WSkinArt.alpha(TX, 0xE0), CENTER, on, cw * .96f);
            if (on) {
                Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
                tp.setColor(AC); tp.setStrokeWidth(Math.max(1.5f, 2 * k)); tp.setStrokeCap(Paint.Cap.ROUND);
                float yy = y0 + H * .97f;
                cv.drawLine(cx - cw * .14f, yy, cx + cw * .14f, yy, tp);
            }
        }
    }

    static void drawTop(Context c, Canvas cv, WidgetModel m, Geo g, RectF r, float k, float pad, int TX, int T2, int AC, int IC) {
        JSONObject sp = WidgetHub.shownPrayer(m), d = m.day;
        // اللسان: الوقت + الأيقونة
        RectF t = g.tabR;
        String tt = m.iqPhase ? (sp == null ? "" : sp.optString("iqsh", sp.optString("iqs", ""))) : sh(sp);
        float isz = t.height() * .56f;
        text(cv, c, m, tt, t.left + t.width() * .42f, t.centerY(), t.height() * .44f, TX, CENTER, true, t.width() * .6f);
        prayerIcon(cv, sp == null ? "" : sp.optString("k"), t.right - t.height() * .62f, t.centerY(), isz, IC, m);
        // الرأس
        float top = r.top + g.v0, colW = Math.max(40 * k, (r.right - pad) - (r.left + g.nEnd) + 4 * k);
        float y1 = top + Math.max(15 * k, pad * 1.25f), y2 = y1 + 16 * k;
        String date = d == null ? "" : (d.optString("wd") + " " + (d.optString("grd") + " " + d.optString("grm")).trim()).trim();
        String hij = d == null ? "" : (d.optString("hjd") + " " + d.optString("hjm") + " " + d.optString("hjy")).trim();
        text(cv, c, m, date, r.right - pad, y1, 12.5f * k, TX, RIGHT, true, colW);
        text(cv, c, m, hij, r.right - pad, y2, 10 * k, T2, RIGHT, false, colW);
        text(cv, c, m, (m.iqPhase ? "إقامة " : "") + WidgetHub.nm(sp), r.left + pad, y1, 15 * k, TX, LEFT, true, colW);
        text(cv, c, m, left(m), r.left + pad, y2, 10.5f * k, T2, LEFT, false, colW);
        float rowTop = Math.max(y2 + 14 * k, r.top + g.nDepth + 6 * k);
        prayerRow(c, cv, m, r.left + pad * .7f, r.right - pad * .7f, rowTop, r.bottom - pad * .55f, k, TX, T2, AC, IC);
    }

    static void drawSide(Context c, Canvas cv, WidgetModel m, Geo g, RectF r, float k, float pad, int TX, int T2, int AC, int IC) {
        JSONObject sp = WidgetHub.shownPrayer(m);
        RectF t = g.tabR;
        String tt = m.iqPhase ? (sp == null ? "" : sp.optString("iqsh", sp.optString("iqs", ""))) : sh(sp);
        prayerIcon(cv, sp == null ? "" : sp.optString("k"), t.centerX(), t.top + t.height() * .33f, t.width() * .6f, IC, m);
        text(cv, c, m, tt, t.centerX(), t.top + t.height() * .66f, t.width() * .3f, TX, CENTER, true, t.width() * .86f);
        float x0 = r.left + g.nDepth + 8 * k, x1 = r.right - pad;
        float H = r.height(), y = r.top + Math.max(pad * .9f, H * .1f);
        text(cv, c, m, m.iqPhase ? "وقت الإقامة" : "الصلاة القادمة", x1, y + 6 * k, 11 * k, T2, RIGHT, false, x1 - x0);
        text(cv, c, m, (m.iqPhase ? "إقامة " : "") + WidgetHub.nm(sp), x1, y + 6 * k + H * .17f, Math.min(24 * k, H * .19f), TX, RIGHT, true, x1 - x0);
        text(cv, c, m, left(m), x1, y + 6 * k + H * .31f, 10.5f * k, T2, RIGHT, false, x1 - x0);
        float rowTop = r.top + H * .5f;
        prayerRow(c, cv, m, x0 - 2 * k, x1 + pad * .3f, rowTop, r.bottom - pad * .55f, k, TX, T2, AC, IC);
    }

    static void drawWx(Context c, Canvas cv, WidgetModel m, Geo g, RectF r, float k, float pad, int TX, int T2, int AC, int IC) {
        JSONObject wx = null;
        try { wx = new JSONObject(AlarmScheduler.prefs(c).getString("wx", "{}")); } catch (Exception ignored) {}
        RectF t = g.tabR;
        boolean has = wx != null && wx.has("t");
        String temp = has ? Math.round(wx.optDouble("t")) + "°" : "—°";
        text(cv, c, m, temp, t.left + t.width() * .42f, t.centerY(), t.height() * .46f, TX, CENTER, true, t.width() * .55f);
        wxIcon(cv, has ? wxKind(wx.optInt("code", 1), wx.optInt("day", 1) == 1) : "cloud", t.right - t.height() * .62f, t.centerY(), t.height() * .6f, IC, m);
        JSONObject d = m.day;
        float top = r.top + g.v0, colW = Math.max(40 * k, (r.right - pad) - (r.left + g.nEnd) + 4 * k);
        float y1 = top + Math.max(15 * k, pad * 1.25f), y2 = y1 + 16 * k;
        java.util.Calendar now = java.util.Calendar.getInstance();
        String wd = d != null ? d.optString("wd") : new java.text.SimpleDateFormat("EEEE", new java.util.Locale("ar")).format(now.getTime());
        String gr = d != null ? (d.optString("grd") + " " + d.optString("grm")).trim() : new java.text.SimpleDateFormat("d MMMM", new java.util.Locale("ar")).format(now.getTime());
        text(cv, c, m, wd, r.right - pad, y1, 14 * k, TX, RIGHT, true, colW);
        text(cv, c, m, gr, r.right - pad, y2, 10.5f * k, T2, RIGHT, false, colW);
        if (d != null) {
            text(cv, c, m, (d.optString("hjd") + " " + d.optString("hjm")).trim(), r.left + pad, y1, 12.5f * k, TX, LEFT, false, colW);
            text(cv, c, m, d.optString("hjy"), r.left + pad, y2, 10.5f * k, T2, LEFT, false, colW);
        }
        // توقعات ٧ أيام (اليوم في أقصى اليمين)
        JSONArray days = wx == null ? null : wx.optJSONArray("daily");
        float x0 = r.left + pad * .6f, x1 = r.right - pad * .6f, rowTop = Math.max(y2 + 14 * k, r.top + g.nDepth + 6 * k), rowBot = r.bottom - pad * .5f, H = rowBot - rowTop;
        if (days == null || days.length() == 0) {
            text(cv, c, m, has ? "توقعات الأيام القادمة تظهر بعد التحديث التالي" : "يتطلب اتصالاً بالإنترنت لجلب الطقس", (x0 + x1) / 2f, rowTop + H / 2f, 11 * k, T2, CENTER, false, x1 - x0);
            return;
        }
        String todayIso = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(now.getTime());
        int start = 0;
        for (int i = 0; i < days.length(); i++) if (todayIso.equals(days.optJSONObject(i).optString("d"))) { start = i; break; }
        int n = Math.min(7, days.length() - start);
        float cw = (x1 - x0) / 7f;
        for (int j = 0; j < n; j++) {
            JSONObject o = days.optJSONObject(start + j);
            if (o == null) continue;
            float cx = x1 - cw * (j + .5f);
            String nm = "";
            try {
                java.util.Calendar cal = java.util.Calendar.getInstance();
                cal.setTime(new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).parse(o.optString("d")));
                nm = DAYN[cal.get(java.util.Calendar.DAY_OF_WEEK)];
            } catch (Exception ignored) {}
            boolean on = j == 0;
            text(cv, c, m, nm, cx, rowTop + H * .12f, Math.min(11 * k, H * .19f), on ? TX : T2, CENTER, on, cw * .98f);
            wxIcon(cv, wxKind(o.optInt("c", 1), true), cx, rowTop + H * .42f, Math.min(22 * k, H * .32f), on ? AC : IC, m);
            text(cv, c, m, Math.round(o.optDouble("mx")) + "°", cx, rowTop + H * .71f, Math.min(13 * k, H * .22f), TX, CENTER, true, cw);
            text(cv, c, m, Math.round(o.optDouble("mn")) + "°", cx, rowTop + H * .9f, Math.min(10 * k, H * .16f), T2, CENTER, false, cw);
        }
    }
}
