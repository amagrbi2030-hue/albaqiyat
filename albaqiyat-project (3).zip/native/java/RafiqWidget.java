package com.albaqiyat.app;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.os.Bundle;

/** أساس ويدجت «الرفيق اليومي»: تُرسم من مصدر البيانات الموحّد وتتكيّف مع الحجم */
public abstract class RafiqWidget extends AppWidgetProvider {
    protected abstract String kind();

    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        for (int id : ids) RafiqWidgets.render(c, m, id, kind());
        RafiqWidgets.scheduleRefresh(c);
    }

    @Override
    public void onAppWidgetOptionsChanged(Context c, AppWidgetManager m, int id, Bundle o) {
        RafiqWidgets.render(c, m, id, kind());
    }

    @Override
    public void onDeleted(Context c, int[] ids) {
        android.content.SharedPreferences.Editor e = RafiqEngine.p(c).edit();
        for (int id : ids) e.remove("pick_" + id);
        e.commit();
    }

    @Override
    public void onRestored(Context c, int[] oldIds, int[] newIds) {
        android.content.SharedPreferences p = RafiqEngine.p(c);
        android.content.SharedPreferences.Editor e = p.edit();
        for (int i = 0; i < oldIds.length && i < newIds.length; i++) { String v = p.getString("pick_" + oldIds[i], null); if (v != null) e.putString("pick_" + newIds[i], v).remove("pick_" + oldIds[i]); }
        e.commit();
    }
}
