package com.albaqiyat.app;

import android.app.Notification;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

/** خدمة أمامية خفيفة تحمل إشعار «الصلاة القادمة» الدائم.
 *  لا تستهلك المعالج (لا مؤقتات ولا قفل إيقاظ)؛ العدّ التنازلي يرسمه النظام،
 *  ووجودها يمنع نظام توفير الطاقة من إيقاف التطبيق وحذف منبّهات الأذان وإشعاره. */
public class StatusService extends Service {
    static volatile boolean running = false;

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Notification n = StatusNotice.build(this);
        if (n == null) { running = false; stopSelf(); return START_NOT_STICKY; }
        try {
            if (Build.VERSION.SDK_INT >= 34) startForeground(StatusNotice.NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            else startForeground(StatusNotice.NID, n);
            running = true;
            h.removeCallbacks(tick);
            if (StatusNotice.styled) h.postDelayed(tick, 60_000L);
        } catch (Exception e) {
            running = false;
            stopSelf();
            return START_NOT_STICKY;
        }
        // إعادة الجدولة احتياطاً كلما أعاد النظام تشغيل الخدمة بعد إيقافها
        if (intent == null) { try { AlarmScheduler.scheduleAll(this); } catch (Exception ignored) {} }
        return START_STICKY;
    }

    // تحديث شريط التقدّم في الإشعار المخصّص كل دقيقة (نفس الإشعار، دون إنشاء جديد).
    // Handler عادي بلا قفل إيقاظ: يتوقف تلقائياً أثناء سكون الهاتف فلا يستهلك البطارية.
    private final android.os.Handler h = new android.os.Handler(android.os.Looper.getMainLooper());
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!running) return;
            try { StatusNotice.update(StatusService.this); } catch (Exception ignored) {}
            if (running && StatusNotice.styled) h.postDelayed(this, "next".equals(StatusNotice.lastKind) ? 300_000L : 60_000L);
        }
    };

    @Override
    public void onDestroy() {
        h.removeCallbacks(tick);
        running = false;
        super.onDestroy();
    }
}
