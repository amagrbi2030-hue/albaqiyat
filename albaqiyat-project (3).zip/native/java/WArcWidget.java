package com.albaqiyat.app;

public class WArcWidget extends BaseWidget {
    @Override
    protected String kind() { return "arc"; }
}
