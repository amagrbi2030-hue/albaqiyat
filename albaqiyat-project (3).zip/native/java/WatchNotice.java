package com.albaqiyat.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import org.json.JSONObject;

/**
 * «تنبيه على الساعة الذكية»: إشعار عادي قصير (غير مستمر) عند الأذان والإقامة،
 * لأن تطبيقات الساعات (مثل Huawei Health) لا تنقل الإشعارات المستمرة المرتبطة بتشغيل الصوت.
 */
final class WatchNotice {
    private WatchNotice() {}
    static final String CH = "watch_alerts_v1";

    static boolean on(Context c) { return AlarmScheduler.prefs(c).getBoolean("watch", false); }

    static void prayer(Context c, JSONObject ev, String kind) {
        if (!on(c)) return;
        String name = ev.optString("name", "");
        if ("iqama".equals(kind)) post(c, 4801, "🕌 أقيمت صلاة " + name, "حان وقت إقامة صلاة " + name);
        else if ("adhan".equals(kind)) post(c, 4800, "🕌 حان الآن أذان " + name, (ev.optString("iqs", "").isEmpty() ? "" : "الإقامة الساعة " + ev.optString("iqs", "")).trim());
    }

    static boolean post(Context c, int id, String title, String body) {
        try {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return false;
            if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(CH) == null) {
                NotificationChannel ch = new NotificationChannel(CH, "تنبيهات الساعة الذكية", NotificationManager.IMPORTANCE_HIGH);
                ch.setDescription("إشعار قصير عند الأذان والإقامة لتنقله الساعة الذكية");
                ch.enableVibration(true);
                ch.setSound(null, null); // الصوت يبقى للأذان على الهاتف
                nm.createNotificationChannel(ch);
            }
            if (Build.VERSION.SDK_INT >= 24 && !nm.areNotificationsEnabled()) return false;
            Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, CH) : new Notification.Builder(c);
            int icon = c.getResources().getIdentifier("ic_stat_salah", "drawable", c.getPackageName());
            b.setSmallIcon(icon != 0 ? icon : android.R.drawable.ic_popup_reminder).setContentTitle(title).setContentText(body)
             .setAutoCancel(true).setCategory(Notification.CATEGORY_REMINDER).setWhen(System.currentTimeMillis()).setShowWhen(true)
             .setTimeoutAfter(Build.VERSION.SDK_INT >= 26 ? 20 * 60 * 1000L : 0);
            if (Build.VERSION.SDK_INT < 26) b.setPriority(Notification.PRIORITY_HIGH).setVibrate(new long[]{0, 300, 200, 300});
            Intent li = c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
            if (li != null) b.setContentIntent(PendingIntent.getActivity(c, id, li, AlarmScheduler.piFlags()));
            nm.notify(id, b.build());
            return true;
        } catch (Exception e) { return false; }
    }
}
