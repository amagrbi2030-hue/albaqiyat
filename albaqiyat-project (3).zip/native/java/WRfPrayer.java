package com.albaqiyat.app;

public class WRfPrayer extends RafiqWidget {
    @Override
    protected String kind() { return "rprayer"; }
}
