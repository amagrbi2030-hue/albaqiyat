package com.albaqiyat.app;

public class WTasbih42 extends TasbihWidget {
    @Override
    protected String kind() { return "tb42"; }
}
