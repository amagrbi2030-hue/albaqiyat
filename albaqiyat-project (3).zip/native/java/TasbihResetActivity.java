package com.albaqiyat.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.appwidget.AppWidgetManager;
import android.os.Bundle;

/** تأكيد تصفير عدّاد الويدجت (زر بعيد عن منطقة التسبيح + نافذة تأكيد) */
public class TasbihResetActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        final int id = getIntent().getIntExtra("id", -1);
        if (id < 0) { finish(); return; }
        org.json.JSONObject o = TasbihStore.cfg(this, id);
        String t = o == null ? "" : TasbihStore.text(this, TasbihStore.current(o));
        int n = o == null ? 0 : TasbihStore.count(o, TasbihStore.current(o));
        AlertDialog d = new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("تصفير العدّاد؟")
            .setMessage("سيُصفَّر عدّاد «" + t + "» الحالي (" + n + ").\nالإحصائيات والسجل التاريخي لا تتأثر.")
            .setPositiveButton("تصفير", (x, w) -> {
                TasbihStore.reset(this, id);
                TasbihRender.render(this, AppWidgetManager.getInstance(this), id, TasbihRender.kindOf(this, id));
            })
            .setNegativeButton("إلغاء", null)
            .create();
        d.setOnDismissListener(x -> finish());
        d.show();
    }
}
