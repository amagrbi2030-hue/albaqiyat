package com.albaqiyat.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import org.json.JSONObject;

/**
 * شاشة الأذان/الإقامة الكاملة خارج التطبيق.
 * التصميم يُقرأ من إعدادات «تخصيص البطاقة» (prefs: acard) التي يرسلها التطبيق بألوان محسوبة مسبقاً لكل نمط،
 * فتطابق الشاشة هنا معاينة التطبيق: ١٠ أنماط، خلفية لكل صلاة (مكتبة أو صورة خاصة)، زجاج ضبابي، إطار، خط، مؤقت.
 */
public class AdhanActivity extends Activity {
    private final Handler h = new Handler(Looper.getMainLooper());
    private AudioManager am;
    private SeekBar vol;
    private Button stopBtn;
    private String kind = "adhan";
    private JSONObject ev = new JSONObject(), cfg = new JSONObject();
    // الألوان والقياسات الحالية
    private int C1 = 0xFF0F5132, C2 = 0xFF06281B, ACC = 0xFFF3D98B, INK = Color.WHITE, SUB = 0xD1FFFFFF;
    private boolean LIGHT = false;
    private float Z = 1f;
    private Typeface face = Typeface.DEFAULT_BOLD;
    // المؤقت
    private long fromAt = 0, toAt = 0, iqAt = 0;
    private TextView badge, statusTv, cdTv, cdSub, timeTv;
    private TimerView timer;
    private boolean ringTimer = true, keep = false;
    private String styleId = "float", lay = "float", pk = "glass", base = "";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        }
        Window w = getWindow();
        w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 21) {
            w.setStatusBarColor(Color.TRANSPARENT);
            w.setNavigationBarColor(Color.TRANSPARENT);
            w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }
        setVolumeControlStream(AudioManager.STREAM_ALARM);
        am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        build(getIntent());
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        seenPlaying = false; stopped = false; idleSince = 0; openedAt = android.os.SystemClock.elapsedRealtime();
        setIntent(i);
        build(i);
    }

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    static int color(String s, int def) {
        try { return s == null || s.isEmpty() ? def : parse(s); } catch (Exception e) { return def; }
    }

    /** يدعم #RRGGBB و rgba(r,g,b,a) */
    static int parse(String s) {
        s = s.trim();
        if (s.startsWith("rgba")) {
            String[] p = s.substring(s.indexOf('(') + 1, s.indexOf(')')).split(",");
            return Color.argb(Math.round(Float.parseFloat(p[3].trim()) * 255), Integer.parseInt(p[0].trim()), Integer.parseInt(p[1].trim()), Integer.parseInt(p[2].trim()));
        }
        return Color.parseColor(s);
    }

    static int alpha(int c, int a) { return (c & 0x00FFFFFF) | (Math.max(0, Math.min(255, a)) << 24); }

    static int mix(int a, int b, float t) {
        return Color.argb(255, (int) (Color.red(a) + (Color.red(b) - Color.red(a)) * t), (int) (Color.green(a) + (Color.green(b) - Color.green(a)) * t), (int) (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t));
    }

    private static int[] sky(String p) {
        switch (p) {
            case "fajr": return new int[]{0xFF0B1E3F, 0xFF3B3F78, 0xFFC97B8E};
            case "dhuhr": return new int[]{0xFF1C5C8C, 0xFF4E95C2, 0xFFE9D9A6};
            case "asr": return new int[]{0xFF6E4A1E, 0xFFC38A3A, 0xFFF1D592};
            case "maghrib": return new int[]{0xFF2B1640, 0xFFB24A3A, 0xFFF0A35E};
            default: return new int[]{0xFF050B1A, 0xFF0D2340, 0xFF1F3B5C};
        }
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp * Z);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        t.setTypeface(bold ? face : Typeface.create(face, Typeface.NORMAL));
        if (!LIGHT) t.setShadowLayer(dp(5), 0, dp(1), 0x99000000);
        return t;
    }

    private GradientDrawable round(int fill, int stroke, float radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radius));
        if (stroke != 0) g.setStroke(dp(1.2f), stroke);
        return g;
    }

    private Typeface font(String id) {
        int rid = 0;
        if ("amiri".equals(id)) rid = R.font.amiri_bold;
        else if ("plex".equals(id)) rid = R.font.plex_bold;
        else rid = R.font.tajawal_bold;
        try { if (Build.VERSION.SDK_INT >= 26) return getResources().getFont(rid); } catch (Exception ignored) {}
        return Typeface.DEFAULT_BOLD;
    }

    /** خلفية الصلاة: صورة خاصة، أو صورة من المكتبة، أو لا شيء */
    private Bitmap loadBg(String prayer) {
        JSONObject bg = cfg.optJSONObject("bg");
        String sel = bg == null ? prayer : bg.optString(prayer, prayer);
        if ("none".equals(sel)) return null;
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        int maxSide = Math.max(dm.widthPixels, dm.heightPixels);
        if ("custom".equals(sel)) {
            java.io.File f = new java.io.File(getFilesDir(), "acard_" + prayer + ".jpg");
            if (f.exists()) {
                try {
                    BitmapFactory.Options o = new BitmapFactory.Options();
                    o.inJustDecodeBounds = true;
                    BitmapFactory.decodeFile(f.getAbsolutePath(), o);
                    int s = 1;
                    while (Math.max(o.outWidth, o.outHeight) / (s * 2) >= maxSide) s *= 2;
                    o = new BitmapFactory.Options(); o.inSampleSize = s;
                    Bitmap b = BitmapFactory.decodeFile(f.getAbsolutePath(), o);
                    if (b != null) return b;
                } catch (Exception ignored) {}
            }
            sel = prayer;
        }
        int rid = getResources().getIdentifier("photo_" + sel, "drawable", getPackageName());
        if (rid == 0) rid = getResources().getIdentifier("bg_" + sel, "drawable", getPackageName());
        if (rid == 0) return null;
        try { return BitmapFactory.decodeResource(getResources(), rid); } catch (Exception e) { return null; }
    }

    private void loadStyle(String prayer) {
        try { cfg = new JSONObject(AlarmScheduler.prefs(this).getString("acard", "{}")); } catch (Exception e) { cfg = new JSONObject(); }
        styleId = cfg.optString("style", "float");
        if (cfg.optBoolean("autoNight", false) && ("isha".equals(prayer) || "fajr".equals(prayer))) styleId = "night";
        JSONObject L = cfg.optJSONObject("lay");
        JSONObject l = L == null ? null : L.optJSONObject(styleId);
        lay = l == null ? "float" : l.optString("lay", "float");
        pk = l == null ? "glass" : l.optString("pk", "glass");
        base = l == null ? "" : l.optString("base", "");
        JSONObject P = cfg.optJSONObject("pal");
        JSONObject p = P == null ? null : P.optJSONObject(styleId);
        if (p != null) {
            C1 = color(p.optString("c1"), C1); C2 = color(p.optString("c2"), C2); ACC = color(p.optString("acc"), ACC);
            INK = color(p.optString("ink"), INK); SUB = color(p.optString("sub"), SUB); LIGHT = p.optBoolean("light", false);
        } else { // لم يُحفظ تصميم بعد: الشكل الافتراضي (زجاج عائم بلون زمردي)
            C1 = 0xFF0F5132; C2 = 0xFF06281B; ACC = 0xFFF3D98B; INK = Color.WHITE; SUB = 0xD1FFFFFF; LIGHT = false;
        }
        Z = (float) cfg.optDouble("size", 1.0);
        if (Z < 0.8f || Z > 1.3f) Z = 1f;
        face = font(cfg.optString("font", "ui"));
        ringTimer = !"bar".equals(cfg.optString("timer", "ring"));
        keep = cfg.optBoolean("keep", false);
    }

    private void build(Intent in) {
        try { ev = new JSONObject(in.getStringExtra("ev") == null ? "{}" : in.getStringExtra("ev")); }
        catch (Exception e) { ev = new JSONObject(); }
        final String prayer = ev.optString("prayer", "fajr");
        kind = ev.optString("kind", "adhan");
        loadStyle(prayer);
        long at = ev.optLong("at", System.currentTimeMillis());
        iqAt = ev.optLong("iq", 0);
        if ("pre".equals(kind)) { fromAt = at; toAt = ev.optLong("adhanAt", 0); }
        else if ("adhan".equals(kind) && iqAt > 0) { fromAt = at; toAt = iqAt; }
        else if ("iqama".equals(kind)) { fromAt = at; toAt = at; iqAt = at; }
        else { fromAt = 0; toAt = 0; }

        final FrameLayout root = new FrameLayout(this);
        if (Build.VERSION.SDK_INT >= 17) root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        boolean plain = "plain".equals(lay);
        final Bitmap photo = plain ? null : loadBg(prayer);

        // ── الخلفية ──
        final ImageView bg = new ImageView(this);
        bg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        if (photo != null) bg.setImageBitmap(photo);
        else if (plain) bg.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{C1, C2}));
        else bg.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, sky(prayer)));
        if ("night".equals(base)) bg.setColorFilter(0x66000000);
        root.addView(bg, new FrameLayout.LayoutParams(-1, -1));
        if (!plain) {
            View shade = new View(this);
            int[] sh = "cinema".equals(lay) ? new int[]{0x40000000, 0x00000000, 0x59000000, 0xE0000000}
                    : "night".equals(base) ? new int[]{alpha(C2, 0xE0), alpha(C1, 0x73), alpha(C2, 0xD9)}
                    : new int[]{0x6B000000, 0x1F000000, 0x38000000, 0x9E000000};
            shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, sh));
            root.addView(shade, new FrameLayout.LayoutParams(-1, -1));
            if ("night".equals(base)) root.addView(new StarsView(this, ACC), new FrameLayout.LayoutParams(-1, -1));
        }

        final LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        root.addView(main, new FrameLayout.LayoutParams(-1, -1));
        // مناطق الأمان (شريط الحالة والتنقل والحواف)
        if (Build.VERSION.SDK_INT >= 20) {
            main.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
                public WindowInsets onApplyWindowInsets(View v, WindowInsets ins) {
                    v.setPadding(ins.getSystemWindowInsetLeft(), ins.getSystemWindowInsetTop(), ins.getSystemWindowInsetRight(), ins.getSystemWindowInsetBottom());
                    return ins;
                }
            });
        }

        if ("panel".equals(lay) && photo != null) {
            final FrameLayout box = new FrameLayout(this);
            final ImageView ph = new ImageView(this);
            ph.setImageBitmap(photo);
            ph.setScaleType(ImageView.ScaleType.FIT_CENTER);
            ph.setAdjustViewBounds(true);
            ph.setPadding(dp(4), dp(4), dp(4), dp(4));
            ph.setBackground(round(0x26FFFFFF, 0x80FFFFFF, 16));
            if (Build.VERSION.SDK_INT >= 21) ph.setElevation(dp(10));
            box.addView(ph, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
            box.post(new Runnable() { public void run() { ph.setMaxWidth(box.getWidth()); ph.setMaxHeight(box.getHeight()); ph.requestLayout(); } });
            LinearLayout.LayoutParams lph = new LinearLayout.LayoutParams(-1, 0, 1f);
            lph.setMargins(dp(16), dp(20), dp(16), dp(6));
            main.addView(box, lph);
        } else {
            main.addView(new View(this), new LinearLayout.LayoutParams(-1, 0, 1f));
        }

        // ── اللوح ──
        final FrameLayout panel = new FrameLayout(this);
        final ImageView frost = new ImageView(this);
        frost.setScaleType(ImageView.ScaleType.FIT_XY);
        boolean glassy = "glass".equals(pk) && photo != null;
        if (glassy) panel.addView(frost, new FrameLayout.LayoutParams(-1, -1));
        final PanelDrawable pd = new PanelDrawable();
        View deco = new View(this);
        deco.setBackground(pd);
        panel.addView(deco, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        boolean arch = "arch".equals(pk);
        col.setPadding(dp(18), dp(arch ? 40 : 18), dp(18), dp(18));
        panel.addView(col, new FrameLayout.LayoutParams(-1, -2));
        LinearLayout.LayoutParams lpan = new LinearLayout.LayoutParams(-1, -2);
        int side = "cinema".equals(lay) ? 6 : 14;
        lpan.setMargins(dp(side), dp(6), dp(side), dp("float".equals(lay) || "plain".equals(lay) ? 6 : 16));
        main.addView(panel, lpan);
        if (!"panel".equals(lay) && !"cinema".equals(lay)) main.addView(new View(this), new LinearLayout.LayoutParams(-1, 0, 1f));
        if (Build.VERSION.SDK_INT >= 21) {
            panel.setOutlineProvider(new ViewOutlineProvider() {
                public void getOutline(View v, Outline o) {
                    if ("arch".equals(pk)) { try { o.setConvexPath(panelShape(v.getWidth(), v.getHeight(), dp(22), true)); return; } catch (Exception ignored) {} }
                    o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), dp(26));
                }
            });
            panel.setClipToOutline(true);
            if (!"cinema".equals(lay)) panel.setElevation(dp(8));
        }
        // الزجاج الضبابي: نسخة مموّهة من جزء الخلفية الواقع خلف اللوح
        if (glassy) {
            panel.postDelayed(new Runnable() { public void run() { frost(root, bg, panel, frost); } }, 60);
        }

        // ── المحتوى ──
        String label = badgeText(System.currentTimeMillis());
        badge = text("✦  " + label + "  ✦", 14, LIGHT ? mix(ACC, 0xFF000000, 0.2f) : ACC, true);
        badge.setBackground(round(LIGHT ? alpha(ACC, 0x22) : alpha(C2, 0x80), alpha(ACC, 0xC0), 99));
        badge.setPadding(dp(16), dp(7), dp(16), dp(7));
        LinearLayout.LayoutParams lpb = new LinearLayout.LayoutParams(-2, -2);
        lpb.bottomMargin = dp(6);
        col.addView(badge, lpb);

        TextView nm = text("صلاة " + ev.optString("name", ""), "cinema".equals(lay) ? 40 : 34, INK, true);
        col.addView(nm);
        String t0 = "iqama".equals(kind) ? ev.optString("time", "") : ev.optString("time", "");
        timeTv = text(t0, 24, ACC, true);
        col.addView(timeTv);

        String city = ev.optString("city", "");
        StringBuilder meta = new StringBuilder();
        if (!city.isEmpty()) meta.append("📍 ").append(city);
        String hj = ev.optString("hj", ""), gr = ev.optString("gr", "");
        if (!hj.isEmpty() || !gr.isEmpty()) meta.append("\n").append(hj).append(hj.isEmpty() || gr.isEmpty() ? "" : "  ·  ").append(gr);
        if (meta.length() > 0) {
            TextView mt = text(meta.toString(), 12.5f, SUB, false);
            mt.setLineSpacing(dp(2), 1f);
            LinearLayout.LayoutParams lm = new LinearLayout.LayoutParams(-2, -2);
            lm.topMargin = dp(4);
            col.addView(mt, lm);
        }
        String who = ev.optString("who", "");
        if (!who.isEmpty()) {
            TextView wt = text(("iqama".equals(kind) ? "الإقامة: " : "المؤذن: ") + who, 12.5f, SUB, false);
            LinearLayout.LayoutParams lw = new LinearLayout.LayoutParams(-2, -2);
            lw.topMargin = dp(2);
            col.addView(wt, lw);
        }
        statusTv = text("", 12.5f, SUB, true);
        statusTv.setBackground(round(alpha(INK, 0x16), 0, 99));
        statusTv.setPadding(dp(12), dp(4), dp(12), dp(4));
        LinearLayout.LayoutParams ls = new LinearLayout.LayoutParams(-2, -2);
        ls.topMargin = dp(8);
        col.addView(statusTv, ls);
        if ("pre".equals(kind)) {
            TextView pm = text("اقتربت الصلاة، الرجاء الاستعداد", 16, INK, true);
            LinearLayout.LayoutParams lpm = new LinearLayout.LayoutParams(-2, -2);
            lpm.topMargin = dp(8);
            col.addView(pm, lpm);
        }

        // ── المؤقت ──
        timer = null; cdTv = null; cdSub = null;
        if (toAt > 0) {
            if (ringTimer) {
                FrameLayout rf = new FrameLayout(this);
                timer = new TimerView(this, true);
                rf.addView(timer, new FrameLayout.LayoutParams(-1, -1));
                LinearLayout rt = new LinearLayout(this);
                rt.setOrientation(LinearLayout.VERTICAL);
                rt.setGravity(Gravity.CENTER);
                cdTv = text("", 21, INK, true);
                cdSub = text("", 10.5f, SUB, false);
                rt.addView(cdTv); rt.addView(cdSub);
                rf.addView(rt, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
                LinearLayout.LayoutParams lr = new LinearLayout.LayoutParams(dp(112 * Z), dp(112 * Z));
                lr.topMargin = dp(10);
                col.addView(rf, lr);
            } else {
                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                cdTv = text("", 21, INK, true);
                cdSub = text("", 11, SUB, false);
                row.addView(cdTv, new LinearLayout.LayoutParams(-2, -2));
                View sp = new View(this);
                row.addView(sp, new LinearLayout.LayoutParams(0, 1, 1f));
                row.addView(cdSub, new LinearLayout.LayoutParams(-2, -2));
                LinearLayout.LayoutParams lr = new LinearLayout.LayoutParams(-1, -2);
                lr.topMargin = dp(10);
                col.addView(row, lr);
                timer = new TimerView(this, false);
                LinearLayout.LayoutParams lb2 = new LinearLayout.LayoutParams(-1, dp(9));
                lb2.topMargin = dp(6);
                col.addView(timer, lb2);
            }
        }

        // ── ذكر/فضل موثّق ──
        if (cfg.optBoolean("fadl", true)) {
            JSONObject dk = cfg.optJSONObject("dhikr");
            String key = "iqama".equals(kind) ? "iqama" : ("adhan".equals(kind) ? "adhan" : "adhan");
            org.json.JSONArray a = dk == null ? null : dk.optJSONArray(key);
            String ftx = a != null ? a.optString(0, "") : ev.optString("fadl", "");
            String fsr = a != null ? a.optString(1, "") : ev.optString("fsrc", "");
            if (!ftx.isEmpty() && !"pre".equals(kind)) {
                LinearLayout card = new LinearLayout(this);
                card.setOrientation(LinearLayout.VERTICAL);
                card.setBackground(round(alpha(INK, 0x14), alpha(ACC, 0x66), 18));
                card.setPadding(dp(14), dp(10), dp(14), dp(10));
                TextView ft = text(ftx, 14, INK, false);
                try { if (Build.VERSION.SDK_INT >= 26) ft.setTypeface(getResources().getFont(R.font.amiri_bold)); } catch (Exception ignored) {}
                ft.setLineSpacing(dp(3), 1f);
                card.addView(ft, new LinearLayout.LayoutParams(-1, -2));
                if (!fsr.isEmpty()) {
                    TextView fsv = text(fsr, 10.5f, SUB, false);
                    LinearLayout.LayoutParams lfs = new LinearLayout.LayoutParams(-1, -2);
                    lfs.topMargin = dp(3);
                    card.addView(fsv, lfs);
                }
                LinearLayout.LayoutParams lc0 = new LinearLayout.LayoutParams(-1, -2);
                lc0.topMargin = dp(10);
                col.addView(card, lc0);
            }
        }

        // ── مستوى الصوت ──
        LinearLayout vrow = new LinearLayout(this);
        vrow.setOrientation(LinearLayout.HORIZONTAL);
        vrow.setGravity(Gravity.CENTER_VERTICAL);
        vrow.setBackground(round(alpha(INK, 0x1A), alpha(INK, 0x4D), 22));
        vrow.setPadding(dp(8), dp(4), dp(8), dp(4));
        Button minus = smallBtn("−");
        Button plus = smallBtn("+");
        vol = new SeekBar(this);
        final int max = am != null ? am.getStreamMaxVolume(AudioManager.STREAM_ALARM) : 7;
        vol.setMax(max);
        vol.setContentDescription("مستوى صوت الأذان");
        if (am != null) vol.setProgress(am.getStreamVolume(AudioManager.STREAM_ALARM));
        vol.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean user) {
                if (user && am != null) am.setStreamVolume(AudioManager.STREAM_ALARM, p, 0);
            }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });
        minus.setContentDescription("خفض الصوت");
        plus.setContentDescription("رفع الصوت");
        minus.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { adjust(AudioManager.ADJUST_LOWER); } });
        plus.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { adjust(AudioManager.ADJUST_RAISE); } });
        vrow.addView(plus, new LinearLayout.LayoutParams(dp(40), dp(40)));
        vrow.addView(vol, new LinearLayout.LayoutParams(0, -2, 1));
        vrow.addView(minus, new LinearLayout.LayoutParams(dp(40), dp(40)));
        LinearLayout.LayoutParams lv2 = new LinearLayout.LayoutParams(-1, -2);
        lv2.topMargin = dp(12);
        col.addView(vrow, lv2);

        // ── الأزرار ──
        stopBtn = new Button(this);
        stopBtn.setText("pre".equals(kind) ? "حسناً" : ("iqama".equals(kind) ? "إيقاف الإقامة" : "إيقاف الأذان"));
        stopBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        stopBtn.setTypeface(face);
        stopBtn.setAllCaps(false);
        GradientDrawable gold;
        if (LIGHT) { gold = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{mix(ACC, 0xFF000000, 0.1f), mix(ACC, 0xFF000000, 0.4f)}); stopBtn.setTextColor(Color.WHITE); }
        else { gold = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{mix(ACC, 0xFF000000, 0.25f), ACC, mix(ACC, 0xFFFFFFFF, 0.25f)}); stopBtn.setTextColor(0xFF2A1C04); }
        gold.setCornerRadius(dp(99));
        stopBtn.setBackground(gold);
        stopBtn.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { stopAndClose(); } });
        LinearLayout.LayoutParams lb = new LinearLayout.LayoutParams(-1, dp(50));
        lb.topMargin = dp(10);
        col.addView(stopBtn, lb);

        Button close = new Button(this);
        close.setText("إغلاق البطاقة");
        close.setAllCaps(false);
        close.setTypeface(face);
        close.setTextColor(INK);
        close.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        close.setBackground(round(alpha(INK, 0x1A), alpha(INK, 0x66), 99));
        close.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { finish(); } });
        LinearLayout.LayoutParams lc = new LinearLayout.LayoutParams(-1, dp(44));
        lc.topMargin = dp(8);
        col.addView(close, lc);

        // دخول ناعم
        panel.setAlpha(0f);
        panel.setTranslationY(dp(18));
        panel.animate().alpha(1f).translationY(0).setDuration(520).start();

        setContentView(root);
        updateTimer();
        h.removeCallbacksAndMessages(null);
        h.post(tick);
    }

    private String badgeText(long now) {
        if ("pre".equals(kind)) return "بعد ١٠ دقائق يحين الأذان";
        if ("iqama".equals(kind)) return "حان وقت الإقامة";
        // الأذان: لا تظهر «حان وقت الإقامة» إلا إذا حلّ وقتها فعلاً
        if (iqAt > 0 && now >= iqAt) return "حان وقت الإقامة";
        if (iqAt > 0 && (now - fromAt > 60000 && !AdhanService.isPlaying())) return "الإقامة بعد";
        return "حان الآن وقت الأذان";
    }

    private static String ar(String s) {
        StringBuilder b = new StringBuilder();
        for (char c : s.toCharArray()) b.append(c >= '0' && c <= '9' ? (char) ('٠' + (c - '0')) : c);
        return b.toString();
    }

    private void updateTimer() {
        long now = System.currentTimeMillis();
        if (badge != null) badge.setText("✦  " + badgeText(now) + "  ✦");
        String st;
        if ("pre".equals(kind)) st = "قبل الأذان";
        else if ("iqama".equals(kind) || (iqAt > 0 && now >= iqAt)) st = "وقت الإقامة";
        else if (iqAt > 0) st = (now - fromAt < 60000 ? "وقت الأذان · الإقامة " : "بين الأذان والإقامة · الإقامة ") + ev.optString("iqs", "");
        else st = "وقت الأذان";
        if (statusTv != null) statusTv.setText(st);
        if (timer == null) return;
        boolean done = now >= toAt;
        float frac = toAt > fromAt ? Math.max(0f, Math.min(1f, (now - fromAt) / (float) (toAt - fromAt))) : 1f;
        timer.set(done ? 1f : frac);
        if (cdTv != null) {
            if (done) { cdTv.setText("pre".equals(kind) ? "الآن" : "✓"); cdSub.setText("pre".equals(kind) ? "حان الأذان" : "حان وقت الإقامة"); }
            else {
                long s = (toAt - now + 999) / 1000, m = s / 60;
                cdTv.setText(ar(m + ":" + (s % 60 < 10 ? "0" : "") + (s % 60)));
                cdSub.setText("pre".equals(kind) ? "حتى الأذان" : (ringTimer ? "حتى الإقامة" : "حتى الإقامة · " + ev.optString("iqs", "")));
            }
        }
    }

    /** يقصّ جزء الخلفية خلف اللوح ويموّهه (RenderEffect في أندرويد 12+، وتصغير/تكبير خفيف فيما قبله) */
    private void frost(View root, ImageView bg, View panel, ImageView out) {
        try {
            int w = panel.getWidth(), hh = panel.getHeight();
            if (w <= 0 || hh <= 0 || bg.getDrawable() == null) return;
            int[] pr = new int[2], br = new int[2];
            panel.getLocationInWindow(pr); bg.getLocationInWindow(br);
            pr[0] -= (int) panel.getTranslationX(); pr[1] -= (int) panel.getTranslationY();
            float sc = 0.25f;
            Bitmap b = Bitmap.createBitmap(Math.max(1, (int) (w * sc)), Math.max(1, (int) (hh * sc)), Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(b);
            c.scale(sc, sc);
            c.translate(br[0] - pr[0], br[1] - pr[1]);
            Matrix m = bg.getImageMatrix();
            if (m != null) c.concat(m);
            bg.getDrawable().draw(c);
            if (Build.VERSION.SDK_INT >= 31) {
                out.setImageBitmap(b);
                out.setRenderEffect(android.graphics.RenderEffect.createBlurEffect(dp(5), dp(5), Shader.TileMode.CLAMP));
            } else {
                Bitmap s1 = Bitmap.createScaledBitmap(b, Math.max(1, b.getWidth() / 6), Math.max(1, b.getHeight() / 6), true);
                Bitmap s2 = Bitmap.createScaledBitmap(s1, Math.max(1, s1.getWidth() / 2), Math.max(1, s1.getHeight() / 2), true);
                out.setImageBitmap(Bitmap.createScaledBitmap(s2, b.getWidth(), b.getHeight(), true));
            }
        } catch (Throwable ignored) {}
    }

    /** رسم اللوح: الشكل (مستطيل/محراب) + التعبئة (زجاج/لون/مخطوطة/نقش) + النقوش + الإطار */
    private class PanelDrawable extends Drawable {
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);


        @Override
        public void draw(Canvas c) {
            Rect b = getBounds();
            int w = b.width(), hh = b.height();
            if (w <= 0 || hh <= 0) return;
            float r = dp(26);
            boolean arch = "arch".equals(pk);
            Path sh = shape(w, hh, r, arch);
            int ga = (int) (cfg.optInt("glass", 30) * 2.55f);
            p.setStyle(Paint.Style.FILL);
            p.setShader(null);
            if ("parchment".equals(pk)) {
                JSONObject P = cfg.optJSONObject("pal");
                JSONObject pp = P == null ? null : P.optJSONObject(styleId);
                int p1 = color(pp == null ? "" : pp.optString("p1"), 0xFFFBF4E2), p2 = color(pp == null ? "" : pp.optString("p2"), 0xFFEAD9B2);
                p.setShader(new RadialGradient(w / 2f, 0, Math.max(w, hh) * 1.1f, alpha(p1, ga), alpha(p2, ga), Shader.TileMode.CLAMP));
                c.drawPath(sh, p);
            } else if ("glass".equals(pk)) {
                p.setShader(new LinearGradient(0, 0, w * 0.3f, hh, alpha(C1, ga), alpha(C2, ga), Shader.TileMode.CLAMP));
                c.drawPath(sh, p);
                p.setShader(new LinearGradient(0, 0, 0, hh * 0.55f, 0x29FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
                c.drawPath(sh, p);
            } else if (!"none".equals(pk)) { // solid / arch / emboss / plain
                p.setShader(new LinearGradient(0, 0, w * 0.3f, hh, alpha(C1, ga), alpha(C2, ga), Shader.TileMode.CLAMP));
                c.drawPath(sh, p);
            }
            p.setShader(null);
            // النقوش الهندسية
            boolean pat = cfg.optBoolean("pattern", true) && !"cinema".equals(lay);
            if (pat) {
                c.save();
                c.clipPath(sh);
                Paint sp = new Paint(Paint.ANTI_ALIAS_FLAG);
                sp.setStyle(Paint.Style.STROKE);
                sp.setStrokeWidth(Math.max(1f, dp(0.9f)));
                float step = dp(46);
                boolean emb = "emboss".equals(pk);
                for (int pass = 0; pass < (emb ? 2 : 1); pass++) {
                    if (emb) { sp.setColor(pass == 0 ? 0x40000000 : 0x2EFFFFFF); c.translate(pass == 0 ? dp(1) : -dp(2), pass == 0 ? dp(1) : -dp(2)); }
                    else sp.setColor(alpha(ACC, LIGHT ? 0x2A : 0x24));
                    for (float y = 0; y < hh + step; y += step)
                        for (float x = ((int) (y / step) % 2) * step / 2; x < w + step; x += step)
                            c.drawPath(WidgetArt.star8(x, y, step * 0.34f), sp);
                }
                c.restore();
            }
            if ("emboss".equals(pk)) {
                Paint e = new Paint(Paint.ANTI_ALIAS_FLAG);
                e.setStyle(Paint.Style.STROKE);
                e.setStrokeWidth(dp(3));
                e.setShader(new LinearGradient(0, 0, 0, hh, 0x40FFFFFF, 0x59000000, Shader.TileMode.CLAMP));
                c.drawPath(sh, e);
            }
            // الإطار
            String fr = "cinema".equals(lay) ? "none" : cfg.optString("frame", "glass");
            if ("gold".equals(fr)) {
                Paint f = new Paint(Paint.ANTI_ALIAS_FLAG);
                f.setStyle(Paint.Style.STROKE);
                f.setStrokeWidth(dp(1.3f));
                f.setColor(alpha(ACC, 0xD9));
                c.drawPath(shape(w, hh, r, arch, dp(0.7f)), f);
                f.setStrokeWidth(dp(0.8f));
                f.setColor(alpha(ACC, 0x66));
                c.drawPath(shape(w, hh, r - dp(6), arch, dp(6.5f)), f);
            } else if ("glass".equals(fr)) {
                Paint f = new Paint(Paint.ANTI_ALIAS_FLAG);
                f.setStyle(Paint.Style.STROKE);
                f.setStrokeWidth(dp(1));
                f.setColor(LIGHT ? alpha(INK, 0x40) : 0x73FFFFFF);
                c.drawPath(shape(w, hh, r, arch, dp(0.5f)), f);
            }
        }

        Path shape(int w, int hh, float r, boolean arch, float inset) {
            Path p0 = panelShape((int) (w - 2 * inset), (int) (hh - 2 * inset), Math.max(0, r), arch);
            p0.offset(inset, inset);
            return p0;
        }

        Path shape(int w, int hh, float r, boolean arch) { return panelShape(w, hh, r, arch); }

        @Override public void setAlpha(int a) {}
        @Override public void setColorFilter(ColorFilter cf) {}
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    static Path panelShape(int w, int hh, float r, boolean arch) {
            Path p0 = new Path();
            if (!arch) { p0.addRoundRect(new RectF(0, 0, w, hh), r, r, Path.Direction.CW); return p0; }
            float ah = Math.min(hh * 0.22f, w * 0.42f); // ارتفاع قوس المحراب
            p0.moveTo(0, hh - r);
            p0.lineTo(0, ah);
            p0.cubicTo(0, ah * 0.35f, w * 0.28f, 0, w / 2f, 0);
            p0.cubicTo(w * 0.72f, 0, w, ah * 0.35f, w, ah);
            p0.lineTo(w, hh - r);
            p0.quadTo(w, hh, w - r, hh);
            p0.lineTo(r, hh);
            p0.quadTo(0, hh, 0, hh - r);
            p0.close();
            return p0;
    }

    /** مؤقت الإقامة: حلقة أو شريط، يُحسب من الساعة الحقيقية في كل تحديث */
    private class TimerView extends View {
        final boolean ring;
        float frac = 0f;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        TimerView(Context c, boolean ring) { super(c); this.ring = ring; }

        void set(float f) { if (Math.abs(f - frac) > 0.0005f) { frac = f; invalidate(); } }

        @Override
        protected void onDraw(Canvas c) {
            int w = getWidth(), hh = getHeight();
            if (ring) {
                float sw = dp(6), rr = Math.min(w, hh) / 2f - sw;
                RectF o = new RectF(w / 2f - rr, hh / 2f - rr, w / 2f + rr, hh / 2f + rr);
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(sw); p.setStrokeCap(Paint.Cap.ROUND);
                p.setColor(alpha(INK, 0x29)); c.drawArc(o, 0, 360, false, p);
                p.setColor(ACC); c.drawArc(o, -90, 360 * frac, false, p);
            } else {
                p.setStyle(Paint.Style.FILL);
                p.setColor(alpha(INK, 0x29));
                c.drawRoundRect(new RectF(0, 0, w, hh), hh / 2f, hh / 2f, p);
                p.setColor(ACC);
                float fw = Math.max(hh, w * frac);
                c.drawRoundRect(new RectF(w - fw, 0, w, hh), hh / 2f, hh / 2f, p); // يمتلئ من اليمين
            }
        }
    }

    /** نجوم وهلال «ليالي الحرمين» */
    private static class StarsView extends View {
        final int acc;
        StarsView(Context c, int acc) { super(c); this.acc = acc; }
        @Override
        protected void onDraw(Canvas c) {
            int w = getWidth(), hh = getHeight();
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            java.util.Random r = new java.util.Random(11);
            float d = getResources().getDisplayMetrics().density;
            for (int i = 0; i < 70; i++) {
                p.setColor(alpha(0xFFFFFFFF, 70 + r.nextInt(150)));
                c.drawCircle(r.nextFloat() * w, r.nextFloat() * hh * 0.5f, (0.5f + r.nextFloat()) * d, p);
            }
            float R = 18 * d, cx = w - 46 * d, cy = 70 * d;
            Path m = new Path(); m.addCircle(cx, cy, R, Path.Direction.CW);
            Path cut = new Path(); cut.addCircle(cx + R * 0.45f, cy - R * 0.2f, R * 0.88f, Path.Direction.CW);
            if (Build.VERSION.SDK_INT >= 19) m.op(cut, Path.Op.DIFFERENCE);
            p.setColor(alpha(acc, 0xE0));
            c.drawPath(m, p);
        }
    }

    private Button smallBtn(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 21);
        b.setTextColor(LIGHT ? mix(ACC, 0xFF000000, 0.2f) : ACC);
        b.setPadding(0, 0, 0, 0);
        b.setBackground(round(alpha(INK, 0x1A), alpha(ACC, 0x99), 99));
        return b;
    }

    private void adjust(int dir) {
        if (am == null) return;
        am.adjustStreamVolume(AudioManager.STREAM_ALARM, dir, AudioManager.FLAG_SHOW_UI);
        if (vol != null) vol.setProgress(am.getStreamVolume(AudioManager.STREAM_ALARM));
    }

    private boolean seenPlaying = false;
    private long idleSince = 0, openedAt = android.os.SystemClock.elapsedRealtime();
    private final Runnable tick = new Runnable() {
        public void run() {
            if (am != null && vol != null) vol.setProgress(am.getStreamVolume(AudioManager.STREAM_ALARM));
            boolean pl = AdhanService.isPlaying();
            if (pl) seenPlaying = true;
            if (stopBtn != null && !pl) stopBtn.setText("إغلاق");
            updateTimer();
            long now = System.currentTimeMillis();
            long age = android.os.SystemClock.elapsedRealtime() - openedAt;
            // «إبقاء البطاقة حتى الإقامة»: تبقى بعد الأذان عدّاداً للإقامة، وتُغلق بعد دقيقة من حلول وقتها
            boolean holding = keep && "adhan".equals(kind) && iqAt > 0 && now < iqAt + 60000;
            // عند انتهاء الأذان أو الإقامة أو تنبيه ما قبل الأذان تُغلق البطاقة تلقائياً
            if (!holding && ((seenPlaying && !pl) || (!seenPlaying && age > 45000))) {
                if (idleSince == 0) idleSince = android.os.SystemClock.elapsedRealtime();
                else if (android.os.SystemClock.elapsedRealtime() - idleSince > 1800) { finish(); return; }
            } else idleSince = 0;
            h.postDelayed(this, 500);
        }
    };

    private boolean stopped = false;

    private void stopAndClose() {
        if (stopped || (!AdhanService.isPlaying() && seenPlaying)) { finish(); return; }
        stopped = true;
        try {
            Intent s = new Intent(this, AdhanService.class);
            s.setAction("STOP");
            startService(s);
        } catch (Exception ignored) {}
        if (keep && "adhan".equals(kind) && iqAt > System.currentTimeMillis()) { // يبقى عدّاد الإقامة ظاهراً
            if (stopBtn != null) stopBtn.setText("إغلاق");
            seenPlaying = true;
            return;
        }
        finish();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateTimer(); // بعد العودة للواجهة يُعاد الحساب من الساعة الحقيقية
    }

    @Override
    protected void onDestroy() {
        h.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
