package com.albaqiyat.app;

public class WWxweekWidget extends BaseWidget {
    @Override
    protected String kind() { return "wxweek"; }
}
