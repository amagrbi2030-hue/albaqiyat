package com.albaqiyat.app;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.os.Bundle;

/** أساس ويدجت «مسبحة بلمسة»: كل نسخة لها إعدادات وعدّاد مستقلان (حسب رقم الويدجت) */
public abstract class TasbihWidget extends AppWidgetProvider {
    protected abstract String kind();

    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        for (int id : ids) TasbihRender.render(c, m, id, kind());
    }

    @Override
    public void onAppWidgetOptionsChanged(Context c, AppWidgetManager m, int id, Bundle o) {
        TasbihRender.render(c, m, id, kind()); // تغيير الحجم يغيّر التخطيط
    }

    @Override
    public void onDeleted(Context c, int[] ids) {
        for (int id : ids) TasbihStore.remove(c, id); // السجل التاريخي يبقى
    }

    @Override
    public void onRestored(Context c, int[] oldIds, int[] newIds) {
        // بعد استعادة نسخة احتياطية: نقل إعدادات كل نسخة لرقمها الجديد
        for (int i = 0; i < oldIds.length && i < newIds.length; i++) {
            org.json.JSONObject o = TasbihStore.cfg(c, oldIds[i]);
            if (o != null) { TasbihStore.save(c, newIds[i], o); TasbihStore.remove(c, oldIds[i]); }
        }
    }
}
