package com.albaqiyat.app;

public class WTasbih1 extends TasbihWidget {
    @Override
    protected String kind() { return "tb1"; }
}
