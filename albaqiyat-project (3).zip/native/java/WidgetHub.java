package com.albaqiyat.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.StyleSpan;
import android.text.style.TypefaceSpan;
import android.util.TypedValue;
import android.view.View;
import android.widget.RemoteViews;
import android.graphics.Bitmap;
import org.json.JSONArray;
import org.json.JSONObject;

/** رسم جميع أشكال ودجت أوقات الصلاة */
public class WidgetHub {
    static final String ACTION_MUTE = "com.albaqiyat.app.WIDGET_MUTE";
    static final String ACTION_ARC_MODE = "com.albaqiyat.app.WIDGET_ARC_MODE";
    static final Class<?>[] CLS = {PrayerWidget.class, WNextWidget.class, WCrescentWidget.class, WTimelineWidget.class,
            WMosqueWidget.class, WGlassWidget.class, WMinimalWidget.class,
            WDayWidget.class, WSkyWidget.class, WMihrabWidget.class, WGlassdayWidget.class, WSunWidget.class, WDualWidget.class,
            WPlineWidget.class, WDaynightWidget.class, WFulldayWidget.class, WWeatherWidget.class, WThreeWidget.class, WRoyalWidget.class, WCalliWidget.class, WTodayWidget.class, WRingsWidget.class, WCalli3Widget.class, WPillsWidget.class, WGclockWidget.class, WArcWidget.class, WWxweekWidget.class, WPtopWidget.class, WPsideWidget.class, WAsmaWidget.class};
    static final String[] KINDS = {"full", "next", "crescent", "timeline", "mosque", "glass", "minimal",
            "day", "sky", "mihrab", "glassday", "sun", "dual", "pline", "daynight", "fullday", "weather", "three", "royal", "calli", "today", "rings", "calli3", "pills", "gclock", "arc", "wxweek", "ptop", "pside", "asma"};
    static final int[] NOW = {R.id.w_now0, R.id.w_now1, R.id.w_now2, R.id.w_now3, R.id.w_now4};

    static final int[] CELL = {R.id.w_c0, R.id.w_c1, R.id.w_c2, R.id.w_c3, R.id.w_c4, R.id.w_c5};
    static final int[] NAME = {R.id.w_n0, R.id.w_n1, R.id.w_n2, R.id.w_n3, R.id.w_n4, R.id.w_n5};
    static final int[] TIME = {R.id.w_t0, R.id.w_t1, R.id.w_t2, R.id.w_t3, R.id.w_t4, R.id.w_t5};
    static final int[] DOT = {R.id.w_d0, R.id.w_d1, R.id.w_d2, R.id.w_d3, R.id.w_d4, R.id.w_d5};
    // ألوان الرسم الحالية: افتراضية، أو من «نظام المظاهر» لكل ويدجت (تُضبط في render)
    static int GOLD_TXT = 0xFFF3D98B, WHITE = 0xFFFFFFFF, SOFT = 0xBFFFFFFF, DIM = 0x80FFFFFF, ICON = 0xFFFFFFFF;
    static WidgetModel CUR = null;
    static final int[] CD6 = {R.id.w_cd0, R.id.w_cd1, R.id.w_cd2, R.id.w_cd3, R.id.w_cd4, R.id.w_cd5};
    static final int[] PB = {R.id.w_pb0, R.id.w_pb1, R.id.w_pb2, R.id.w_pb3, R.id.w_pb4, R.id.w_pb5};
    static final int[] PI = {R.id.w_pi0, R.id.w_pi1, R.id.w_pi2, R.id.w_pi3, R.id.w_pi4, R.id.w_pi5};
    static final int[] PC = {R.id.w_pc0, R.id.w_pc1, R.id.w_pc2, R.id.w_pc3, R.id.w_pc4, R.id.w_pc5};

    static int al(int c, int a) { return (c & 0x00FFFFFF) | (a << 24); }

    static void skinColors(WidgetModel m) {
        CUR = m;
        if (m.sk) { WHITE = m.text; SOFT = m.text2; GOLD_TXT = m.accent; DIM = al(m.text, 0x80); ICON = m.icon; }
        else { WHITE = 0xFFFFFFFF; SOFT = 0xBFFFFFFF; GOLD_TXT = 0xFFF3D98B; DIM = 0x80FFFFFF; ICON = 0xFFFFFFFF; }
        WidgetArt.TRACK = al(WHITE, 0x33);
        WidgetArt.RING_TXT = WHITE;
    }

    /** نص بخط المظهر ووزنه */
    static CharSequence span(String s) {
        WidgetModel m = CUR;
        if (s == null) s = "";
        if (m == null || !m.sk || s.isEmpty()) return s;
        String fam = "serif".equals(m.font) ? "serif" : "condensed".equals(m.font) ? "sans-serif-condensed" : "sans-serif";
        if ("light".equals(m.weight)) fam = "serif".equals(m.font) ? "serif" : fam + "-light";
        else if ("normal".equals(m.weight) && !"serif".equals(m.font)) fam = fam + ("sans-serif".equals(fam) ? "-medium" : "");
        SpannableString sp = new SpannableString(s);
        sp.setSpan(new TypefaceSpan(fam), 0, s.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        if ("bold".equals(m.weight)) sp.setSpan(new StyleSpan(Typeface.BOLD), 0, s.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        return sp;
    }

    /** إنشاء التصميم وتطبيق المظهر على كل نصوصه وخلفياته (من الجدول المولّد WSkinIds) */
    static RemoteViews rv(Context c, WidgetModel m, int layout) {
        RemoteViews v = new RemoteViews(c.getPackageName(), layout);
        if (m == null || !m.sk) return v;
        float dpx = c.getResources().getDisplayMetrics().density;
        int pad = Math.round(m.pad * dpx);
        v.setViewPadding(R.id.w_content, pad, pad, pad, pad);
        Object[] T;
        try { T = WSkinIds.of(c.getResources().getResourceEntryName(layout)); } catch (Exception e) { T = null; }
        if (T == null) return v;
        int[][] rows = (int[][]) T[0];
        String[] tx = (String[]) T[1];
        for (int i = 0; i < rows.length; i++) {
            int[] r = rows[i];
            int id = r[0], cls = r[1], sp10 = r[2], fl = r[3], a = r[4], bg = r[5];
            if (cls <= 2) {
                v.setTextColor(id, cls == 0 ? m.text : cls == 1 ? m.text2 : m.accent);
                if ((fl & 1) == 0 && sp10 > 0 && Math.abs(m.fsize - 1f) > 0.01f) v.setTextViewTextSize(id, TypedValue.COMPLEX_UNIT_SP, sp10 / 10f * m.fsize);
                if ((fl & 8) != 0 && tx[i] != null) v.setTextViewText(id, span(tx[i]));
                if ((fl & 2) != 0 && m.clock24 && id == R.id.w_clock) { v.setCharSequence(id, "setFormat12Hour", "H:mm"); v.setCharSequence(id, "setFormat24Hour", "H:mm"); }
            } else if (cls == 3) tint(v, id, bgColor(bg, m));
            else if (cls == 4) v.setInt(id, "setBackgroundColor", al(m.text, Math.max(0x20, a)));
        }
        return v;
    }

    static int bgColor(int res, WidgetModel m) {
        if (res == R.drawable.w_hl || res == R.drawable.w_pill_line || res == R.drawable.w_dot_next) return m.accent;
        return m.text;
    }

    static void tint(RemoteViews v, int id, int color) {
        if (Build.VERSION.SDK_INT >= 31) v.setColorStateList(id, "setBackgroundTintList", ColorStateList.valueOf(color | 0xFF000000));
    }

    static void bgRes(RemoteViews v, int id, int res) {
        v.setInt(id, "setBackgroundResource", res);
        if (CUR != null && CUR.sk) tint(v, id, bgColor(res, CUR));
    }

    static void dotRes(RemoteViews v, int id, int res) {
        v.setImageViewResource(id, res);
        if (CUR != null && CUR.sk) v.setInt(id, "setColorFilter", res == R.drawable.w_dot_next ? CUR.accent : res == R.drawable.w_dot_cur ? CUR.text : al(CUR.text, res == R.drawable.w_dot_past ? 0x80 : 0x55));
    }

    static void prog(RemoteViews v, int id) {
        if (CUR != null && CUR.sk && Build.VERSION.SDK_INT >= 31) {
            v.setColorStateList(id, "setProgressTintList", ColorStateList.valueOf(CUR.accent));
            v.setColorStateList(id, "setProgressBackgroundTintList", ColorStateList.valueOf(al(CUR.text, 0x40)));
        }
    }

    static boolean any(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        for (Class<?> k : CLS) {
            int[] ids = m.getAppWidgetIds(new ComponentName(c, k));
            if (ids != null && ids.length > 0) return true;
        }
        return false;
    }

    static void updateAll(Context c) {
        renderAllOnly(c);
        try { WeatherFetcher.maybeFetch(c); } catch (Exception ignored) {}
    }

    static void renderAllOnly(Context c) {
        try {
            AppWidgetManager m = AppWidgetManager.getInstance(c);
            for (int i = 0; i < CLS.length; i++) {
                int[] ids = m.getAppWidgetIds(new ComponentName(c, CLS[i]));
                if (ids == null) continue;
                for (int id : ids) render(c, m, id, KINDS[i]);
            }
        } catch (Exception ignored) {}
        AlarmScheduler.scheduleWidgetTick(c);
        scheduleMinute(c);
        try { MyWidgets.updateAll(c); } catch (Throwable ignored) {}
    }

    static String nm(JSONObject o) { return o == null ? "" : o.optString("name", ""); }
    static String tm(JSONObject o) { return o == null ? "" : o.optString("s", ""); }
    static String tmShort(JSONObject o) { return o == null ? "" : o.optString("sh", o.optString("s", "")); }

    /** الصلوات الخمس من عناصر اليوم (دون الشروق) مع مواضعها الأصلية */
    static int[] five(JSONArray it) {
        int[] r = new int[5];
        int j = 0;
        if (it != null) for (int i = 0; i < it.length() && j < 5; i++) {
            JSONObject o = it.optJSONObject(i);
            if (o != null && !"sunrise".equals(o.optString("k"))) r[j++] = i;
        }
        for (; j < 5; j++) r[j] = -1;
        return r;
    }

    static void countdown(RemoteViews v, WidgetModel m) {
        if (Build.VERSION.SDK_INT >= 24 && m.ok) {
            v.setViewVisibility(R.id.w_cd, View.VISIBLE);
            v.setChronometer(R.id.w_cd, SystemClock.elapsedRealtime() + (m.target - System.currentTimeMillis()), null, true);
            v.setChronometerCountDown(R.id.w_cd, true);
        } else {
            v.setViewVisibility(R.id.w_cd, View.GONE);
        }
    }

    static PendingIntent openApp(Context c) {
        Intent li = c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
        if (li == null) li = new Intent(c, MainActivity.class);
        return PendingIntent.getActivity(c, 0, li, AlarmScheduler.piFlags());
    }

    static PendingIntent mute(Context c) {
        Intent i = new Intent(c, PrayerWidget.class);
        i.setAction(ACTION_MUTE);
        return PendingIntent.getBroadcast(c, 99002, i, AlarmScheduler.piFlags());
    }

    static void render(Context c, AppWidgetManager mgr, int id, String kind) {
        try {
            WidgetModel m = WidgetModel.load(c, kind);
            skinColors(m);
            Bundle opts = mgr.getAppWidgetOptions(id);
            RemoteViews v;
            switch (kind) {
                case "next": v = next(c, m, opts); break;
                case "crescent": v = crescent(c, m, opts); break;
                case "timeline": v = timeline(c, m, opts); break;
                case "mosque": v = mosque(c, m, opts); break;
                case "glass": v = glass(c, m, opts); break;
                case "minimal": v = minimal(c, m, opts); break;
                case "calli": v = calli(c, m, opts); break;
                case "today": v = today(c, m, opts); break;
                case "rings": v = rings(c, m, opts); break;
                case "calli3": v = calli3(c, m, opts); break;
                case "pills": v = pills(c, m, opts); break;
                case "gclock": v = gclock(c, m, opts); break;
                case "arc": v = arc(c, m, opts); break;
                case "wxweek": case "ptop": case "pside": v = notch(c, m, opts, kind); break;
                case "asma": v = asma(c, m, opts); break;
                case "day": case "sky": case "mihrab": case "glassday": case "sun": case "dual":
                case "pline": case "daynight": case "fullday": case "weather": case "three": case "royal":
                    v = generic(c, m, opts, kind); break;
                default: v = full(c, m, opts);
            }
            v.setOnClickPendingIntent(R.id.w_root, openApp(c));
            if (!m.ok && !"wxweek".equals(kind) && !"asma".equals(kind)) {
                v.setViewVisibility(R.id.w_content, View.GONE);
                v.setViewVisibility(R.id.w_empty, View.VISIBLE);
            } else {
                v.setViewVisibility(R.id.w_content, View.VISIBLE);
                v.setViewVisibility(R.id.w_empty, View.GONE);
            }
            mgr.updateAppWidget(id, v);
        } catch (Exception ignored) {}
    }

    /** الساعة النجمية: ساعة كبيرة حيّة + عمود التاريخ بالخط العربي + الصلوات الخمس، بألوان الثيم */
    static RemoteViews calli(Context c, WidgetModel m, Bundle o) {
        RemoteViews v = rv(c, m, R.layout.widget_calli);
        v.setImageViewBitmap(R.id.w_bg, WidgetArt.starBg(c, o, 320, 170, m));
        if (!m.ok) return v;
        JSONObject d = m.day;
        v.setImageViewBitmap(R.id.w_cal, WidgetArt.calliColumn(c, d == null ? "" : d.optString("wd"),
                d == null ? "" : d.optString("grd"), d == null ? "" : d.optString("grm"),
                d == null ? "" : d.optString("hjd"), d == null ? "" : d.optString("hjm")));
        JSONArray it = d == null ? null : d.optJSONArray("items");
        int[] f = five(it);
        for (int i = 0; i < 5; i++) {
            JSONObject p = (it != null && f[i] >= 0) ? it.optJSONObject(f[i]) : null;
            t(v, NAME[i], nm(p));
            t(v, TIME[i], tmShort(p));
            boolean nx = f[i] >= 0 && f[i] == m.nextIdx && !m.iqPhase;
            boolean cu = f[i] >= 0 && f[i] == m.curIdx && m.iqPhase;
            bgRes(v, TIME[i], (nx || cu) ? R.drawable.w_pill_line : R.drawable.w_none);
            v.setTextColor(NAME[i], (nx || cu) ? WHITE : al(WHITE, 0xD9));
        }
        return v;
    }

    /** حالة اليوم: الساعة واليوم والتاريخ + الطقس + الصلاة القادمة + البطارية + ما مرّ من اليوم */
    static RemoteViews today(Context c, WidgetModel m, Bundle o) {
        RemoteViews v = rv(c, m, R.layout.widget_today);
        int acc = m.sk ? m.accent : WidgetArt.mix(m.gold, 0xFFFFFFFF, 0.15f);
        v.setImageViewBitmap(R.id.w_bg, WidgetArt.todayBg(c, o, m));
        v.setTextColor(R.id.w_ampm, acc);
        v.setTextColor(R.id.w_time, acc);
        // البطارية
        int bat = -1;
        try {
            android.os.BatteryManager bm = (android.os.BatteryManager) c.getSystemService(Context.BATTERY_SERVICE);
            if (bm != null) bat = bm.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY);
        } catch (Exception ignored) {}
        t(v, R.id.w_bat, bat >= 0 ? bat + "%" : "—");
        v.setImageViewBitmap(R.id.w_bar2, WidgetArt.bar(Math.max(0, bat) / 100f, acc));
        // ما مرّ من اليوم
        java.util.Calendar cal = java.util.Calendar.getInstance();
        float dayFrac = (cal.get(java.util.Calendar.HOUR_OF_DAY) * 60 + cal.get(java.util.Calendar.MINUTE)) / 1440f;
        v.setImageViewBitmap(R.id.w_ring, WidgetArt.ring(dayFrac, acc));
        // الطقس
        t(v, R.id.w_wemoji, m.wx ? m.wemoji : "☁️");
        t(v, R.id.w_temp, m.wx ? m.temp : "—");
        t(v, R.id.w_wdesc, m.wx ? m.wdesc : "لا يوجد اتصال");
        if (!m.ok) return v;
        JSONObject d = m.day;
        if (d != null) {
            t(v, R.id.w_day, d.optString("wd"));
            t(v, R.id.w_date, (d.optString("grd") + " " + d.optString("grm")).trim() + "  |  " + (d.optString("hjd") + " " + d.optString("hjm")).trim());
        }
        JSONObject sp = m.iqPhase ? m.cur : m.next;
        t(v, R.id.w_lbl, m.iqPhase ? "الإقامة بعد" : "الصلاة القادمة");
        t(v, R.id.w_name, nm(sp));
        t(v, R.id.w_time, m.iqPhase ? (sp == null ? "" : sp.optString("iqs")) : tm(sp));
        if (Build.VERSION.SDK_INT >= 24) {
            v.setChronometer(R.id.w_cd, SystemClock.elapsedRealtime() + (m.target - System.currentTimeMillis()), "بعد %s", true);
            v.setChronometerCountDown(R.id.w_cd, true);
        }
        long span = Math.max(1, m.target - m.fromAt);
        float pr = Math.max(0f, Math.min(1f, (System.currentTimeMillis() - m.fromAt) / (float) span));
        v.setImageViewBitmap(R.id.w_bar1, WidgetArt.bar(pr, acc));
        return v;
    }

    static final int[] RING = {R.id.w_r0, R.id.w_r1, R.id.w_r2, R.id.w_r3, R.id.w_r4};

    /** الصلوات الخمس — حلقات: حلقة لكل صلاة (مكتملة/تمتلئ/قادمة) + الصلاة القادمة والمتبقي */
    static RemoteViews rings(Context c, WidgetModel m, Bundle o) {
        RemoteViews v = rv(c, m, R.layout.widget_rings);
        v.setImageViewBitmap(R.id.w_bg, m.sk ? WidgetArt.skinPlain(c, o, 320, 170, m, false) : WidgetArt.bg(c, o, 320, 170, WidgetArt.THEME, m, null, false));
        if (!m.ok) return v;
        int acc = m.sk ? m.accent : 0xFFFFFFFF;
        boolean filled = m.sk && "fill".equals(m.iconStyle);
        float isz = m.sk ? m.iconSize : 1f;
        JSONArray it = m.items();
        int[] f = five(it);
        long now = System.currentTimeMillis();
        float pr = m.progress() / 1000f;
        int hl = m.iqPhase ? m.curIdx : m.nextIdx;
        for (int j = 0; j < 5; j++) {
            JSONObject p = (it != null && f[j] >= 0) ? it.optJSONObject(f[j]) : null;
            t(v, NAME[j], nm(p));
            t(v, TIME[j], tmShort(p));
            boolean on = f[j] >= 0 && f[j] == hl;
            String st = on ? "next" : (p != null && p.optLong("at") <= now ? "past" : "up");
            v.setImageViewBitmap(RING[j], WidgetArt.prayerRing(p == null ? "" : p.optString("k"), pr, st, acc, WHITE, ICON, filled, isz));
            v.setTextColor(NAME[j], on ? WHITE : al(WHITE, 0xB3));
            v.setTextColor(TIME[j], on ? WHITE : al(WHITE, 0xB3));
        }
        JSONObject sp = shownPrayer(m);
        t(v, R.id.w_name, (m.iqPhase ? "إقامة " : "") + nm(sp) + " " + (m.iqPhase ? (sp == null ? "" : sp.optString("iqsh", sp.optString("iqs", ""))) : tmShort(sp)));
        t(v, R.id.w_lbl, m.iqPhase ? "وقت الإقامة" : "الصلاة القادمة");
        t(v, R.id.w_cdl, m.iqPhase ? "الإقامة بعد" : "المتبقي");
        if (Build.VERSION.SDK_INT >= 24) {
            v.setChronometer(R.id.w_cd, SystemClock.elapsedRealtime() + (m.target - System.currentTimeMillis()), null, true);
            v.setChronometerCountDown(R.id.w_cd, true);
        }
        v.setImageViewBitmap(R.id.w_ricon, WidgetArt.prayerRing(sp == null ? "" : sp.optString("k"), pr, "next", acc, WHITE, ICON, filled, isz));
        return v;
    }


    static Bitmap plainBg(Context c, Bundle o, int w, int h, WidgetModel m, int style) {
        return m.sk ? WidgetArt.skinPlain(c, o, w, h, m, false) : WidgetArt.bg(c, o, w, h, style, m, null, false);
    }

    static int onAccent(int acc) { return WSkinArt.luminance(acc) > .4 ? 0xFF151515 : 0xFFFFFFFF; }

    /** التقويم بالخط العربي: الشهر الميلادي | اليوم | الشهر الهجري + الصلوات الست، والقادمة بإطار وعدّاد */
    static RemoteViews calli3(Context c, WidgetModel m, Bundle o) {
        RemoteViews v = rv(c, m, R.layout.widget_calli3);
        v.setImageViewBitmap(R.id.w_bg, plainBg(c, o, 320, 170, m, WidgetArt.THEME));
        v.setInt(R.id.w_div, "setBackgroundColor", al(WHITE, 0x40));
        if (!m.ok) return v;
        JSONObject d = m.day;
        v.setImageViewBitmap(R.id.w_cal, WidgetArt.calliRow(c, d == null ? "" : d.optString("grm"), d == null ? "" : d.optString("wd"), d == null ? "" : d.optString("hjm"), WHITE));
        JSONArray it = m.items();
        int hl = m.iqPhase ? m.curIdx : m.nextIdx;
        for (int i = 0; i < 6; i++) {
            JSONObject p = it != null && i < it.length() ? it.optJSONObject(i) : null;
            t(v, NAME[i], nm(p));
            t(v, TIME[i], tmShort(p));
            boolean on = i == hl;
            v.setTextColor(NAME[i], on ? WHITE : SOFT);
            v.setTextColor(TIME[i], WHITE);
            bgRes(v, TIME[i], on ? R.drawable.w_pill_line : R.drawable.w_none);
            if (on && Build.VERSION.SDK_INT >= 24) {
                v.setViewVisibility(CD6[i], View.VISIBLE);
                v.setChronometer(CD6[i], SystemClock.elapsedRealtime() + (m.target - System.currentTimeMillis()), m.iqPhase ? "الإقامة %s" : "بعد %s", true);
                v.setChronometerCountDown(CD6[i], true);
                v.setTextColor(CD6[i], SOFT);
            } else v.setViewVisibility(CD6[i], View.GONE);
        }
        return v;
    }

    /** كبسولات الصلاة الزجاجية: كبسولة لكل صلاة (مع الشروق) وأيقونتها، والقادمة دائرتها مضيئة */
    static RemoteViews pills(Context c, WidgetModel m, Bundle o) {
        RemoteViews v = rv(c, m, R.layout.widget_pills);
        v.setImageViewBitmap(R.id.w_bg, plainBg(c, o, 330, 150, m, WidgetArt.GLASS));
        v.setImageViewBitmap(R.id.w_inner, WidgetArt.innerPanel(WHITE, m.sk ? m.radius : 24));
        if (!m.ok) return v;
        boolean filled = m.sk && "fill".equals(m.iconStyle);
        float isz = m.sk ? m.iconSize : 1f;
        Bitmap pOff = WidgetArt.pill(WHITE, false, GOLD_TXT), pOn = WidgetArt.pill(WHITE, true, GOLD_TXT);
        Bitmap cOff = WidgetArt.pillCircle(WHITE, false, GOLD_TXT), cOn = WidgetArt.pillCircle(WHITE, true, GOLD_TXT);
        int onTxt = onAccent(GOLD_TXT);
        JSONArray it = m.items();
        int hl = m.iqPhase ? m.curIdx : m.nextIdx;
        for (int i = 0; i < 6; i++) {
            JSONObject p = it != null && i < it.length() ? it.optJSONObject(i) : null;
            boolean on = i == hl;
            t(v, NAME[i], nm(p));
            t(v, TIME[i], tmShort(p));
            v.setTextColor(NAME[i], on ? onTxt : WHITE);
            v.setTextColor(TIME[i], on ? onTxt : SOFT);
            v.setImageViewBitmap(PB[i], on ? pOn : pOff);
            v.setImageViewBitmap(PC[i], on ? cOn : cOff);
            v.setImageViewBitmap(PI[i], WidgetArt.prayerIcon(p == null ? "" : p.optString("k"), on ? GOLD_TXT : ICON, filled, isz));
        }
        return v;
    }

    /** الساعة الزجاجية: ساعة كبيرة + اليوم والتاريخ + الصلاة القادمة وعدّادها */
    static RemoteViews gclock(Context c, WidgetModel m, Bundle o) {
        RemoteViews v = rv(c, m, R.layout.widget_gclock);
        v.setImageViewBitmap(R.id.w_bg, plainBg(c, o, 320, 150, m, WidgetArt.GLASS));
        v.setInt(R.id.w_div, "setBackgroundColor", al(WHITE, 0x55));
        if (!m.ok) return v;
        JSONObject d = m.day;
        if (d != null) {
            t(v, R.id.w_day, d.optString("wd"));
            t(v, R.id.w_date, (d.optString("grd") + " " + d.optString("grm")).trim() + "  ·  " + (d.optString("hjd") + " " + d.optString("hjm")).trim());
        }
        JSONObject sp = shownPrayer(m);
        t(v, R.id.w_name, (m.iqPhase ? "إقامة " : "") + nm(sp) + "  " + (m.iqPhase ? (sp == null ? "" : sp.optString("iqs", "")) : tm(sp)));
        v.setTextColor(R.id.w_name, GOLD_TXT);
        if (Build.VERSION.SDK_INT >= 24) {
            v.setChronometer(R.id.w_cd, SystemClock.elapsedRealtime() + (m.target - System.currentTimeMillis()), "بعد %s", true);
            v.setChronometerCountDown(R.id.w_cd, true);
        }
        return v;
    }

    /** الوضع الحالي لويدجت «فائدة اليوم»: من زر القمر، أو من الإعداد، أو تلقائياً حسب الشروق والغروب */
    static boolean arcDark(Context c) { return arcDark(c, WidgetModel.load(c, "arc")); }

    static boolean arcDark(Context c, WidgetModel m) {
        String o = AlarmScheduler.prefs(c).getString("arc_mode", "");
        if (!o.isEmpty()) return "dark".equals(o);
        if ("dark".equals(m.arcMode)) return true;
        if ("light".equals(m.arcMode)) return false;
        return !arcIsDay(m);
    }

    /** فترة النهار = من أذان الظهر إلى أذان المغرب (الظهر والعصر)، وما عداها ليل (المغرب والعشاء والفجر) */
    static boolean arcIsDay(WidgetModel m) {
        long now = System.currentTimeMillis(), dh = 0, mg = 0;
        JSONArray it = m.day == null ? null : m.day.optJSONArray("items");
        for (int i = 0; it != null && i < it.length(); i++) {
            JSONObject p = it.optJSONObject(i);
            if (p == null) continue;
            if ("dhuhr".equals(p.optString("k"))) dh = p.optLong("at");
            if ("maghrib".equals(p.optString("k"))) mg = p.optLong("at");
        }
        if (dh > 0 && mg > 0) return now >= dh && now < mg;
        return m.sunrise > 0 && m.sunset > 0 && now >= m.sunrise + 4 * 3600_000L && now < m.sunset;
    }

    static final java.util.HashSet<String> NIGHT_PH = new java.util.HashSet<>(java.util.Arrays.asList(
            "dhuhr", "maghrib", "isha", "makkah_n", "madinah_n", "aqsa_n", "rock_n", "quba_n", "sophia_n", "umayyad_n"));

    static int dayIndex() {
        java.util.Calendar cal = java.util.Calendar.getInstance();
        return cal.get(java.util.Calendar.DAY_OF_YEAR) + cal.get(java.util.Calendar.YEAR) * 366;
    }

    /** فائدة اليوم ورحلة الصلاة: صورة مسجد تتغير ٤ مرات يومياً + فائدة يومية + مسار الصلوات + أزرار الوضع والكتم */
    static RemoteViews arc(Context c, WidgetModel m, Bundle o) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_arc);
        boolean dark = arcDark(c, m);
        int txt = dark ? 0xFFFFFFFF : 0xFF12372A, sub = dark ? 0xD9FFFFFF : 0xD912372A;
        String[] ph = m.arcPhotos != null && m.arcPhotos.length > 0 ? m.arcPhotos : new String[]{"lib:fajr", "lib:dhuhr", "lib:asr", "lib:maghrib", "lib:isha"};
        java.util.Calendar cal = java.util.Calendar.getInstance();
        // صور الفترة الحالية فقط (صور المستخدم تدخل في الفترتين)، وتتبدّل كل ٣ ساعات
        boolean day = arcIsDay(m);
        java.util.ArrayList<String> L = new java.util.ArrayList<>();
        for (String x : ph) { if (x == null) continue; if (!x.startsWith("lib:") || NIGHT_PH.contains(x.substring(4)) != day) L.add(x); }
        if (L.isEmpty()) L.addAll(java.util.Arrays.asList(ph));
        String pick = L.get(Math.abs(dayIndex() * 8 + cal.get(java.util.Calendar.HOUR_OF_DAY) / 3) % L.size());
        v.setImageViewBitmap(R.id.w_bg, WidgetArt.arcBg(c, o, m, pick, dark));
        v.setImageViewBitmap(R.id.w_moon, WidgetArt.arcButton(dark ? "moon" : "sun", dark));
        v.setImageViewBitmap(R.id.w_bell, WidgetArt.arcButton(m.muted ? "bellOff" : "bell", dark));
        Intent mi = new Intent(c, WArcWidget.class);
        mi.setAction(ACTION_ARC_MODE);
        v.setOnClickPendingIntent(R.id.w_moon, PendingIntent.getBroadcast(c, 99003, mi, AlarmScheduler.piFlags()));
        v.setOnClickPendingIntent(R.id.w_bell, mute(c));
        int[] tv = {R.id.w_date, R.id.w_faida, R.id.w_fsrc, R.id.w_cdl, R.id.w_cd};
        for (int id : tv) v.setTextColor(id, id == R.id.w_date || id == R.id.w_fsrc ? sub : txt);
        if (Build.VERSION.SDK_INT >= 31) v.setColorStateList(R.id.w_cdbox, "setBackgroundTintList", ColorStateList.valueOf(dark ? 0xFF000000 : 0xFFFFFFFF));
        if (!m.ok) return v;
        JSONObject d = m.day;
        if (d != null) {
            t(v, R.id.w_date, (d.optString("wd") + " " + d.optString("hj")).trim());
            JSONObject fd = d.optJSONObject("faida");
            if (fd != null) {
                SpannableString sp = new SpannableString(fd.optString("t"));
                sp.setSpan(new TypefaceSpan("serif"), 0, sp.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                v.setTextViewText(R.id.w_faida, sp);
                v.setTextViewText(R.id.w_fsrc, fd.optString("s"));
            } else { v.setTextViewText(R.id.w_faida, "السلام عليكم ورحمة الله"); v.setTextViewText(R.id.w_fsrc, ""); }
        }
        JSONObject sp = shownPrayer(m);
        v.setTextViewText(R.id.w_cdl, (m.iqPhase ? "إقامة " + nm(sp) : nm(sp)) + " بعد ");
        if (Build.VERSION.SDK_INT >= 24) {
            v.setChronometer(R.id.w_cd, SystemClock.elapsedRealtime() + (m.target - System.currentTimeMillis()), null, true);
            v.setChronometerCountDown(R.id.w_cd, true);
        }
        v.setImageViewBitmap(R.id.w_arc, WidgetArt.arcPath(c, o, m, dark));
        return v;
    }

    /** البطاقات ذات اللسان (الطقس الأسبوعي، الصلاة بلسان علوي، الصلاة بلسان جانبي): صورة واحدة مرسومة بالمظهر */
    static RemoteViews notch(Context c, WidgetModel m, Bundle o, String kind) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_notch);
        v.setImageViewBitmap(R.id.w_bg, WNotchArt.render(c, o, m, kind));
        v.setContentDescription(R.id.w_bg, "wxweek".equals(kind) ? "الطقس" : "مواقيت الصلاة");
        return v;
    }

    /** أسماء الله الحسنى: اسم اليوم ومعناه */
    static RemoteViews asma(Context c, WidgetModel m, Bundle o) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_notch);
        v.setImageViewBitmap(R.id.w_bg, WAsmaArt.render(c, o, m));
        int i = WAsmaArt.todayIndex();
        v.setContentDescription(R.id.w_bg, "اسم اليوم من أسماء الله الحسنى: " + WAsmaArt.ASMA[i][0] + " — " + WAsmaArt.ASMA[i][1]);
        return v;
    }

    static final String ACTION_MIN = "com.albaqiyat.app.WIDGET_MIN";
    static final String[] MIN_KINDS = {"ptop", "pside"};

    /** تحديث كل دقيقة لعدّاد «بعد ٧ س ٥٥ د» في الشكلين الجديدين فقط — منبّه غير موقظ (لا يعمل والشاشة مطفأة) */
    static void scheduleMinute(Context c) {
        try {
            android.app.AlarmManager am = (android.app.AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            if (am == null) return;
            Intent i = new Intent(c, WPtopWidget.class);
            i.setAction(ACTION_MIN);
            PendingIntent pi = PendingIntent.getBroadcast(c, 99410, i, AlarmScheduler.piFlags());
            am.cancel(pi);
            AppWidgetManager mgr = AppWidgetManager.getInstance(c);
            boolean any = false;
            for (int j = 0; j < KINDS.length; j++) for (String k : MIN_KINDS) if (k.equals(KINDS[j]) && mgr.getAppWidgetIds(new ComponentName(c, CLS[j])).length > 0) any = true;
            if (!any) return;
            long at = (System.currentTimeMillis() / 60000 + 1) * 60000 + 300;
            if (Build.VERSION.SDK_INT >= 23) {
                try { am.setExact(android.app.AlarmManager.RTC, at, pi); } catch (SecurityException se) { am.set(android.app.AlarmManager.RTC, at, pi); }
            } else am.set(android.app.AlarmManager.RTC, at, pi);
        } catch (Exception ignored) {}
    }

    static void renderMinute(Context c) {
        try {
            AppWidgetManager mgr = AppWidgetManager.getInstance(c);
            for (int j = 0; j < KINDS.length; j++) for (String k : MIN_KINDS) if (k.equals(KINDS[j])) for (int id : mgr.getAppWidgetIds(new ComponentName(c, CLS[j]))) render(c, mgr, id, k);
        } catch (Exception ignored) {}
        scheduleMinute(c);
    }

    static void t(RemoteViews v, int id, String s) { v.setTextViewText(id, span(s == null ? "" : s)); }

    // ── الأشكال الجديدة: تعبئة موحّدة (الحقول غير الموجودة في التصميم تُتجاهل تلقائياً) ──
    static RemoteViews generic(Context c, WidgetModel m, Bundle o, String kind) {
        int lay; int style; int dw, dh; boolean v2 = false, cres = false;
        switch (kind) {
            case "day": lay = R.layout.widget_day; style = WidgetArt.THEME; dw = 300; dh = 320; cres = true; break;
            case "sky": lay = R.layout.widget_sky; style = WidgetArt.PHASE; dw = 230; dh = 230; v2 = true; break;
            case "mihrab": lay = R.layout.widget_mihrab; style = WidgetArt.MIHRAB; dw = 220; dh = 300; v2 = true; break;
            case "glassday": lay = R.layout.widget_glassday; style = WidgetArt.GLASS; dw = 220; dh = 300; cres = true; break;
            case "sun": lay = R.layout.widget_sun; style = WidgetArt.SUN; dw = 300; dh = 220; v2 = true; break;
            case "dual": lay = R.layout.widget_dual; style = WidgetArt.THEME; dw = 160; dh = 180; break;
            case "pline": lay = R.layout.widget_pline; style = WidgetArt.THEME; dw = 320; dh = 170; break;
            case "daynight": lay = R.layout.widget_daynight; style = WidgetArt.PHASE; dw = 230; dh = 230; v2 = true; break;
            case "fullday": lay = R.layout.widget_fullday; style = WidgetArt.THEME; dw = 300; dh = 400; cres = true; break;
            case "weather": lay = R.layout.widget_weather; style = WidgetArt.PHASE; dw = 230; dh = 250; v2 = true; break;
            case "three": lay = R.layout.widget_three; style = WidgetArt.GLASS; dw = 300; dh = 320; cres = true; break;
            default: lay = R.layout.widget_royal; style = WidgetArt.ROYAL; dw = 300; dh = 320; v2 = true;
        }
        RemoteViews v = rv(c, m, lay);
        v.setImageViewBitmap(R.id.w_bg, v2 ? WidgetArt.bg2(c, o, dw, dh, style, m) : WidgetArt.bg(c, o, dw, dh, style, m, null, cres));
        if (!m.ok) return v;
        String wd = m.d("wd"), hj = m.d("hj"), gr = m.d("gr");
        t(v, R.id.w_wd, wd); t(v, R.id.w_hj, hj); t(v, R.id.w_gr, gr);
        t(v, R.id.w_hjd, m.d("hjd")); t(v, R.id.w_hjm, m.d("hjm")); t(v, R.id.w_hjy, m.d("hjy"));
        t(v, R.id.w_grd, m.d("grd")); t(v, R.id.w_grm, m.d("grm")); t(v, R.id.w_gry, m.d("gry"));
        t(v, R.id.w_wdhj, wd + " " + hj); t(v, R.id.w_wdgr, wd + " " + gr); t(v, R.id.w_wdp, "📅 " + wd);
        t(v, R.id.w_city, m.city); t(v, R.id.w_cityp, "📍 " + m.city);
        t(v, R.id.w_temp, m.wx ? m.temp : "؟°");
        t(v, R.id.w_wdesc, m.wx ? m.wdesc : "لا يوجد اتصال");
        t(v, R.id.w_wemoji, m.wx ? m.wemoji : "؟");
        t(v, R.id.w_wxs, "royal".equals(kind) ? ((m.wx ? m.wemoji : "؟") + "\n" + (m.wx ? m.temp : "؟°")) : ((m.wx ? m.wemoji + " " + m.temp : "؟°")));
        t(v, R.id.w_minmax, m.wx && !m.minmax.isEmpty() ? m.minmax : "العظمى ؟° | الصغرى ؟°");
        t(v, R.id.w_wxline, m.wx ? m.wemoji + " " + m.temp + " — " + m.wdesc : "؟° — لا يوجد اتصال");
        t(v, R.id.w_wxcity, (m.wx ? m.wemoji + " " + m.temp : "؟°") + " — " + m.city);
        JSONObject sp = shownPrayer(m);
        String tt = m.iqPhase ? sp.optString("iqs", "") : tm(sp);
        t(v, R.id.w_lbl, m.iqPhase ? "وقت الإقامة" : "الصلاة القادمة");
        t(v, R.id.w_name, (m.iqPhase ? "إقامة " : "") + nm(sp));
        t(v, R.id.w_nameic, "🕌 " + (m.iqPhase ? "إقامة " : "") + nm(sp));
        t(v, R.id.w_time, tt);
        String nl = ("dual".equals(kind) || "sky".equals(kind) || "daynight".equals(kind)) ? nm(sp) + " " + tt : "🕌 " + nm(sp) + " — " + tt;
        if (m.iqPhase) nl = "⏱ إقامة " + nm(sp) + " " + tt;
        t(v, R.id.w_next_line, nl);
        t(v, R.id.w_cdl, "fullday".equals(kind) ? (m.iqPhase ? "إقامة " + nm(sp) + " بعد " : nm(sp) + " بعد ") : label(m) + " ");
        countdown(v, m);
        v.setProgressBar(R.id.w_prog, 1000, m.progress(), false);
        prog(v, R.id.w_prog);
        t(v, R.id.w_rise, "الشروق " + tm(m.item("sunrise")));
        t(v, R.id.w_set, "الغروب " + tm(m.item("maghrib")));
        t(v, R.id.w_fajr, "الفجر " + tm(m.item("fajr")));
        t(v, R.id.w_isha, "العشاء " + tm(m.item("isha")));
        if ("sun".equals(kind)) t(v, R.id.w_temp, m.wx ? m.temp + " C" : "؟°");
        boolean day = m.isDay();
        t(v, R.id.w_greet, day ? "صباح الخير" : "مساء الخير");
        t(v, R.id.w_gemoji, "fajr".equals(m.phase) ? "🌅" : day ? "☀️" : ("sunset".equals(m.phase) ? "🌇" : "🌙"));
        JSONArray it = m.items();
        long now = System.currentTimeMillis();
        if ("fullday".equals(kind)) {
            for (int i = 0; i < 6; i++) {
                JSONObject p = it != null && i < it.length() ? it.optJSONObject(i) : null;
                t(v, NAME[i], nm(p)); t(v, TIME[i], tm(p));
                boolean hl = i == (m.iqPhase ? m.curIdx : m.nextIdx);
                bgRes(v, CELL[i], hl ? R.drawable.w_hl : R.drawable.w_none);
                v.setTextColor(NAME[i], hl ? GOLD_TXT : SOFT);
                v.setTextColor(TIME[i], hl ? GOLD_TXT : WHITE);
            }
        } else {
            int[] f = five(it);
            boolean dots = "pline".equals(kind) || "royal".equals(kind);
            for (int j = 0; j < 5; j++) {
                JSONObject p = f[j] >= 0 ? it.optJSONObject(f[j]) : null;
                t(v, NAME[j], nm(p)); t(v, TIME[j], tmShort(p));
                boolean isNext = f[j] >= 0 && f[j] == m.nextIdx && !m.iqPhase;
                boolean isCur = f[j] >= 0 && f[j] == m.curIdx;
                boolean past = p != null && p.optLong("at") <= now;
                v.setTextColor(NAME[j], isNext ? GOLD_TXT : (isCur ? WHITE : (past && dots ? DIM : SOFT)));
                v.setTextColor(TIME[j], isNext ? GOLD_TXT : (past && dots && !isCur ? DIM : WHITE));
                if (dots) {
                    dotRes(v, DOT[j], isCur ? R.drawable.w_dot_cur : (isNext ? R.drawable.w_dot_next : (past ? R.drawable.w_dot_past : R.drawable.w_dot_off)));
                    v.setViewVisibility(NOW[j], isCur || (m.curIdx < 0 && isNext) ? View.VISIBLE : View.INVISIBLE);
                } else {
                    bgRes(v, CELL[j], isNext ? R.drawable.w_hl : (isCur ? R.drawable.w_cur : R.drawable.w_cell));
                }
            }
        }
        return v;
    }

    static String label(WidgetModel m) { return m.iqPhase ? "الإقامة بعد" : "متبقي"; }
    static JSONObject shownPrayer(WidgetModel m) { return m.iqPhase ? m.cur : m.next; }

    // ── ١. الشامل (الموصى به) ──
    static RemoteViews full(Context c, WidgetModel m, Bundle o) {
        RemoteViews v = rv(c, m, R.layout.widget_full);
        v.setImageViewBitmap(R.id.w_bg, WidgetArt.bg(c, o, 300, 300, WidgetArt.THEME, m, null, true));
        if (!m.ok) return v;
        JSONObject sp = shownPrayer(m);
        t(v, R.id.w_city, m.city);
        t(v, R.id.w_date, m.day != null ? m.day.optString("greg", "") : "");
        t(v, R.id.w_lbl, m.iqPhase ? "وقت الإقامة" : "الصلاة القادمة");
        t(v, R.id.w_name, nm(sp));
        t(v, R.id.w_time, m.iqPhase ? sp.optString("iqs", "") : tm(sp));
        t(v, R.id.w_cdl, label(m) + " ");
        countdown(v, m);
        JSONArray it = m.items();
        int[] f = five(it);
        for (int j = 0; j < 5; j++) {
            JSONObject p = f[j] >= 0 ? it.optJSONObject(f[j]) : null;
            t(v, NAME[j], nm(p));
            t(v, TIME[j], tmShort(p));
            boolean isNext = f[j] >= 0 && f[j] == m.nextIdx && !m.iqPhase;
            boolean isCur = f[j] >= 0 && f[j] == m.curIdx;
            bgRes(v, CELL[j], isNext ? R.drawable.w_hl : (isCur ? R.drawable.w_cur : R.drawable.w_cell));
            v.setTextColor(NAME[j], isNext ? GOLD_TXT : (isCur ? WHITE : SOFT));
            v.setTextColor(TIME[j], isNext ? GOLD_TXT : WHITE);
        }
        String k = sp != null ? sp.optString("k") : "";
        t(v, R.id.w_adh, m.muted ? "🔕 الأذان صامت" : ("🔔 الأذان " + (m.alertOn("adhan", k) ? "مفعّل" : "معطّل")));
        t(v, R.id.w_iq, "⏱ الإقامة " + (m.iqPhase ? "بعد قليل" : (m.alertOn("iqama", k) ? "مفعّلة" : "معطّلة")));
        t(v, R.id.w_bell, m.muted ? "🔕" : "🔔");
        v.setOnClickPendingIntent(R.id.w_bell, mute(c));
        return v;
    }

    // ── ٢. الصلاة القادمة الفاخر ──
    static RemoteViews next(Context c, WidgetModel m, Bundle o) {
        RemoteViews v = rv(c, m, R.layout.widget_next);
        v.setImageViewBitmap(R.id.w_bg, WidgetArt.bg(c, o, 300, 160, WidgetArt.GLASS, m, null, true));
        if (!m.ok) return v;
        JSONObject sp = shownPrayer(m);
        t(v, R.id.w_lbl, m.iqPhase ? "✦ وقت الإقامة" : "✦ الصلاة القادمة");
        t(v, R.id.w_name, nm(sp));
        t(v, R.id.w_time, "🕐 " + (m.iqPhase ? sp.optString("iqs", "") : tm(sp)));
        t(v, R.id.w_cdl, label(m) + " ");
        countdown(v, m);
        v.setProgressBar(R.id.w_prog, 1000, m.progress(), false);
        prog(v, R.id.w_prog);
        t(v, R.id.w_from, m.iqPhase ? "الأذان" : (m.cur != null ? nm(m.cur) : ""));
        t(v, R.id.w_to, m.iqPhase ? "الإقامة" : nm(m.next));
        return v;
    }

    // ── ٣. الهلال والصلوات ──
    static RemoteViews crescent(Context c, WidgetModel m, Bundle o) {
        RemoteViews v = rv(c, m, R.layout.widget_crescent);
        JSONObject sp = shownPrayer(m);
        String skyKey = m.cur != null ? m.cur.optString("k") : (sp != null ? sp.optString("k") : "isha");
        v.setImageViewBitmap(R.id.w_bg, WidgetArt.bg(c, o, 230, 230, WidgetArt.SKY, m, skyKey, true));
        if (!m.ok) return v;
        t(v, R.id.w_time, m.iqPhase ? sp.optString("iqsh", sp.optString("iqs", "")) : tmShort(sp));
        t(v, R.id.w_name, m.iqPhase ? "إقامة " + nm(sp) : nm(sp));
        countdown(v, m);
        JSONArray it = m.items();
        int[] f = five(it);
        for (int j = 0; j < 5; j++) {
            JSONObject p = f[j] >= 0 ? it.optJSONObject(f[j]) : null;
            t(v, NAME[j], nm(p));
            boolean isCur = f[j] >= 0 && f[j] == m.curIdx;
            boolean isNext = f[j] >= 0 && f[j] == m.nextIdx && !m.iqPhase;
            v.setTextColor(NAME[j], isNext ? GOLD_TXT : (isCur ? WHITE : SOFT));
            bgRes(v, CELL[j], isCur ? R.drawable.w_cur : (isNext ? R.drawable.w_hl : R.drawable.w_none));
        }
        return v;
    }

    // ── ٤. رحلة اليوم ──
    static RemoteViews timeline(Context c, WidgetModel m, Bundle o) {
        RemoteViews v = rv(c, m, R.layout.widget_timeline);
        v.setImageViewBitmap(R.id.w_bg, WidgetArt.bg(c, o, 320, 140, WidgetArt.THEME, m, null, false));
        if (!m.ok) return v;
        JSONObject sp = shownPrayer(m);
        t(v, R.id.w_name, (m.iqPhase ? "إقامة " : "القادمة: ") + nm(sp) + "  " + (m.iqPhase ? sp.optString("iqs", "") : tm(sp)));
        t(v, R.id.w_cdl, label(m) + " ");
        countdown(v, m);
        JSONArray it = m.items();
        long now = System.currentTimeMillis();
        for (int i = 0; i < 6; i++) {
            JSONObject p = it != null && i < it.length() ? it.optJSONObject(i) : null;
            t(v, NAME[i], nm(p));
            t(v, TIME[i], tmShort(p));
            boolean isCur = i == m.curIdx, isNext = i == m.nextIdx && !m.iqPhase;
            boolean past = p != null && p.optLong("at") <= now;
            dotRes(v, DOT[i], isCur ? R.drawable.w_dot_cur : (isNext ? R.drawable.w_dot_next : (past ? R.drawable.w_dot_past : R.drawable.w_dot_off)));
            v.setTextColor(NAME[i], isNext ? GOLD_TXT : (isCur ? WHITE : (past ? DIM : SOFT)));
            v.setTextColor(TIME[i], isNext ? GOLD_TXT : (past && !isCur ? DIM : WHITE));
        }
        return v;
    }

    // ── ٥. المسجد المصغر ──
    static RemoteViews mosque(Context c, WidgetModel m, Bundle o) {
        RemoteViews v = rv(c, m, R.layout.widget_mosque);
        v.setImageViewBitmap(R.id.w_bg, WidgetArt.bg(c, o, 200, 250, WidgetArt.THEME, m, null, false));
        v.setInt(R.id.w_icon, "setColorFilter", m.sk ? m.icon : m.gold);
        t(v, R.id.w_bell, m.muted ? "🔕" : "🔔");
        v.setOnClickPendingIntent(R.id.w_bell, mute(c));
        if (!m.ok) return v;
        JSONObject sp = shownPrayer(m);
        t(v, R.id.w_city, m.city);
        t(v, R.id.w_date, m.day != null ? m.day.optString("greg", "") : "");
        t(v, R.id.w_name, m.iqPhase ? "إقامة " + nm(sp) : nm(sp));
        t(v, R.id.w_time, m.iqPhase ? sp.optString("iqs", "") : tm(sp));
        JSONObject then = m.iqPhase ? m.next : m.after;
        t(v, R.id.w_then, then != null ? "ثم " + nm(then) + "  " + tm(then) : "");
        return v;
    }

    // ── ٦. الزجاج الفاخر ──
    static RemoteViews glass(Context c, WidgetModel m, Bundle o) {
        RemoteViews v = rv(c, m, R.layout.widget_glass);
        v.setImageViewBitmap(R.id.w_bg, WidgetArt.bg(c, o, 220, 270, WidgetArt.GLASS, m, null, true));
        if (!m.ok) return v;
        JSONArray it = m.items();
        int[] f = five(it);
        for (int j = 0; j < 5; j++) {
            JSONObject p = f[j] >= 0 ? it.optJSONObject(f[j]) : null;
            t(v, NAME[j], nm(p));
            t(v, TIME[j], tm(p));
            boolean isNext = f[j] >= 0 && f[j] == m.nextIdx && !m.iqPhase;
            boolean isCur = f[j] >= 0 && f[j] == m.curIdx;
            bgRes(v, CELL[j], isNext ? R.drawable.w_hl : (isCur ? R.drawable.w_cur : R.drawable.w_none));
            v.setTextColor(NAME[j], isNext ? GOLD_TXT : SOFT);
            v.setTextColor(TIME[j], isNext ? GOLD_TXT : WHITE);
        }
        JSONObject sp = shownPrayer(m);
        t(v, R.id.w_cdl, (m.iqPhase ? "إقامة " + nm(sp) + " بعد " : nm(sp) + " بعد "));
        countdown(v, m);
        return v;
    }

    // ── ٧. الصلاة التالية (بسيط) ──
    static RemoteViews minimal(Context c, WidgetModel m, Bundle o) {
        RemoteViews v = rv(c, m, R.layout.widget_minimal);
        v.setImageViewBitmap(R.id.w_bg, WidgetArt.bg(c, o, 170, 170, WidgetArt.MINIMAL, m, null, false));
        if (!m.ok) return v;
        JSONObject sp = shownPrayer(m);
        t(v, R.id.w_name, m.iqPhase ? "إقامة " + nm(sp) : nm(sp));
        t(v, R.id.w_time, m.iqPhase ? sp.optString("iqs", "") : tm(sp));
        t(v, R.id.w_cdl, label(m) + " ");
        countdown(v, m);
        JSONObject then = m.iqPhase ? m.next : m.after;
        t(v, R.id.w_then, then != null ? nm(then) + "  " + tm(then) : "");
        return v;
    }
}
