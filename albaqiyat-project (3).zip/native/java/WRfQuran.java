package com.albaqiyat.app;

public class WRfQuran extends RafiqWidget {
    @Override
    protected String kind() { return "rquran"; }
}
