package com.albaqiyat.app;

public class WAsmaWidget extends BaseWidget {
    @Override
    protected String kind() { return "asma"; }
}
