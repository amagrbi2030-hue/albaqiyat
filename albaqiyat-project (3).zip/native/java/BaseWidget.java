package com.albaqiyat.app;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

/** أساس مشترك لجميع ودجات أوقات الصلاة */
public abstract class BaseWidget extends AppWidgetProvider {
    protected abstract String kind();

    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        for (int id : ids) WidgetHub.render(c, m, id, kind());
        AlarmScheduler.scheduleWidgetTick(c);
    }

    @Override
    public void onAppWidgetOptionsChanged(Context c, AppWidgetManager m, int id, Bundle o) {
        WidgetHub.render(c, m, id, kind());
    }

    @Override
    public void onEnabled(Context c) {
        AlarmScheduler.scheduleWidgetTick(c);
    }

    @Override
    public void onReceive(Context c, Intent i) {
        super.onReceive(c, i);
        String a = i.getAction();
        if (AlarmScheduler.ACTION_TICK.equals(a) || Intent.ACTION_POWER_CONNECTED.equals(a) || Intent.ACTION_POWER_DISCONNECTED.equals(a)
                || Intent.ACTION_BATTERY_LOW.equals(a) || Intent.ACTION_BATTERY_OKAY.equals(a)) {
            WidgetHub.updateAll(c);
        } else if (WidgetHub.ACTION_MIN.equals(a)) {
            WidgetHub.renderMinute(c);
        } else if (WidgetHub.ACTION_ARC_MODE.equals(a)) {
            // زر القمر في ويدجت «فائدة اليوم»: تبديل الداكن/الفاتح
            String cur = AlarmScheduler.prefs(c).getString("arc_mode", "");
            boolean dark = cur.isEmpty() ? WidgetHub.arcDark(c) : "dark".equals(cur);
            AlarmScheduler.prefs(c).edit().putString("arc_mode", dark ? "light" : "dark").commit();
            WidgetHub.renderAllOnly(c);
        } else if (WidgetHub.ACTION_MUTE.equals(a)) {
            // أثناء رفع الأذان: الزر يوقف الأذان الحالي فقط ولا يكتم الأذانات القادمة (كان سبب عدم ظهور البطاقة لاحقاً)
            if (AdhanService.isPlaying()) {
                try { Intent st = new Intent(c, AdhanService.class); st.setAction("STOP"); c.startService(st); } catch (Exception ignored) {}
                return;
            }
            boolean mu = !AlarmScheduler.prefs(c).getBoolean("muted", false);
            AlarmScheduler.prefs(c).edit().putBoolean("muted", mu).commit();
            WidgetHub.updateAll(c);
        }
    }
}
