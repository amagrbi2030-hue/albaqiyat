package com.albaqiyat.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.net.Uri;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;

/** رسم ويدجت «مسبحة بلمسة»: ١٢ نمطاً، تخطيط يتغير مع الحجم (١×١، صفّ ٤×١، حلقة ٢×٢ فأكبر) */
final class TasbihRender {
    private TasbihRender() {}

    static final String[] KINDS = {"tb1", "tb2", "tb41", "tb42", "tb44", "tbm"};
    static final Class<?>[] CLS = {WTasbih1.class, WTasbih2.class, WTasbih41.class, WTasbih42.class, WTasbih44.class, WTasbihMulti.class};
    static final int[][] DEF_DP = {{70, 70}, {150, 150}, {300, 70}, {300, 150}, {300, 300}, {300, 150}};

    static final int A_INC = 1, A_UNDO = 2, A_PREV = 3, A_NEXT = 4, A_RESET = 5, A_ROUND = 6, A_CNEXT = 7, A_CSTOP = 8, A_OPEN = 9;

    static String kindOf(Context c, int id) {
        try {
            android.appwidget.AppWidgetProviderInfo pi = AppWidgetManager.getInstance(c).getAppWidgetInfo(id);
            if (pi != null) for (int i = 0; i < CLS.length; i++) if (pi.provider.getClassName().equals(CLS[i].getName())) return KINDS[i];
        } catch (Exception ignored) {}
        return "tb2";
    }

    static void renderAll(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        for (int i = 0; i < CLS.length; i++) {
            try { for (int id : m.getAppWidgetIds(new ComponentName(c, CLS[i]))) render(c, m, id, KINDS[i]); } catch (Exception ignored) {}
        }
    }

    static int[] allIds(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        java.util.ArrayList<Integer> L = new java.util.ArrayList<>();
        for (Class<?> k : CLS) try { for (int id : m.getAppWidgetIds(new ComponentName(c, k))) L.add(id); } catch (Exception ignored) {}
        int[] r = new int[L.size()];
        for (int i = 0; i < r.length; i++) r[i] = L.get(i);
        return r;
    }

    // ── الأنماط: bg1, bg2, رقم, حلقة, حبات, نص ──
    static int[] pal(String st, boolean night) {
        switch (st) {
            case "blue": return new int[]{0xFF12336E, 0xFF081A3A, 0xFFFFFFFF, 0xFFD4AF37, 0xFFD9C27A, 0xFFF1E6C2};
            case "ivory": return new int[]{0xFFF8F2E3, 0xFFEADFC4, 0xFF4A3220, 0xFF8B5A2B, 0xFF8B5A2B, 0xFF5B4330};
            case "purple": return new int[]{0xFF432266, 0xFF22113A, 0xFFFFFFFF, 0xFFD9B65A, 0xFFE3CCFF, 0xFFEFE2FF};
            case "turq": return new int[]{0xFF0F7A78, 0xFF07494A, 0xFFFFFFFF, 0xFFF2D27A, 0xFFBFF3EE, 0xFFE6FFFB};
            case "black": return new int[]{0xFF1A1A1A, 0xFF060606, 0xFFF5E6B8, 0xFFC9A54B, 0xFFC9A54B, 0xFFD9CFB5};
            case "glass": return night ? new int[]{0x66101418, 0x4D101418, 0xFFFFFFFF, 0xFFD4AF37, 0xFFFFFFFF, 0xFFE8EEF2}
                                       : new int[]{0x8CFFFFFF, 0x66FFFFFF, 0xFF13293D, 0xFFB8932E, 0xFF0F5132, 0xFF1E3346};
            case "neon": return new int[]{0xFF070914, 0xFF0D1230, 0xFF39FFE0, 0xFF39FFE0, 0xFFFF3DCB, 0xFFB9FFF6};
            case "lcd": return new int[]{0xFF2A3B2C, 0xFF16211A, 0xFF1B2A1B, 0xFF9FC59A, 0xFF9FC59A, 0xFFCFE6CB};
            case "beadring": return new int[]{0xFF12402F, 0xFF0A2A1E, 0xFFFFFFFF, 0xFFD4AF37, 0xFFE2C46A, 0xFFF3E9C8};
            case "card": return new int[]{0xFFFBF7EC, 0xFFF0E6CE, 0xFF0F5132, 0xFF0F5132, 0xFFC9A54B, 0xFF0F5132};
            case "clear": return night ? new int[]{0x00000000, 0x00000000, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF}
                                       : new int[]{0x00000000, 0x00000000, 0xFF14231A, 0xFF0F5132, 0xFF0F5132, 0xFF14231A};
            default: return new int[]{0xFF146C43, 0xFF0A3B24, 0xFFFFFFFF, 0xFFD4AF37, 0xFFE9D9A6, 0xFFF3E9C8}; // green
        }
    }

    static int col(String s, int def) {
        if (s == null || s.isEmpty()) return def;
        try { return Color.parseColor(s); } catch (Exception e) { return def; }
    }

    static int darker(int c, float f) {
        return Color.argb(Color.alpha(c), (int) (Color.red(c) * f), (int) (Color.green(c) * f), (int) (Color.blue(c) * f));
    }

    static int al(int c, int a) { return (c & 0x00FFFFFF) | (Math.max(0, Math.min(255, a)) << 24); }

    static String num(int n, boolean ar) {
        String s = String.valueOf(n);
        if (!ar) return s;
        StringBuilder b = new StringBuilder();
        for (char ch : s.toCharArray()) b.append(ch >= '0' && ch <= '9' ? (char) ('٠' + (ch - '0')) : ch);
        return b.toString();
    }

    static boolean night(Context c, JSONObject o) {
        String md = o.optString("mode", "auto");
        if ("dark".equals(md)) return true;
        if ("light".equals(md)) return false;
        return (c.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
    }

    static PendingIntent act(Context c, int id, int a, String extra) {
        Intent i = new Intent(c, TasbihReceiver.class);
        i.setAction(TasbihReceiver.ACTION);
        i.setData(Uri.parse("tasbih://w/" + id + "/" + a));
        i.putExtra("id", id);
        i.putExtra("a", a);
        if (extra != null) i.putExtra("d", extra);
        return PendingIntent.getBroadcast(c, id * 16 + a, i, AlarmScheduler.piFlags());
    }

    static void render(Context c, AppWidgetManager m, int id, String kind) {
        try { render0(c, m, id, kind); } catch (Throwable ignored) {}
    }

    static int[] sizeDp(Context c, AppWidgetManager m, int id, String kind) {
        int ki = 1;
        for (int i = 0; i < KINDS.length; i++) if (KINDS[i].equals(kind)) ki = i;
        int wdp = DEF_DP[ki][0], hdp = DEF_DP[ki][1];
        try {
            Bundle op = m.getAppWidgetOptions(id);
            boolean land = c.getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE;
            int w = op.getInt(land ? AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH : AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0);
            int h = op.getInt(land ? AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT : AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0);
            if (w > 0) wdp = w;
            if (h > 0) hdp = h;
        } catch (Exception ignored) {}
        return new int[]{wdp, hdp};
    }

    static int layOf(int wdp, int hdp) { return (wdp < 105 && hdp < 105) ? 0 : (hdp < 95 ? 1 : 2); }

    /** هل تتسع الويدجت لأزرار ما بعد الهدف؟ (الصغيرة والصف لا تتسع: اللمسة تبدأ دورة جديدة) */
    static boolean hasChoice(Context c, int id) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        int[] wh = sizeDp(c, m, id, kindOf(c, id));
        return layOf(wh[0], wh[1]) == 2;
    }

    private static void render0(Context c, AppWidgetManager m, int id, String kind) {
        JSONObject o = TasbihStore.ensure(c, id, kind);
        float dp = c.getResources().getDisplayMetrics().density;
        int[] wh = sizeDp(c, m, id, kind);
        int wdp = wh[0], hdp = wh[1];
        int lay = layOf(wdp, hdp); // 0 صغير، 1 صف، 2 حلقة
        int layout = lay == 0 ? R.layout.tasbih_small : lay == 1 ? R.layout.tasbih_row : R.layout.tasbih_ring;
        RemoteViews v = new RemoteViews(c.getPackageName(), layout);

        String st = o.optString("style", "green");
        boolean nt = night(c, o);
        int[] P = pal(st, nt);
        JSONObject cc = o.optJSONObject("col");
        if (cc != null) {
            if (!cc.optString("bg").isEmpty()) { P[0] = col(cc.optString("bg"), P[0]); P[1] = darker(P[0], 0.62f); }
            P[2] = col(cc.optString("num"), P[2]);
            P[3] = col(cc.optString("ring"), P[3]);
            P[4] = col(cc.optString("bead"), P[4]);
            P[5] = col(cc.optString("text"), P[5]);
        }
        int alpha = Math.max(0, Math.min(100, o.optInt("alpha", 100)));
        int orn = o.optInt("orn", 1);
        float fs = (float) Math.max(0.7, Math.min(1.5, o.optDouble("fs", 1.0)));
        boolean ar = o.optBoolean("ar", false);
        boolean multi = "multi".equals(o.optString("kind"));
        String d = TasbihStore.current(o);
        int n = TasbihStore.count(o, d), target = o.optInt("target", 33);
        JSONObject rr = o.optJSONObject("rounds");
        int rounds = rr == null ? 0 : rr.optInt(d, 0);
        boolean done = o.optBoolean("done", false), stopped = o.optBoolean("stopped", false);
        String msg = o.optString("msg", "");
        float prog = target > 0 ? Math.min(1f, n / (float) target) : (n % 100) / 100f;

        // ── الخلفية المرسومة ──
        int W = Math.round(wdp * dp), H = Math.round(hdp * dp);
        float sc = Math.min(1f, 720f / Math.max(W, H));
        int bw = Math.max(40, Math.round(W * sc)), bh = Math.max(40, Math.round(H * sc));
        float u = dp * sc; // وحدة dp داخل الصورة
        Bitmap bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bmp);
        drawBg(cv, bw, bh, u, st, P, alpha, orn, nt);
        float cx, cy, r;
        if (lay == 0) { cx = bw / 2f; cy = bh / 2f; r = Math.min(bw, bh) / 2f - 7 * u; }
        else if (lay == 2) {
            float top = 8 * u + 30 * u, bot = 8 * u + 34 * u;
            cx = bw / 2f; cy = top + (bh - top - bot) / 2f; r = Math.min(bw - 16 * u, bh - top - bot) / 2f - 3 * u;
        } else { cx = cy = r = 0; }
        if (done || (msg.length() > 0 && !stopped)) glow(cv, lay == 1 ? bw * 0.6f : cx, lay == 1 ? bh / 2f : cy, lay == 1 ? bh : r * 1.25f, P[3]);
        if (lay == 1) drawRowProgress(cv, bw, bh, u, st, P, prog, target);
        else drawFace(cv, cx, cy, r, u, st, P, prog, target, n);
        v.setImageViewBitmap(R.id.tb_bg, bmp);

        // ── النصوص ──
        boolean lcd = "lcd".equals(st);
        int cid = lcd ? R.id.tb_count_lcd : R.id.tb_count;
        v.setViewVisibility(R.id.tb_count, lcd ? View.GONE : View.VISIBLE);
        v.setViewVisibility(R.id.tb_count_lcd, lcd ? View.VISIBLE : View.GONE);
        String ns = lcd ? num(n, false) : num(n, ar);
        v.setTextViewText(cid, ns);
        if (!lcd) v.setTextColor(cid, P[2]);
        int digits = ns.length();
        float cpx;
        if (lay == 1) cpx = H * 0.42f;
        else { float rr0 = (lay == 0 ? Math.min(W, H) / 2f - 7 * dp : r / sc); cpx = rr0 * (lay == 0 ? 0.62f : 0.56f); }
        if (digits >= 4) cpx *= lay == 1 ? 0.85f : 0.72f; else if (digits == 3) cpx *= 0.86f;
        if (lcd && lay != 1) cpx *= 0.8f;
        v.setTextViewTextSize(cid, TypedValue.COMPLEX_UNIT_PX, cpx * fs);

        String sub;
        if (done) sub = msg.isEmpty() ? "اكتمل الهدف ✓" : msg;
        else if (stopped) sub = msg.isEmpty() ? "متوقّف — المس للبدء" : msg;
        else if (!msg.isEmpty()) sub = msg;
        else if (target > 0) sub = (lay == 0 ? "/" + num(target, ar) : "من " + num(target, ar)) + (rounds > 0 && lay != 0 ? " · الدورة " + num(rounds + 1, ar) : "");
        else sub = lay == 0 ? "∞" : "بلا حدّ";
        if (lay == 0 && (done || stopped)) sub = "✓";
        v.setTextViewText(R.id.tb_sub, sub);
        v.setTextColor(R.id.tb_sub, al(P[5], 0xCC));
        v.setTextViewTextSize(R.id.tb_sub, TypedValue.COMPLEX_UNIT_PX, (lay == 0 ? 9 : 11) * dp * Math.min(1.25f, fs));

        String title = TasbihStore.text(c, d);
        if (lay != 0) {
            v.setTextViewText(R.id.tb_title, title);
            v.setTextColor(R.id.tb_title, P[5]);
            float tsp = lay == 1 ? 14 : (wdp >= 250 && hdp >= 250 ? 18 : 15);
            if (title.length() > 26) tsp *= 0.82f;
            v.setTextViewTextSize(R.id.tb_title, TypedValue.COMPLEX_UNIT_PX, tsp * dp * fs);
            for (int b : new int[]{R.id.tb_prev, R.id.tb_next}) { v.setTextColor(b, P[5]); v.setViewVisibility(b, multi ? View.VISIBLE : View.GONE); }
            v.setTextColor(R.id.tb_undo, al(P[5], 0xDD));
            v.setTextColor(R.id.tb_reset, al(P[5], 0x88));
            v.setOnClickPendingIntent(R.id.tb_prev, act(c, id, A_PREV, null));
            v.setOnClickPendingIntent(R.id.tb_next, act(c, id, A_NEXT, null));
            v.setOnClickPendingIntent(R.id.tb_undo, act(c, id, A_UNDO, null));
            Intent ri = new Intent(c, TasbihResetActivity.class);
            ri.setData(Uri.parse("tasbih://reset/" + id));
            ri.putExtra("id", id);
            ri.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_HISTORY | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
            v.setOnClickPendingIntent(R.id.tb_reset, PendingIntent.getActivity(c, id * 16 + A_RESET, ri, AlarmScheduler.piFlags()));
            Intent li = c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
            if (li != null) {
                li.setData(Uri.parse("tasbih://open/" + id));
                li.putExtra("route", "tbw");
                li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                // العنوان صار جزءاً من مساحة العدّ؛ فتح التطبيق من سطر القائمة أسفل الويدجت (الشكل الكبير)
                if (lay == 2) v.setOnClickPendingIntent(R.id.tb_list, PendingIntent.getActivity(c, id * 16 + A_OPEN, li, AlarmScheduler.piFlags()));
            }
        }
        if (lay == 2) {
            v.setViewVisibility(R.id.tb_bottom, done ? View.GONE : View.VISIBLE);
            v.setViewVisibility(R.id.tb_choice, done ? View.VISIBLE : View.GONE);
            for (int b : new int[]{R.id.tb_c_round, R.id.tb_c_next, R.id.tb_c_stop}) v.setTextColor(b, P[5]);
            v.setOnClickPendingIntent(R.id.tb_c_round, act(c, id, A_ROUND, null));
            v.setOnClickPendingIntent(R.id.tb_c_next, act(c, id, A_CNEXT, null));
            v.setOnClickPendingIntent(R.id.tb_c_stop, act(c, id, A_CSTOP, null));
            v.setTextColor(R.id.tb_list, al(P[5], 0xBB));
            v.setTextViewText(R.id.tb_list, listLine(c, o, d, ar, multi || "card".equals(st), wdp));
        }
        // كامل البطاقة تعدّ عند اللمس (ما عدا الأزرار الصغيرة)، وليس منطقة العدّاد وحدها
        PendingIntent inc = act(c, id, A_INC, null);
        v.setOnClickPendingIntent(R.id.tb_tap, inc);
        v.setOnClickPendingIntent(R.id.tb_root, inc);
        if (lay != 0) v.setOnClickPendingIntent(R.id.tb_title, inc);
        v.setContentDescription(R.id.tb_tap, "سبّح: " + title + " — " + n);
        m.updateAppWidget(id, v);
    }

    /** سطر أسفل الويدجت: قائمة الأذكار مع عدّاداتها (متعدد/بطاقة) أو مجموع اليوم */
    static String listLine(Context c, JSONObject o, String cur, boolean ar, boolean list, int wdp) {
        if (list) {
            JSONArray ids = "multi".equals(o.optString("kind")) ? o.optJSONArray("multi") : null;
            if (ids == null) { ids = new JSONArray(); JSONArray L = TasbihStore.list(c); for (int i = 0; i < L.length() && i < 4; i++) ids.put(L.optJSONObject(i).optString("id")); }
            StringBuilder b = new StringBuilder();
            int pos = 0;
            for (int i = 0; i < ids.length(); i++) {
                String x = ids.optString(i);
                if (x.equals(cur)) pos = i + 1;
                if (x.equals(cur) && ids.length() > 1) continue;
                String t = strip(TasbihStore.text(c, x));
                if (t.length() > 14) t = t.substring(0, 13) + "…";
                if (b.length() > 0) b.append("  ·  ");
                b.append(t).append(" ").append(num(TasbihStore.count(o, x), ar));
            }
            return (pos > 0 && ids.length() > 1 ? num(pos, ar) + "/" + num(ids.length(), ar) + "   " : "") + b;
        }
        try {
            JSONObject h = new JSONObject(TasbihStore.p(c).getString("hist", "{}")).optJSONObject(TasbihStore.today());
            int s = 0;
            if (h != null) { java.util.Iterator<String> it = h.keys(); while (it.hasNext()) s += h.optInt(it.next()); }
            return wdp >= 200 ? "مجموع اليوم: " + num(s, ar) : num(s, ar);
        } catch (Exception e) { return ""; }
    }

    static String strip(String s) { return s.replaceAll("[\\u064B-\\u0652\\u0670\\u0640]", ""); }

    // ── الرسم ──
    static void drawBg(Canvas cv, int w, int h, float u, String st, int[] P, int alpha, int orn, boolean nt) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float rad = 22 * u;
        RectF R0 = new RectF(u, u, w - u, h - u);
        int a1 = Math.round(Color.alpha(P[0]) * alpha / 100f), a2 = Math.round(Color.alpha(P[1]) * alpha / 100f);
        if (!"clear".equals(st)) {
            p.setShader(new LinearGradient(0, 0, w * 0.3f, h, al(P[0], a1), al(P[1], a2), Shader.TileMode.CLAMP));
            cv.drawRoundRect(R0, rad, rad, p);
            p.setShader(null);
        }
        if ("glass".equals(st)) {
            p.setShader(new LinearGradient(0, 0, 0, h * 0.55f, nt ? 0x22FFFFFF : 0x55FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
            cv.drawRoundRect(R0, rad, rad, p);
            p.setShader(null);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.2f * u); p.setColor(nt ? 0x40FFFFFF : 0x99FFFFFF);
            cv.drawRoundRect(R0, rad, rad, p);
            p.setStyle(Paint.Style.FILL);
        }
        if ("black".equals(st)) { // ملمس مطفي خفيف
            java.util.Random rn = new java.util.Random(7);
            p.setColor(0x0AFFFFFF);
            for (int i = 0; i < w * h / 900; i++) cv.drawCircle(rn.nextFloat() * w, rn.nextFloat() * h, 0.8f * u, p);
        }
        if ("ivory".equals(st)) { // عروق خشب خفيفة في الحافة
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3 * u); p.setColor(al(0xFF8B5A2B, 0x55));
            cv.drawRoundRect(new RectF(2.5f * u, 2.5f * u, w - 2.5f * u, h - 2.5f * u), rad, rad, p);
            p.setStyle(Paint.Style.FILL);
        }
        if (orn >= 1 && !"clear".equals(st) && !"lcd".equals(st) && !"neon".equals(st)) {
            int gold = "card".equals(st) || "ivory".equals(st) ? 0xFFB08A2E : 0xFFD4AF37;
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(0.9f * u); p.setColor(al(gold, 0x70));
            float ins = 5 * u;
            cv.drawRoundRect(new RectF(ins, ins, w - ins, h - ins), rad - 4 * u, rad - 4 * u, p);
            p.setStyle(Paint.Style.FILL);
            if (orn >= 2) {
                p.setColor(al(gold, 0x9A));
                float s = 5 * u;
                star(cv, p, 13 * u, 13 * u, s); star(cv, p, w - 13 * u, 13 * u, s);
                star(cv, p, 13 * u, h - 13 * u, s); star(cv, p, w - 13 * u, h - 13 * u, s);
            }
        }
        if ("neon".equals(st)) {
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.2f * u); p.setColor(al(P[3], 0x66));
            p.setMaskFilter(new BlurMaskFilter(4 * u, BlurMaskFilter.Blur.NORMAL));
            cv.drawRoundRect(new RectF(3 * u, 3 * u, w - 3 * u, h - 3 * u), rad, rad, p);
            p.setMaskFilter(null); p.setStyle(Paint.Style.FILL);
        }
    }

    /** نجمة ثمانية صغيرة (زخرفة هادئة) */
    static void star(Canvas cv, Paint p, float x, float y, float s) {
        Path pa = new Path();
        for (int i = 0; i < 16; i++) {
            double a = Math.PI * i / 8 - Math.PI / 2;
            float rr = i % 2 == 0 ? s : s * 0.45f;
            float px = x + (float) Math.cos(a) * rr, py = y + (float) Math.sin(a) * rr;
            if (i == 0) pa.moveTo(px, py); else pa.lineTo(px, py);
        }
        pa.close();
        cv.drawPath(pa, p);
    }

    static void glow(Canvas cv, float x, float y, float r, int c) {
        if (r <= 0) return;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new RadialGradient(x, y, r, new int[]{al(c, 0x55), al(c, 0x18), al(c, 0)}, new float[]{0f, 0.6f, 1f}, Shader.TileMode.CLAMP));
        cv.drawCircle(x, y, r, p);
    }

    static boolean beadStyle(String st) { return "ivory".equals(st) || "beadring".equals(st); }

    static void drawFace(Canvas cv, float cx, float cy, float r, float u, String st, int[] P, float prog, int target, int n) {
        if (r <= 4) return;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        if ("lcd".equals(st)) {
            float pw = r * 1.7f, ph = r * 0.85f;
            RectF pr = new RectF(cx - pw / 2, cy - ph / 2 - r * 0.12f, cx + pw / 2, cy + ph / 2 - r * 0.12f);
            p.setColor(0xFF0C120D);
            cv.drawRoundRect(new RectF(pr.left - 4 * u, pr.top - 4 * u, pr.right + 4 * u, pr.bottom + 4 * u), 10 * u, 10 * u, p);
            p.setShader(new LinearGradient(0, pr.top, 0, pr.bottom, 0xFFB4CFA9, 0xFF8FB088, Shader.TileMode.CLAMP));
            cv.drawRoundRect(pr, 6 * u, 6 * u, p);
            p.setShader(null);
            p.setColor(0x14000000);
            for (float yy = pr.top + 2 * u; yy < pr.bottom; yy += 3 * u) cv.drawRect(pr.left, yy, pr.right, yy + 0.6f * u, p);
            int seg = 20; float gap = 2 * u, sw = (pw - gap * (seg - 1)) / seg, y0 = pr.bottom + 10 * u;
            for (int i = 0; i < seg; i++) {
                p.setColor(i < Math.round(prog * seg) ? P[3] : al(P[3], 0x30));
                float x0 = cx + pw / 2 - (i + 1) * sw - i * gap; // من اليمين
                cv.drawRoundRect(new RectF(x0, y0, x0 + sw, y0 + 5 * u), 1.5f * u, 1.5f * u, p);
            }
            return;
        }
        if (beadStyle(st)) {
            int N = 33;
            float br = (float) (r * Math.sin(Math.PI / N)) * 0.92f;
            float rr = r - br;
            int filled = Math.round(prog * N);
            if (target > 0 && n >= target) filled = N;
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(0.8f * u); p.setColor(al(P[4], 0x55));
            cv.drawCircle(cx, cy, rr, p);
            p.setStyle(Paint.Style.FILL);
            boolean wood = "ivory".equals(st);
            for (int i = 0; i < N; i++) {
                double a = -Math.PI / 2 - 2 * Math.PI * i / N; // عكس عقارب الساعة (اتجاه عربي)
                float bx = cx + (float) Math.cos(a) * rr, by = cy + (float) Math.sin(a) * rr;
                boolean on = i < filled;
                int base = on ? P[4] : al(P[4], wood ? 0x50 : 0x38);
                if (wood) base = on ? P[4] : 0x55C9A27A;
                p.setShader(new RadialGradient(bx - br * 0.35f, by - br * 0.35f, br * 1.3f, new int[]{lighten(base), base, darker(base, 0.7f)}, new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
                cv.drawCircle(bx, by, br * (i == 0 ? 1.18f : 1f), p);
                p.setShader(null);
            }
            return;
        }
        float sw = Math.max(3 * u, r * 0.085f);
        float rr = r - sw / 2 - 2 * u;
        RectF oval = new RectF(cx - rr, cy - rr, cx + rr, cy + rr);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(sw);
        p.setColor(al(P[3], "clear".equals(st) ? 0x40 : 0x2E));
        cv.drawCircle(cx, cy, rr, p);
        p.setStrokeCap(Paint.Cap.ROUND);
        float sweep = -360f * prog; // عكس عقارب الساعة
        if ("neon".equals(st)) {
            p.setColor(P[3]);
            p.setMaskFilter(new BlurMaskFilter(sw * 0.9f, BlurMaskFilter.Blur.NORMAL));
            if (prog > 0) cv.drawArc(oval, -90, sweep, false, p);
            p.setMaskFilter(null);
            p.setStrokeWidth(sw * 0.45f);
            p.setColor(0xFFE9FFFC);
            if (prog > 0) cv.drawArc(oval, -90, sweep, false, p);
        } else {
            p.setColor(P[3]);
            if (prog > 0) cv.drawArc(oval, -90, sweep, false, p);
        }
        p.setStrokeCap(Paint.Cap.BUTT);
        // حبّة رأس التقدم
        if (prog > 0 && prog < 1) {
            double a = Math.toRadians(-90 + sweep);
            p.setStyle(Paint.Style.FILL);
            p.setColor(P[4]);
            cv.drawCircle(cx + (float) Math.cos(a) * rr, cy + (float) Math.sin(a) * rr, sw * 0.62f, p);
        }
        // علامات خفيفة كل ١١ (ثلاث دورات صغيرة)
        p.setStyle(Paint.Style.FILL);
        p.setColor(al(P[3], 0x66));
        for (int i = 0; i < 3; i++) {
            double a = -Math.PI / 2 - 2 * Math.PI * i / 3;
            cv.drawCircle(cx + (float) Math.cos(a) * (rr - sw * 1.2f), cy + (float) Math.sin(a) * (rr - sw * 1.2f), 1.4f * u, p);
        }
    }

    static int lighten(int c) {
        return Color.argb(Color.alpha(c), Math.min(255, Color.red(c) + 70), Math.min(255, Color.green(c) + 70), Math.min(255, Color.blue(c) + 70));
    }

    static void drawRowProgress(Canvas cv, int w, int h, float u, String st, int[] P, float prog, int target) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        if (beadStyle(st)) {
            int N = 33;
            float x1 = w - 14 * u, x0 = 14 * u, gap = (x1 - x0) / (N - 1), br = Math.min(gap * 0.42f, 3.2f * u), y = h - 6 * u;
            int filled = Math.round(prog * N);
            for (int i = 0; i < N; i++) {
                int base = i < filled ? P[4] : al(P[4], 0x40);
                p.setColor(base);
                cv.drawCircle(x1 - i * gap, y, br, p);
            }
            return;
        }
        float y = h - 6 * u, x0 = 14 * u, x1 = w - 14 * u, th = 3 * u;
        p.setColor(al(P[3], 0x30));
        cv.drawRoundRect(new RectF(x0, y - th / 2, x1, y + th / 2), th, th, p);
        if (prog > 0) {
            p.setColor(P[3]);
            if ("neon".equals(st)) p.setMaskFilter(new BlurMaskFilter(3 * u, BlurMaskFilter.Blur.NORMAL));
            cv.drawRoundRect(new RectF(x1 - (x1 - x0) * prog, y - th / 2, x1, y + th / 2), th, th, p); // من اليمين لليسار
            p.setMaskFilter(null);
        }
    }
}
