package com.albaqiyat.app;

import android.content.Context;
import android.graphics.Color;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

/** بيانات الودجت: الصلاة الحالية والقادمة ووقت الإقامة، محسوبة من الأوقات المحفوظة */
public class WidgetModel {
    public boolean ok = false;
    public String city = "";
    public JSONObject day;        // اليوم المعروض
    public JSONObject cur, next, after;
    public int curIdx = -1, nextIdx = -1; // داخل عناصر اليوم المعروض
    public boolean iqPhase = false;       // بين الأذان والإقامة
    public long target = 0, fromAt = 0;   // العدّ التنازلي ونقطة البداية لشريط التقدم
    public int c1 = 0xFF0F5132, c2 = 0xFF0B3A27, gold = 0xFFD8B45A;
    public String orn = "star";      // شكل الزخرفة: star / lattice / circles / crescent / dots / none
    public boolean custom = false;   // تدرّج مختار من مكتبة الألوان (بدل لون الثيم)
    public int[] grad = null;        // ألوان التدرّج بالترتيب (لونان أو أكثر)
    public String look = "classic";  // النمط: classic / glass / clear
    // ── نظام المظاهر (الإصدار 2): إعدادات محلولة مسبقاً في التطبيق ──
    public boolean sk = false;
    public int[] cols = null;
    public String fill = "linear", material = "none", font = "sans", weight = "normal", iconStyle = "line";
    public int alpha = 100, shIn = 0, shOut = 0, glow = 0, reflect = 0;
    public float frameW = 1.2f, radius = 24, pad = 14, fsize = 1f, iconSize = 1f;
    public int frame = 0xFFD8B45A, text = 0xFFFFFFFF, text2 = 0xC8FFFFFF, icon = 0xFFF3D98B, accent = 0xFFF3D98B, avg = 0xFF0F5132;
    public boolean tshadow = false, timeSky = true, clock24 = false;
    public String arcMode = "auto";
    public String[] arcPhotos = null;
    public boolean muted = false;
    public JSONObject alerts;
    // الطقس (يُحدَّث عند توفر الإنترنت)
    public boolean wx = false;
    public String temp = "", wdesc = "", wemoji = "", minmax = "";
    // مرحلة اليوم: fajr / morning / dhuhr / sunset / night
    public String phase = "night";
    public long sunrise = 0, sunset = 0;

    static class Entry { JSONObject o; int day; int idx; Entry(JSONObject o, int d, int i) { this.o = o; day = d; idx = i; } }

    static int color(String s, int def) {
        try { return s == null || s.isEmpty() ? def : Color.parseColor(s); } catch (Exception e) { return def; }
    }

    public static WidgetModel load(Context c) { return load(c, null); }

    /** تحميل المظهر: الخاص بنوع الويدجت إن وُجد، وإلا العام */
    void applySkin(JSONObject k) {
        if (k == null) return;
        sk = true;
        JSONArray a = k.optJSONArray("colors");
        if (a != null && a.length() > 0) { cols = new int[a.length()]; for (int i = 0; i < cols.length; i++) cols[i] = color(a.optString(i), 0xFF0F5132); }
        else cols = new int[]{0xFF0F5132};
        fill = k.optString("fill", "linear"); material = k.optString("material", "none");
        alpha = k.optInt("alpha", 100); shIn = k.optInt("shIn", 0); shOut = k.optInt("shOut", 0); glow = k.optInt("glow", 0); reflect = k.optInt("reflect", 0);
        frameW = (float) k.optDouble("frameW", 1.2); radius = (float) k.optDouble("radius", 24); pad = (float) k.optDouble("pad", 14);
        fsize = (float) k.optDouble("fsize", 1); iconSize = (float) k.optDouble("iconSize", 1);
        frame = color(k.optString("frame"), frame); text = color(k.optString("text"), text); text2 = color(k.optString("text2"), text2);
        icon = color(k.optString("icon"), icon); accent = color(k.optString("accent"), accent); avg = color(k.optString("avg"), avg);
        font = k.optString("font", "sans"); weight = k.optString("weight", "normal"); iconStyle = k.optString("iconStyle", "line");
        arcMode = k.optString("arcMode", "auto");
        JSONArray ap = k.optJSONArray("arcPhotos");
        if (ap != null && ap.length() > 0) { arcPhotos = new String[ap.length()]; for (int i = 0; i < ap.length(); i++) arcPhotos[i] = ap.optString(i); }
        orn = k.optString("orn", "star"); tshadow = k.optBoolean("shadow", false); timeSky = k.optBoolean("timeSky", true); clock24 = k.optBoolean("clock24", false);
        // توافق مع الرسم السابق
        c1 = cols[cols.length - 1]; c2 = cols[0]; gold = accent; custom = true; grad = cols.length >= 2 ? cols : null; look = "classic";
    }

    public static WidgetModel load(Context c, String kind) {
        WidgetModel m = new WidgetModel();
        WSkinArt.ctx = c.getApplicationContext();
        JSONObject w;
        try { w = new JSONObject(AlarmScheduler.prefs(c).getString("widget", "{}")); } catch (JSONException e) { w = new JSONObject(); }
        m.muted = AlarmScheduler.prefs(c).getBoolean("muted", false);
        m.city = w.optString("city", "");
        m.alerts = w.optJSONObject("alerts");
        JSONObject th = w.optJSONObject("theme");
        if (th != null) {
            m.c1 = color(th.optString("c1"), m.c1);
            m.c2 = color(th.optString("c2"), m.c2);
            m.gold = color(th.optString("gold"), m.gold);
        }
        // مظهر الويدجت المختار من «معرض الويدجت» (يتقدّم على لون الثيم)
        JSONObject ws = null;
        try { ws = new JSONObject(AlarmScheduler.prefs(c).getString("wstyle", "{}")); } catch (Exception ignored) {}
        if (ws != null && ws.optInt("v", 0) >= 2) {
            JSONObject kk = ws.optJSONObject("k");
            JSONObject own = kind != null && kk != null ? kk.optJSONObject(kind) : null;
            m.applySkin(own != null ? own : ws.optJSONObject("g"));
        } else if (ws != null) {
            if (ws.has("c1")) { m.c1 = color(ws.optString("c1"), m.c1); m.c2 = color(ws.optString("c2"), m.c2); m.gold = color(ws.optString("gold"), m.gold); m.custom = true; }
            JSONArray cols = ws.optJSONArray("cols");
            if (cols != null && cols.length() >= 2) {
                int[] g = new int[Math.min(6, cols.length())];
                for (int i = 0; i < g.length; i++) g[i] = color(cols.optString(i), i == 0 ? m.c2 : m.c1);
                m.grad = g; m.custom = true;
            }
            m.orn = ws.optString("orn", "star");
            m.look = ws.optString("look", "classic");
        }
        JSONArray days = w.optJSONArray("days");
        if (days == null) return m;
        List<Entry> P = new ArrayList<>();
        for (int d = 0; d < days.length(); d++) {
            JSONObject dd = days.optJSONObject(d);
            JSONArray it = dd == null ? null : dd.optJSONArray("items");
            if (it == null) continue;
            for (int i = 0; i < it.length(); i++) {
                JSONObject o = it.optJSONObject(i);
                if (o != null && !"sunrise".equals(o.optString("k")) && o.optLong("at", 0) > 0) P.add(new Entry(o, d, i));
            }
        }
        long now = System.currentTimeMillis();
        int n = -1;
        for (int i = 0; i < P.size(); i++) if (P.get(i).o.optLong("at") > now) { n = i; break; }
        if (n < 0) return m;
        Entry nx = P.get(n);
        Entry cu = n > 0 ? P.get(n - 1) : null;
        m.next = nx.o;
        m.after = n + 1 < P.size() ? P.get(n + 1).o : null;
        m.cur = cu != null ? cu.o : null;
        long iq = cu != null ? cu.o.optLong("iq", 0) : 0;
        m.iqPhase = cu != null && iq > now;
        Entry shown = m.iqPhase ? cu : nx;
        m.day = days.optJSONObject(shown.day);
        if (m.iqPhase) {
            m.target = iq;
            m.fromAt = cu.o.optLong("at");
            m.curIdx = cu.idx;
            m.nextIdx = nx.day == cu.day ? nx.idx : -1;
        } else {
            m.target = nx.o.optLong("at");
            m.fromAt = cu != null ? (cu.o.optLong("iq", 0) > 0 ? cu.o.optLong("iq") : cu.o.optLong("at")) : now;
            m.nextIdx = nx.idx;
            m.curIdx = cu != null && cu.day == nx.day ? cu.idx : -1;
        }
        m.ok = true;
        m.loadWeather(c);
        m.computePhase(now);
        return m;
    }

    /** أقرب لحظة يتغيّر فيها الودجت (أذان أو إقامة) */
    public static long nextChange(Context c) {
        WidgetModel m = load(c);
        if (!m.ok) return 0;
        return m.target;
    }

    void loadWeather(Context c) {
        try {
            JSONObject x = new JSONObject(AlarmScheduler.prefs(c).getString("wx", "{}"));
            if (!x.has("t")) return;
            long at = AlarmScheduler.prefs(c).getLong("wx_at", 0);
            // عند انقطاع الإنترنت يبقى آخر قياس محفوظ ظاهراً (لا يُستبدل بعلامة ؟)
            int code = x.optInt("code", 1);
            boolean day = x.optInt("day", 1) == 1;
            wx = true;
            temp = Math.round(x.optDouble("t")) + "°";
            wdesc = WeatherFetcher.desc(code);
            wemoji = WeatherFetcher.emoji(code, day);
            double mx = x.optDouble("max", Double.NaN), mn = x.optDouble("min", Double.NaN);
            if (!Double.isNaN(mx) && !Double.isNaN(mn)) minmax = "العظمى " + Math.round(mx) + "° | الصغرى " + Math.round(mn) + "°";
        } catch (Exception ignored) {}
    }

    long at(String k) {
        JSONArray it = items();
        if (it == null) return 0;
        for (int i = 0; i < it.length(); i++) {
            JSONObject o = it.optJSONObject(i);
            if (o != null && k.equals(o.optString("k"))) return o.optLong("at", 0);
        }
        return 0;
    }

    public JSONObject item(String k) {
        JSONArray it = items();
        if (it == null) return null;
        for (int i = 0; i < it.length(); i++) {
            JSONObject o = it.optJSONObject(i);
            if (o != null && k.equals(o.optString("k"))) return o;
        }
        return null;
    }

    void computePhase(long now) {
        sunrise = at("sunrise");
        sunset = at("maghrib");
        String k = cur != null ? cur.optString("k") : "";
        long sr = sunrise;
        if ("fajr".equals(k)) phase = (sr > 0 && now >= sr) ? "morning" : "fajr";
        else if ("dhuhr".equals(k)) phase = "dhuhr";
        else if ("asr".equals(k)) phase = "sunset";
        else if ("maghrib".equals(k)) phase = (now - cur.optLong("at") < 25 * 60 * 1000L) ? "sunset" : "night";
        else phase = "night";
    }

    public boolean isDay() { return "morning".equals(phase) || "dhuhr".equals(phase) || "fajr".equals(phase); }

    public String d(String key) { return day != null ? day.optString(key, "") : ""; }

    public JSONArray items() { return day != null ? day.optJSONArray("items") : null; }

    public int progress() {
        long now = System.currentTimeMillis();
        long span = target - fromAt;
        if (span <= 0) return 0;
        long p = (now - fromAt) * 1000 / span;
        return (int) Math.max(0, Math.min(1000, p));
    }

    public boolean alertOn(String type, String k) {
        if (alerts == null) return true;
        JSONObject a = alerts.optJSONObject(type);
        return a != null && a.optBoolean(k, false);
    }
}
