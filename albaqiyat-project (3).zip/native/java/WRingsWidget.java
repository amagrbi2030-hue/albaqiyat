package com.albaqiyat.app;

public class WRingsWidget extends BaseWidget {
    @Override
    protected String kind() { return "rings"; }
}
