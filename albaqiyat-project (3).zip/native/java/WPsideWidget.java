package com.albaqiyat.app;

public class WPsideWidget extends BaseWidget {
    @Override
    protected String kind() { return "pside"; }
}
