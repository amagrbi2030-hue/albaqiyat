package com.albaqiyat.app;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.Locale;

/**
 * «مسبحة بلمسة»: تخزين دائم وآمن من التداخل لعدّادات ويدجت التسبيح.
 * لكل نسخة ويدجت إعداداتها المستقلة (w_<id>) وعدّاد مستقل لكل ذكر فيها،
 * وسجل تاريخي منفصل (hist / goals / sess) لا يتأثر بتصفير الورد.
 */
final class TasbihStore {
    private TasbihStore() {}
    static final Object LOCK = new Object();

    static SharedPreferences p(Context c) { return c.getSharedPreferences("tasbih_w", Context.MODE_PRIVATE); }

    static String today() { return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date()); }

    static JSONArray list(Context c) {
        try {
            JSONArray a = new JSONArray(p(c).getString("list", "[]"));
            if (a.length() > 0) return a;
        } catch (Exception ignored) {}
        JSONArray a = new JSONArray();
        String[][] d = {{"s1", "سُبْحَانَ اللَّهِ"}, {"s2", "الْحَمْدُ لِلَّهِ"}, {"s3", "اللَّهُ أَكْبَرُ"}, {"s4", "لَا إِلَهَ إِلَّا اللَّهُ"}, {"s5", "أَسْتَغْفِرُ اللَّهَ"}, {"s6", "اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ"}, {"s7", "لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ"}, {"s8", "لَّآ إِلَٰهَ إِلَّآ أَنتَ سُبْحَٰنَكَ إِنِّى كُنتُ مِنَ ٱلظَّٰلِمِينَ"}};
        try { for (String[] x : d) a.put(new JSONObject().put("id", x[0]).put("t", x[1])); } catch (Exception ignored) {}
        return a;
    }

    static String text(Context c, String id) {
        JSONArray a = list(c);
        for (int i = 0; i < a.length(); i++) { JSONObject o = a.optJSONObject(i); if (o != null && id.equals(o.optString("id"))) return o.optString("t"); }
        return a.length() > 0 ? a.optJSONObject(0).optString("t") : "";
    }

    static int indexOf(JSONArray a, String id) {
        for (int i = 0; i < a.length(); i++) { JSONObject o = a.optJSONObject(i); if (o != null && id.equals(o.optString("id"))) return i; }
        return -1;
    }

    static String shift(Context c, String id, int d) {
        JSONArray a = list(c);
        if (a.length() == 0) return id;
        int i = indexOf(a, id);
        i = ((i < 0 ? 0 : i) + d + a.length()) % a.length();
        return a.optJSONObject(i).optString("id");
    }

    static JSONObject defaults() {
        JSONObject o = new JSONObject();
        try {
            o.put("kind", "single").put("style", "green").put("dhikr", "s1").put("target", 33).put("onGoal", "ask")
             .put("vib", true).put("snd", false).put("counts", new JSONObject()).put("rounds", new JSONObject())
             .put("idx", 0).put("multi", new JSONArray().put("s1").put("s2").put("s3")).put("alpha", 100).put("orn", 1).put("fs", 1.0).put("ar", false);
        } catch (Exception ignored) {}
        return o;
    }

    static JSONObject cfg(Context c, int id) {
        synchronized (LOCK) {
            String s = p(c).getString("w_" + id, null);
            try { if (s != null) return merge(defaults(), new JSONObject(s)); } catch (Exception ignored) {}
            return null;
        }
    }

    static JSONObject merge(JSONObject base, JSONObject over) {
        try { Iterator<String> it = over.keys(); while (it.hasNext()) { String k = it.next(); base.put(k, over.get(k)); } } catch (Exception ignored) {}
        return base;
    }

    /** إنشاء إعدادات نسخة جديدة من القالب الذي جهّزه التطبيق (أو الافتراضي) */
    static JSONObject ensure(Context c, int id, String kind) {
        synchronized (LOCK) {
            JSONObject o = cfg(c, id);
            if (o != null) return o;
            JSONObject t = defaults();
            try { t = merge(t, new JSONObject(p(c).getString("tpl", "{}"))); } catch (Exception ignored) {}
            try {
                t.put("counts", new JSONObject()); t.put("rounds", new JSONObject()); t.put("stopped", false); t.put("done", false); t.put("msg", "");
                if ("tbm".equals(kind)) t.put("kind", "multi"); // ويدجت «متعدد الأذكار» دائماً متعددة؛ البقية تتبع القالب
            } catch (Exception ignored) {}
            p(c).edit().putString("w_" + id, t.toString()).commit();
            return t;
        }
    }

    static void save(Context c, int id, JSONObject o) {
        synchronized (LOCK) { p(c).edit().putString("w_" + id, o.toString()).commit(); }
    }

    static void remove(Context c, int id) {
        synchronized (LOCK) { p(c).edit().remove("w_" + id).commit(); }
    }

    static String current(JSONObject o) {
        if ("multi".equals(o.optString("kind"))) {
            JSONArray m = o.optJSONArray("multi");
            if (m != null && m.length() > 0) return m.optString(Math.max(0, Math.min(m.length() - 1, o.optInt("idx", 0))));
        }
        return o.optString("dhikr", "s1");
    }

    static int count(JSONObject o, String d) { JSONObject k = o.optJSONObject("counts"); return k == null ? 0 : k.optInt(d, 0); }

    /** نتيجة اللمسة: 0 لا شيء، 1 زيادة، 2 اكتمال الهدف، 3 بانتظار الاختيار بعد الهدف */
    static int inc(Context c, int id, String d) {
        synchronized (LOCK) {
            JSONObject o = cfg(c, id);
            if (o == null) return 0;
            try {
                if (o.optBoolean("done", false)) return 3; // بانتظار: دورة جديدة / التالي / إيقاف
                if (d == null || d.isEmpty()) d = current(o);
                else if ("multi".equals(o.optString("kind"))) { JSONArray m = o.optJSONArray("multi"); for (int i = 0; m != null && i < m.length(); i++) if (d.equals(m.optString(i))) o.put("idx", i); }
                JSONObject k = o.optJSONObject("counts"); if (k == null) { k = new JSONObject(); o.put("counts", k); }
                int target = o.optInt("target", 33), n = count(o, d);
                if (o.optBoolean("stopped", false)) { o.put("stopped", false); n = 0; }
                else if (target > 0 && n >= target) n = 0; // دورة جديدة بعد اكتمال سابق
                n++;
                k.put(d, n);
                o.put("last", System.currentTimeMillis());
                o.put("msg", "");
                int res = 1;
                if (target > 0 && n == target) {
                    res = 2;
                    JSONObject r = o.optJSONObject("rounds"); if (r == null) { r = new JSONObject(); o.put("rounds", r); }
                    r.put(d, r.optInt(d, 0) + 1);
                    goal(c);
                    String g = o.optString("onGoal", "ask");
                    if ("next".equals(g)) { o.put("msg", "اكتمل ✓ إلى التالي"); advance(c, o); }
                    else if ("stop".equals(g)) { o.put("stopped", true); o.put("msg", "اكتمل ✓ تقبّل الله"); }
                    else if ("round".equals(g)) o.put("msg", "اكتمل ✓ المس لدورة جديدة");
                    else { o.put("done", true); o.put("msg", "اكتمل ✓ تقبّل الله"); }
                }
                p(c).edit().putString("w_" + id, o.toString()).commit();
                hist(c, d, 1);
                return res;
            } catch (Exception e) { return 0; }
        }
    }

    /** ينقل للذكر التالي ويبدأ عدّه من الصفر إن كان مكتملاً */
    static void advance(Context c, JSONObject o) throws Exception {
        JSONObject k = o.optJSONObject("counts"); if (k == null) { k = new JSONObject(); o.put("counts", k); }
        String nx;
        if ("multi".equals(o.optString("kind"))) { JSONArray m = o.optJSONArray("multi"); int L = m == null ? 1 : Math.max(1, m.length()); int ni = (o.optInt("idx", 0) + 1) % L; o.put("idx", ni); nx = m == null ? current(o) : m.optString(ni); }
        else { nx = shift(c, o.optString("dhikr", "s1"), 1); o.put("dhikr", nx); }
        int t = o.optInt("target", 33);
        if (t > 0 && k.optInt(nx, 0) >= t) k.put(nx, 0);
    }

    /** اختيار المستخدم بعد اكتمال الهدف: round / next / stop */
    static void choose(Context c, int id, String what) {
        synchronized (LOCK) {
            JSONObject o = cfg(c, id);
            if (o == null) return;
            try {
                o.put("done", false); o.put("msg", "");
                if ("next".equals(what)) advance(c, o);
                else if ("stop".equals(what)) { o.put("stopped", true); o.put("msg", "متوقّف — المس للبدء"); }
                else o.optJSONObject("counts").put(current(o), 0);
                p(c).edit().putString("w_" + id, o.toString()).commit();
            } catch (Exception ignored) {}
        }
    }

    static void undo(Context c, int id) {
        synchronized (LOCK) {
            JSONObject o = cfg(c, id);
            if (o == null) return;
            try {
                String d = current(o);
                int n = count(o, d);
                if (n <= 0) return;
                o.getJSONObject("counts").put(d, n - 1);
                o.put("msg", ""); o.put("done", false); o.put("stopped", false);
                p(c).edit().putString("w_" + id, o.toString()).commit();
                hist(c, d, -1);
            } catch (Exception ignored) {}
        }
    }

    static void reset(Context c, int id) {
        synchronized (LOCK) {
            JSONObject o = cfg(c, id);
            if (o == null) return;
            try { o.optJSONObject("counts").put(current(o), 0); o.put("msg", ""); o.put("done", false); o.put("stopped", false); p(c).edit().putString("w_" + id, o.toString()).commit(); } catch (Exception ignored) {}
        }
    }

    static void move(Context c, int id, int dir) {
        synchronized (LOCK) {
            JSONObject o = cfg(c, id);
            if (o == null) return;
            try {
                if ("multi".equals(o.optString("kind"))) { JSONArray m = o.optJSONArray("multi"); int L = m == null ? 1 : Math.max(1, m.length()); o.put("idx", (o.optInt("idx", 0) + dir + L) % L); }
                else o.put("dhikr", shift(c, o.optString("dhikr", "s1"), dir));
                o.put("msg", ""); o.put("done", false); o.put("stopped", false);
                p(c).edit().putString("w_" + id, o.toString()).commit();
            } catch (Exception ignored) {}
        }
    }

    static void select(Context c, int id, String d) {
        synchronized (LOCK) {
            JSONObject o = cfg(c, id);
            if (o == null || d == null) return;
            try { o.put("dhikr", d); o.put("msg", ""); p(c).edit().putString("w_" + id, o.toString()).commit(); } catch (Exception ignored) {}
        }
    }

    // ── السجل التاريخي (لا يتأثر بتصفير الورد) ──
    static void hist(Context c, String d, int delta) {
        try {
            SharedPreferences sp = p(c);
            JSONObject h = new JSONObject(sp.getString("hist", "{}"));
            String day = today();
            JSONObject t = h.optJSONObject(day); if (t == null) { t = new JSONObject(); h.put(day, t); }
            t.put(d, Math.max(0, t.optInt(d, 0) + delta));
            // الإبقاء على آخر ٤٠٠ يوم
            if (h.length() > 400) { String min = null; Iterator<String> it = h.keys(); while (it.hasNext()) { String k = it.next(); if (min == null || k.compareTo(min) < 0) min = k; } if (min != null) h.remove(min); }
            JSONArray s = new JSONArray(sp.getString("sess", "[]"));
            long now = System.currentTimeMillis();
            JSONObject last = s.length() > 0 ? s.optJSONObject(s.length() - 1) : null;
            if (delta > 0) {
                if (last != null && d.equals(last.optString("d")) && now - last.optLong("e") < 10 * 60 * 1000L) { last.put("e", now); last.put("n", last.optInt("n") + 1); }
                else { s.put(new JSONObject().put("s", now).put("e", now).put("d", d).put("n", 1).put("src", "w")); }
                while (s.length() > 200) s.remove(0);
            } else if (last != null && d.equals(last.optString("d")) && last.optInt("n") > 0) last.put("n", last.optInt("n") - 1);
            sp.edit().putString("hist", h.toString()).putString("sess", s.toString()).commit();
        } catch (Exception ignored) {}
    }

    static void goal(Context c) {
        try {
            JSONObject g = new JSONObject(p(c).getString("goals", "{}"));
            String day = today();
            g.put(day, g.optInt(day, 0) + 1);
            p(c).edit().putString("goals", g.toString()).commit();
        } catch (Exception ignored) {}
        if (p(c).getBoolean("goalNotif", false)) notify(c, 4790, "اكتمل هدف التسبيح ✓", "تقبّل الله منك — يمكنك بدء دورة جديدة من الويدجت");
    }

    static JSONObject stats(Context c) {
        JSONObject r = new JSONObject();
        try {
            r.put("hist", new JSONObject(p(c).getString("hist", "{}")));
            r.put("goals", new JSONObject(p(c).getString("goals", "{}")));
            r.put("sess", new JSONArray(p(c).getString("sess", "[]")));
        } catch (Exception ignored) {}
        return r;
    }

    static void resetStats(Context c) { p(c).edit().remove("hist").remove("goals").remove("sess").commit(); }

    // ── الإشعارات والتذكيرات ──
    static final String CH = "tasbih_v1";
    static final String ACTION_REMIND = "com.albaqiyat.app.TB_REMIND";

    static void notify(Context c, int nid, String title, String body) {
        try {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(CH) == null) {
                NotificationChannel ch = new NotificationChannel(CH, "تذكير التسبيح", NotificationManager.IMPORTANCE_DEFAULT);
                ch.setDescription("تذكيرات الورد واكتمال هدف التسبيح");
                nm.createNotificationChannel(ch);
            }
            Intent li = c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
            PendingIntent pi = li == null ? null : PendingIntent.getActivity(c, 99310, li, AlarmScheduler.piFlags());
            android.app.Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new android.app.Notification.Builder(c, CH) : new android.app.Notification.Builder(c);
            int icon = c.getResources().getIdentifier("ic_stat_salah", "drawable", c.getPackageName());
            b.setSmallIcon(icon != 0 ? icon : android.R.drawable.ic_popup_reminder).setContentTitle(title).setContentText(body).setAutoCancel(true);
            if (pi != null) b.setContentIntent(pi);
            nm.notify(nid, b.build());
        } catch (Exception ignored) {}
    }

    /** يجدول أقرب تذكير قادم (منبّه غير دقيق لتوفير البطارية) */
    static void scheduleReminders(Context c) {
        try {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            Intent i = new Intent(c, TasbihReceiver.class);
            i.setAction(ACTION_REMIND);
            PendingIntent pi = PendingIntent.getBroadcast(c, 99300, i, AlarmScheduler.piFlags());
            if (am == null) return;
            am.cancel(pi);
            JSONObject r = new JSONObject(p(c).getString("rem", "{}"));
            if (!r.optBoolean("on", false)) return;
            JSONArray L = r.optJSONArray("list");
            if (L == null || L.length() == 0) return;
            long now = System.currentTimeMillis(), best = Long.MAX_VALUE;
            for (int d = 0; d < 8; d++) {
                for (int k = 0; k < L.length(); k++) {
                    JSONObject x = L.optJSONObject(k);
                    if (x == null) continue;
                    Calendar cal = Calendar.getInstance();
                    cal.add(Calendar.DAY_OF_YEAR, d);
                    cal.set(Calendar.HOUR_OF_DAY, x.optInt("h", 6)); cal.set(Calendar.MINUTE, x.optInt("m", 0)); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0);
                    int dow = cal.get(Calendar.DAY_OF_WEEK) - 1; // 0 = الأحد
                    JSONArray days = x.optJSONArray("days");
                    boolean ok = days == null || days.length() == 0;
                    for (int j = 0; days != null && j < days.length(); j++) if (days.optInt(j) == dow) ok = true;
                    long t = cal.getTimeInMillis();
                    if (ok && t > now + 30000 && t < best) best = t;
                }
            }
            if (best == Long.MAX_VALUE) return;
            if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, best, pi);
            else am.set(AlarmManager.RTC_WAKEUP, best, pi);
        } catch (Exception ignored) {}
    }
}
