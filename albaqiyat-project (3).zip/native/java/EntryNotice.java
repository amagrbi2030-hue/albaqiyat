package com.albaqiyat.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import org.json.JSONObject;

/**
 * إشعار «دخول وقت الصلاة» أو «حان وقت الإقامة» دون صوت الأذان/الإقامة —
 * يُستخدم عندما يكون صوت هذه الصلاة متوقفاً في هذا اليوم حسب «الجدولة الأسبوعية» أو «الاستثناءات بالتاريخ»،
 * فيبقى الإشعار مستقلاً عن الصوت (إشعار هادئ بلا صوت مع اهتزاز خفيف).
 */
public class EntryNotice {
    static final String CH = "prayer_entry_v1";
    static final int NID_ADHAN = 4770, NID_IQAMA = 4771, NID_IQPRE = 4772;

    static final int NID_TEST = 4779;

    static void channel(NotificationManager nm) {
        if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(CH) == null) {
            NotificationChannel ch = new NotificationChannel(CH, "دخول وقت الصلاة (دون صوت)", NotificationManager.IMPORTANCE_DEFAULT);
            ch.setDescription("إشعار دخول وقت الصلاة ووقت الإقامة في الأيام التي يكون فيها الصوت متوقفاً حسب الجدولة، واقتراب الإقامة");
            ch.setSound(null, null);
            ch.enableVibration(true);
            ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            nm.createNotificationChannel(ch);
        }
    }

    /** إشعار تجريبي صامت بالنمط المختار */
    static void postTest(Context c, JSONObject ev) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        channel(nm);
        Intent li = c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
        if (li == null) li = new Intent(c, MainActivity.class);
        li.putExtra("route", "ntfStudio");
        PendingIntent pi = PendingIntent.getActivity(c, 8, li, AlarmScheduler.piFlags());
        int icon = c.getResources().getIdentifier("ic_stat_salah", "drawable", c.getPackageName());
        if (icon == 0) icon = android.R.drawable.ic_lock_idle_alarm;
        NStyle.Info in = NStyle.fromJson(ev);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, CH) : new Notification.Builder(c);
        b.setSmallIcon(icon).setContentTitle(in.title).setContentText(in.sub)
                .setStyle(new Notification.BigTextStyle().bigText(in.sub))
                .setColor(0xFFC69A3A).setAutoCancel(true).setOnlyAlertOnce(true)
                .setVisibility(Notification.VISIBILITY_PUBLIC).setContentIntent(pi)
                .setTimeoutAfter(10 * 60 * 1000L);
        if (in.target > System.currentTimeMillis() && Build.VERSION.SDK_INT >= 24) { b.setWhen(in.target).setShowWhen(true).setUsesChronometer(true).setChronometerCountDown(true); }
        if (Build.VERSION.SDK_INT < 26) { b.setPriority(Notification.PRIORITY_DEFAULT); b.setSound(null); }
        try { NStyle.apply(c, b, in); } catch (Throwable ignored) {}
        try { nm.notify(NID_TEST, b.build()); } catch (Exception ignored) {}
    }

    static void post(Context c, JSONObject ev) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(CH) == null) {
            NotificationChannel ch = new NotificationChannel(CH, "دخول وقت الصلاة (دون صوت)", NotificationManager.IMPORTANCE_DEFAULT);
            ch.setDescription("إشعار دخول وقت الصلاة ووقت الإقامة في الأيام التي يكون فيها الصوت متوقفاً حسب الجدولة");
            ch.setSound(null, null);
            ch.enableVibration(true);
            ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            nm.createNotificationChannel(ch);
        }
        boolean iq = "iqama".equals(ev.optString("kind"));
        Intent li = c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
        if (li == null) li = new Intent(c, MainActivity.class);
        li.putExtra("route", "prayer");
        PendingIntent pi = PendingIntent.getActivity(c, iq ? 7 : 6, li, AlarmScheduler.piFlags());
        int icon = c.getResources().getIdentifier("ic_stat_salah", "drawable", c.getPackageName());
        if (icon == 0) icon = android.R.drawable.ic_lock_idle_alarm;
        String body = ev.optString("time", "");
        String city = ev.optString("city", "");
        if (!city.isEmpty()) body = body.isEmpty() ? city : body + " · " + city;
        body = (body.isEmpty() ? "" : body + " · ") + (iq ? "صوت الإقامة متوقف اليوم حسب الجدولة" : "صوت الأذان متوقف اليوم حسب الجدولة");
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, CH) : new Notification.Builder(c);
        b.setSmallIcon(icon)
                .setContentTitle(ev.optString("title", iq ? "حان وقت الإقامة" : "حان وقت الصلاة"))
                .setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body))
                .setColor(0xFFC69A3A)
                .setAutoCancel(true)
                .setCategory(Notification.CATEGORY_REMINDER)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setContentIntent(pi)
                .setTimeoutAfter(60 * 60 * 1000L);
        if (Build.VERSION.SDK_INT < 26) { b.setPriority(Notification.PRIORITY_DEFAULT); b.setDefaults(Notification.DEFAULT_VIBRATE); b.setSound(null); }
        String nk = ev.optString("nkind", iq ? "iqama" : "adhan");
        try { NStyle.Info info = NStyle.fromEvent(c, ev, nk); info.sub = body; NStyle.apply(c, b, info); } catch (Throwable ignored) {}
        int nid = "iqpre".equals(ev.optString("nkind")) ? NID_IQPRE : (iq ? NID_IQAMA : NID_ADHAN);
        try { nm.notify(nid, b.build()); } catch (Exception ignored) {}
    }
}
