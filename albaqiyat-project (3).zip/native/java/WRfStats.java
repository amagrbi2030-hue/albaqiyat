package com.albaqiyat.app;

public class WRfStats extends RafiqWidget {
    @Override
    protected String kind() { return "rstats"; }
}
