package com.albaqiyat.app;

import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;

/**
 * رسم خلفية الويدجت حسب «نظام المظاهر»: التعبئة (لون/لونان/ثلاثة — خطي/قطري/شعاعي) والشفافية،
 * والخامة (زجاج شفاف/ضبابي، معدن مصقول/مطفي، رخام، لؤلؤ، ملمس ناعم)، والظلال والتوهج والانعكاس والزخرفة والإطار.
 * يطابق معاينة التطبيق (wSkinCSS / wMarbleSVG / wNoiseSVG) بنفس المولّد العشوائي الثابت.
 */
final class WSkinArt {
    private WSkinArt() {}

    static int alpha(int c, int a) { return (c & 0x00FFFFFF) | (Math.max(0, Math.min(255, a)) << 24); }

    /** المستطيل الداخلي بعد ترك مساحة للظل الخارجي */
    static RectF inner(int w, int h, float k, WidgetModel m) {
        float s = m.shOut > 0 ? (m.shOut / 3f) * k * 0.6f : 0;
        float half = m.frameW > 0 ? m.frameW * k / 2f : 0;
        return new RectF(s + half, Math.max(0, s - m.shOut / 8f * k) + half, w - s - half, h - s - m.shOut / 8f * k * 0.5f - half);
    }

    static float rad(WidgetModel m, float k) { return Math.max(0, m.radius) * k; }

    static Path shape(RectF r, float rad) {
        Path p = new Path();
        p.addRoundRect(r, rad, rad, Path.Direction.CW);
        return p;
    }

    /** الظل الخارجي (يُرسم قبل القص) */
    static void outerShadow(Canvas cv, RectF r, float rad, float k, WidgetModel m) {
        if (m.shOut <= 0) return;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(alpha(0xFF000000, (int) (255 * Math.min(.45f, m.shOut / 160f) * Math.max(.35f, m.alpha / 100f))));
        p.setMaskFilter(new BlurMaskFilter(Math.max(1f, m.shOut / 3f * k * 0.6f), BlurMaskFilter.Blur.NORMAL));
        RectF o = new RectF(r);
        o.offset(0, m.shOut / 8f * k);
        cv.drawRoundRect(o, rad, rad, p);
    }

    /** مولّد Park–Miller نفسه في التطبيق (wRng) */
    static final class Rng {
        long s;
        Rng(long seed) { s = seed % 2147483647L; if (s <= 0) s += 2147483646L; }
        float next() { s = s * 16807L % 2147483647L; return s / 2147483647f; }
    }

    /** التعبئة + الخامة + التوهج + الانعكاس + الظل الداخلي + الزخرفة (القص على الشكل مطبّق مسبقاً) */
    static void paint(Canvas cv, RectF r, float k, WidgetModel m, int[] sky) {
        float w = r.width(), h = r.height(), x0 = r.left, y0 = r.top;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        int[] c = sky != null ? sky : m.cols;
        if (c == null || c.length == 0) c = new int[]{m.c2, m.c1};
        Shader sh;
        if (c.length == 1) sh = null;
        else if (sky != null || "linear".equals(m.fill)) sh = new LinearGradient(x0, y0, x0, y0 + h, c, null, Shader.TileMode.CLAMP);
        else if ("radial".equals(m.fill)) sh = new RadialGradient(x0 + w / 2f, y0, Math.max(w, h) * 1.2f, c, null, Shader.TileMode.CLAMP);
        else sh = new LinearGradient(x0 + w, y0, x0, y0 + h, c, null, Shader.TileMode.CLAMP); // قطري من أعلى اليمين
        if (sh == null) p.setColor(c[0]); else p.setShader(sh);
        p.setAlpha(sky != null ? 255 : Math.round(m.alpha * 2.55f));
        cv.drawRect(r, p);
        p.setShader(null); p.setAlpha(255);
        String mat = m.material;
        if ("photo".equals(mat)) photo(cv, r, p);
        // ── الخامات ──
        if ("glass".equals(mat) || "frost".equals(mat) || "pearl".equals(mat)) {
            int top = "frost".equals(mat) ? 0x47 : "pearl".equals(mat) ? 0x4D : 0x38;
            int bot = "frost".equals(mat) ? 0x14 : 0x00;
            if ("frost".equals(mat)) { p.setColor(0x18FFFFFF); cv.drawRect(r, p); }
            p.setShader(new LinearGradient(0, y0, 0, y0 + h * ("frost".equals(mat) ? .6f : .5f), alpha(0xFFFFFFFF, top), alpha(0xFFFFFFFF, bot), Shader.TileMode.CLAMP));
            cv.drawRect(r, p);
            p.setShader(null);
        }
        if ("pearl".equals(mat)) {
            radial(cv, r, x0 + w * .2f, y0 + h * .2f, Math.max(w, h) * .6f, 0x59FFC8E1);
            radial(cv, r, x0 + w * .85f, y0 + h * .7f, Math.max(w, h) * .6f, 0x59BEDCFF);
            radial(cv, r, x0 + w * .6f, y0 + h * .3f, Math.max(w, h) * .4f, 0x99FFFFFF);
        }
        if ("metal".equals(mat)) {
            p.setShader(new LinearGradient(0, y0, 0, y0 + h, new int[]{0x52FFFFFF, 0x00FFFFFF, 0x38000000, 0x24FFFFFF, 0x47000000}, new float[]{0f, .18f, .46f, .54f, 1f}, Shader.TileMode.CLAMP));
            cv.drawRect(r, p);
            p.setShader(null);
            p.setColor(0x09FFFFFF);
            p.setStrokeWidth(Math.max(1f, k * .5f));
            for (float x = x0; x < x0 + w; x += 3 * k) cv.drawLine(x, y0, x, y0 + h, p);
        }
        if ("matte".equals(mat)) {
            p.setShader(new LinearGradient(0, y0, 0, y0 + h, 0x14FFFFFF, 0x1F000000, Shader.TileMode.CLAMP));
            cv.drawRect(r, p);
            p.setShader(null);
        }
        if ("soft".equals(mat)) radial(cv, r, x0 + w * .3f, y0 + h * .1f, Math.max(w, h) * .9f, 0x38FFFFFF);
        if ("marble".equals(mat)) marble(cv, r, k, luminance(m.avg) > .4 ? 0xFF7A7A7A : 0xFFFFFFFF);
        if ("matte".equals(mat) || "soft".equals(mat) || "frost".equals(mat)) noise(cv, r, k, "matte".equals(mat) ? .22f : "frost".equals(mat) ? .12f : .08f);
        // ── التوهج والانعكاس ──
        if (m.glow > 0) radial(cv, r, x0 + w * .8f, y0, Math.max(w, h) * .75f, alpha(m.accent, (int) (255 * .7f * m.glow / 100f)));
        if (m.reflect > 0) {
            float a = m.reflect / 100f;
            p.setShader(new LinearGradient(0, y0, 0, y0 + h * .42f, alpha(0xFFFFFFFF, (int) (140 * a)), 0x00FFFFFF, Shader.TileMode.CLAMP));
            cv.drawRect(r, p);
            p.setShader(new LinearGradient(x0 + w * .3f, y0, x0 + w * .55f, y0 + h * .55f, new int[]{0x00FFFFFF, alpha(0xFFFFFFFF, (int) (90 * a)), 0x00FFFFFF}, null, Shader.TileMode.CLAMP));
            cv.drawRect(r, p);
            p.setShader(null);
        }
        // ── الزخرفة الإسلامية (كما هي) ──
        WidgetArt.ornament(cv, (int) (x0 + w), (int) (y0 + h), k, m, alpha(m.accent, 0x30), 54);
        // ── الظل الداخلي ──
        if (m.shIn > 0) {
            float rr = rad(m, k);
            Paint ip = new Paint(Paint.ANTI_ALIAS_FLAG);
            ip.setStyle(Paint.Style.STROKE);
            float bw = Math.max(1f, m.shIn / 4f * k);
            ip.setStrokeWidth(bw * 2);
            ip.setColor(alpha(0xFF000000, (int) (255 * Math.min(.5f, m.shIn / 130f))));
            ip.setMaskFilter(new BlurMaskFilter(bw, BlurMaskFilter.Blur.NORMAL));
            RectF o = new RectF(r);
            o.offset(0, m.shIn / 14f * k);
            cv.drawRoundRect(o, rr, rr, ip);
            ip.setColor(alpha(0xFFFFFFFF, (int) (255 * Math.min(.25f, m.shIn / 400f))));
            o = new RectF(r);
            o.offset(0, -1 * k);
            cv.drawRoundRect(o, rr, rr, ip);
        }
        if ("glass".equals(mat)) { // خط ضوء علوي رفيع
            p.setColor(0x59FFFFFF);
            p.setStrokeWidth(Math.max(1f, k));
            cv.drawLine(x0 + rad(m, k), y0 + k, x0 + w - rad(m, k), y0 + k, p);
        }
    }

    static android.content.Context ctx;
    static final String[] PH = {"fajr", "dhuhr", "asr", "maghrib", "isha"};

    /** «الصور السينمائية للمساجد»: صورة مسجد تتبدّل يومياً (مضغوطة حسب الحجم) + تظليل سينمائي يضمن وضوح النص */
    static void photo(Canvas cv, RectF r, Paint p) {
        android.graphics.Bitmap src = null;
        try {
            if (ctx != null) {
                java.util.Calendar k = java.util.Calendar.getInstance();
                String key = PH[(k.get(java.util.Calendar.DAY_OF_YEAR) + k.get(java.util.Calendar.YEAR) * 366) % PH.length];
                int rid = ctx.getResources().getIdentifier("photo_" + key, "drawable", ctx.getPackageName());
                if (rid != 0) {
                    android.graphics.BitmapFactory.Options o = new android.graphics.BitmapFactory.Options();
                    o.inJustDecodeBounds = true;
                    android.graphics.BitmapFactory.decodeResource(ctx.getResources(), rid, o);
                    int ss = 1;
                    while (o.outWidth / (ss * 2) >= r.width() && o.outHeight / (ss * 2) >= r.height()) ss *= 2;
                    android.graphics.BitmapFactory.Options o2 = new android.graphics.BitmapFactory.Options();
                    o2.inSampleSize = ss;
                    src = android.graphics.BitmapFactory.decodeResource(ctx.getResources(), rid, o2);
                }
            }
        } catch (Throwable ignored) {}
        if (src != null) {
            float sc = Math.max(r.width() / src.getWidth(), r.height() / src.getHeight());
            float dw = src.getWidth() * sc, dh = src.getHeight() * sc;
            Paint bp = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
            cv.drawBitmap(src, null, new RectF(r.centerX() - dw / 2f, r.centerY() - dh / 2f, r.centerX() + dw / 2f, r.centerY() + dh / 2f), bp);
            src.recycle();
        }
        p.setShader(new LinearGradient(0, r.top, 0, r.bottom, new int[]{0x66000000, 0x33000000, 0xB3000000}, new float[]{0f, .45f, 1f}, Shader.TileMode.CLAMP));
        cv.drawRect(r, p);
        p.setShader(null);
    }

    /** الإطار (بعد الزخارف الخاصة) */
    static void frame(Canvas cv, RectF r, float k, WidgetModel m) {
        if (m.frameW <= 0) return;
        Paint f = new Paint(Paint.ANTI_ALIAS_FLAG);
        f.setStyle(Paint.Style.STROKE);
        f.setStrokeWidth(Math.max(1f, m.frameW * k));
        f.setColor(m.frame);
        float hw = f.getStrokeWidth() / 2f, rr = Math.max(0, rad(m, k) - hw);
        cv.drawRoundRect(new RectF(r.left + hw, r.top + hw, r.right - hw, r.bottom - hw), rr, rr, f);
    }

    static void radial(Canvas cv, RectF r, float cx, float cy, float rad, int col) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new RadialGradient(cx, cy, Math.max(1f, rad), col, col & 0x00FFFFFF, Shader.TileMode.CLAMP));
        cv.drawRect(r, p);
    }

    static double luminance(int c) {
        double[] v = {Color.red(c) / 255.0, Color.green(c) / 255.0, Color.blue(c) / 255.0};
        for (int i = 0; i < 3; i++) v[i] = v[i] <= .03928 ? v[i] / 12.92 : Math.pow((v[i] + .055) / 1.055, 2.4);
        return .2126 * v[0] + .7152 * v[1] + .0722 * v[2];
    }

    /** عروق الرخام — نفس تسلسل wMarbleSVG */
    static void marble(Canvas cv, RectF r, float k, int col) {
        Rng g = new Rng(7);
        float W = r.width() / 100f, H = r.height() / 100f, sc = Math.min(r.width(), r.height()) / 100f;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setMaskFilter(new BlurMaskFilter(Math.max(.5f, .35f * sc), BlurMaskFilter.Blur.NORMAL));
        for (int i = 0; i < 6; i++) {
            float x0 = g.next(), y0 = g.next() * .3f - .1f, x1 = g.next(), y1 = g.next() * .5f + .2f, x2 = g.next(), y2 = g.next() * .5f + .4f, x3 = g.next(), y3 = 1.1f;
            float sw = .4f + g.next() * 1.4f, a = .18f + g.next() * .25f;
            Path path = new Path();
            path.moveTo(r.left + x0 * 100 * W, r.top + y0 * 100 * H);
            path.cubicTo(r.left + x1 * 100 * W, r.top + y1 * 100 * H, r.left + x2 * 100 * W, r.top + y2 * 100 * H, r.left + x3 * 100 * W, r.top + y3 * 100 * H);
            p.setStrokeWidth(Math.max(.8f, sw * sc));
            p.setColor(alpha(col, (int) (255 * a)));
            cv.drawPath(path, p);
        }
    }

    /** حبيبات الملمس — نفس تسلسل wNoiseSVG */
    static void noise(Canvas cv, RectF r, float k, float op) {
        Rng g = new Rng(13);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float rad = Math.max(.6f, .35f * Math.min(r.width(), r.height()) / 100f);
        for (int i = 0; i < 160; i++) {
            float x = r.left + g.next() * r.width(), y = r.top + g.next() * r.height();
            boolean white = g.next() > .5f;
            float a = op * (.4f + g.next() * .6f);
            p.setColor(alpha(white ? 0xFFFFFFFF : 0xFF000000, (int) (255 * a)));
            cv.drawCircle(x, y, rad, p);
        }
    }
}
