package com.albaqiyat.app;

public class WTasbih2 extends TasbihWidget {
    @Override
    protected String kind() { return "tb2"; }
}
