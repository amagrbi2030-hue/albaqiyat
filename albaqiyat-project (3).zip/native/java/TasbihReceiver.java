package com.albaqiyat.app;

import android.appwidget.AppWidgetManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import org.json.JSONObject;
import java.util.HashMap;

/** لمسات ويدجت المسبحة، وتذكيرات الورد، وإعادة الجدولة بعد إعادة التشغيل */
public class TasbihReceiver extends BroadcastReceiver {
    static final String ACTION = "com.albaqiyat.app.TB_ACT";
    private static final HashMap<Integer, Long> LAST = new HashMap<>();
    static final long DEBOUNCE_MS = 120; // منع احتساب لمستين متتاليتين خاطفتين

    @Override
    public void onReceive(Context c, Intent in) {
        String a = in.getAction();
        if (TasbihStore.ACTION_REMIND.equals(a)) {
            String t = "حان وقت وردك من التسبيح";
            try { JSONObject r = new JSONObject(TasbihStore.p(c).getString("rem", "{}")); if (!r.optString("text").isEmpty()) t = r.optString("text"); } catch (Exception ignored) {}
            TasbihStore.notify(c, 4791, "مسبحة بلمسة", t);
            TasbihStore.scheduleReminders(c);
            return;
        }
        if (!ACTION.equals(a)) { // إقلاع/تحديث التطبيق
            TasbihStore.scheduleReminders(c);
            TasbihRender.renderAll(c);
            return;
        }
        int id = in.getIntExtra("id", -1), act = in.getIntExtra("a", 0);
        if (id < 0) return;
        JSONObject o = TasbihStore.cfg(c, id);
        if (o == null) o = TasbihStore.ensure(c, id, TasbihRender.kindOf(c, id));
        int res = 0;
        switch (act) {
            case TasbihRender.A_INC: {
                long now = android.os.SystemClock.elapsedRealtime();
                synchronized (LAST) {
                    Long l = LAST.get(id);
                    if (l != null && now - l < DEBOUNCE_MS) return;
                    LAST.put(id, now);
                }
                if (o.optBoolean("done", false) && !TasbihRender.hasChoice(c, id)) TasbihStore.choose(c, id, "round"); // ١×١ و٤×١ لا تتسع للأزرار
                res = TasbihStore.inc(c, id, in.getStringExtra("d"));
                break;
            }
            case TasbihRender.A_UNDO: TasbihStore.undo(c, id); break;
            case TasbihRender.A_PREV: TasbihStore.move(c, id, -1); break;
            case TasbihRender.A_NEXT: TasbihStore.move(c, id, 1); break;
            case TasbihRender.A_ROUND: TasbihStore.choose(c, id, "round"); break;
            case TasbihRender.A_CNEXT: TasbihStore.choose(c, id, "next"); break;
            case TasbihRender.A_CSTOP: TasbihStore.choose(c, id, "stop"); break;
            default: break;
        }
        TasbihRender.render(c, AppWidgetManager.getInstance(c), id, TasbihRender.kindOf(c, id));
        if (res == 1 || res == 2) feedback(c, o, res == 2);
    }

    static void feedback(Context c, JSONObject o, boolean goal) {
        if (o.optBoolean("vib", true)) {
            try {
                Vibrator v = (Vibrator) c.getSystemService(Context.VIBRATOR_SERVICE);
                if (v != null && v.hasVibrator()) {
                    if (Build.VERSION.SDK_INT >= 26) v.vibrate(goal ? VibrationEffect.createWaveform(new long[]{0, 60, 90, 60, 90, 120}, -1) : VibrationEffect.createOneShot(18, 160));
                    else v.vibrate(goal ? 300 : 18);
                }
            } catch (Exception ignored) {}
        }
        if (o.optBoolean("snd", false)) {
            try {
                final ToneGenerator tg = new ToneGenerator(AudioManager.STREAM_NOTIFICATION, goal ? 70 : 45);
                tg.startTone(goal ? ToneGenerator.TONE_PROP_ACK : ToneGenerator.TONE_PROP_BEEP, goal ? 220 : 40);
                new Handler(Looper.getMainLooper()).postDelayed(tg::release, 400);
            } catch (Exception ignored) {}
        }
    }
}
