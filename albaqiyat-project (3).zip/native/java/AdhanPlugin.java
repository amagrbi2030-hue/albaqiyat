package com.albaqiyat.app;

import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;
import com.getcapacitor.JSArray;
import org.json.JSONArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import org.json.JSONObject;

/** جسر بين التطبيق ونظام أندرويد: جدولة الأذان، الودجت، الأذونات */
@CapacitorPlugin(name = "Adhan")
public class AdhanPlugin extends Plugin {
    /* ═══ بوصلة القبلة: مستشعر الدوران + تصحيح الانحراف المغناطيسي (GeomagneticField = نموذج WMM) ═══ */
    private android.hardware.SensorManager qsm;
    private android.hardware.SensorEventListener qsl;
    private volatile float qDecl = 0f;
    private volatile int qAcc = 3;

    @PluginMethod
    public void compassStart(PluginCall call) {
        Context c = getContext();
        double lat = call.getDouble("lat", 0.0), lng = call.getDouble("lng", 0.0);
        JSObject r = new JSObject();
        try {
            android.hardware.GeomagneticField gf = new android.hardware.GeomagneticField((float) lat, (float) lng, 0f, System.currentTimeMillis());
            qDecl = gf.getDeclination();
        } catch (Exception e) { qDecl = 0f; }
        r.put("declination", qDecl);
        stopCompass();
        qsm = (android.hardware.SensorManager) c.getSystemService(Context.SENSOR_SERVICE);
        android.hardware.Sensor rv = qsm == null ? null : qsm.getDefaultSensor(android.hardware.Sensor.TYPE_ROTATION_VECTOR);
        if (rv == null) { r.put("ok", false); call.resolve(r); return; }
        final float[] R = new float[9], R2 = new float[9], O = new float[3];
        qsl = new android.hardware.SensorEventListener() {
            long last = 0;
            @Override public void onSensorChanged(android.hardware.SensorEvent e) {
                if (e.sensor.getType() == android.hardware.Sensor.TYPE_MAGNETIC_FIELD) return;
                long now = android.os.SystemClock.uptimeMillis();
                if (now - last < 40) return;
                last = now;
                android.hardware.SensorManager.getRotationMatrixFromVector(R, e.values);
                int rot = 0;
                try { rot = getActivity().getWindowManager().getDefaultDisplay().getRotation(); } catch (Exception ignored) {}
                float[] M = R;
                if (rot == android.view.Surface.ROTATION_90) { android.hardware.SensorManager.remapCoordinateSystem(R, android.hardware.SensorManager.AXIS_Y, android.hardware.SensorManager.AXIS_MINUS_X, R2); M = R2; }
                else if (rot == android.view.Surface.ROTATION_180) { android.hardware.SensorManager.remapCoordinateSystem(R, android.hardware.SensorManager.AXIS_MINUS_X, android.hardware.SensorManager.AXIS_MINUS_Y, R2); M = R2; }
                else if (rot == android.view.Surface.ROTATION_270) { android.hardware.SensorManager.remapCoordinateSystem(R, android.hardware.SensorManager.AXIS_MINUS_Y, android.hardware.SensorManager.AXIS_X, R2); M = R2; }
                android.hardware.SensorManager.getOrientation(M, O);
                float az = (float) Math.toDegrees(O[0]);
                float hd = ((az + qDecl) % 360f + 360f) % 360f; // اتجاه الهاتف من الشمال الحقيقي
                JSObject d = new JSObject();
                d.put("heading", hd);
                d.put("accuracy", qAcc);
                notifyListeners("compass", d);
            }
            @Override public void onAccuracyChanged(android.hardware.Sensor s, int a) {
                if (s.getType() == android.hardware.Sensor.TYPE_MAGNETIC_FIELD) qAcc = a;
            }
        };
        qsm.registerListener(qsl, rv, android.hardware.SensorManager.SENSOR_DELAY_GAME);
        android.hardware.Sensor mg = qsm.getDefaultSensor(android.hardware.Sensor.TYPE_MAGNETIC_FIELD);
        if (mg != null) qsm.registerListener(qsl, mg, android.hardware.SensorManager.SENSOR_DELAY_UI);
        r.put("ok", true);
        call.resolve(r);
    }

    private void stopCompass() {
        try { if (qsm != null && qsl != null) qsm.unregisterListener(qsl); } catch (Exception ignored) {}
        qsl = null;
    }

    /** فتح المساجد القريبة في تطبيق خرائط Google (أو المتصفح إن لم يوجد) */
    @PluginMethod
    public void openMap(PluginCall call) {
        Context c = getContext();
        double lat = call.getDouble("lat", 0.0), lng = call.getDouble("lng", 0.0);
        String q = call.getString("q", "مسجد"), web = call.getString("web", "https://www.google.com/maps/search/mosque");
        Intent i;
        try {
            Uri g = Uri.parse("geo:" + lat + "," + lng + "?q=" + Uri.encode(q));
            i = new Intent(Intent.ACTION_VIEW, g);
            i.setPackage("com.google.android.apps.maps");
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
            call.resolve();
            return;
        } catch (Exception ignored) {}
        try {
            i = new Intent(Intent.ACTION_VIEW, Uri.parse(web));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
            call.resolve();
        } catch (Exception e) { call.reject("no maps"); }
    }

    /** حفظ مظهر الويدجت (تدرّج + زخرفة) وإعادة رسم كل الويدجت فوراً */
    @PluginMethod
    public void setWidgetStyle(PluginCall call) {
        Context c = getContext();
        AlarmScheduler.prefs(c).edit().putString("wstyle", call.getData().toString()).remove("arc_mode").commit();
        WidgetHub.renderAllOnly(c);
        RafiqWidgets.updateAll(c);
        call.resolve();
    }

    /** تصميم بطاقة الأذان والإقامة (النمط والألوان المحسوبة والخيارات) — تقرؤه AdhanActivity */
    @PluginMethod
    public void setAdhanCard(PluginCall call) {
        JSONObject cfg = call.getObject("cfg");
        AlarmScheduler.prefs(getContext()).edit().putString("acard", cfg == null ? "{}" : cfg.toString()).commit();
        call.resolve();
    }

    /** صورة خاصة لخلفية صلاة معيّنة (JPEG بترميز base64)؛ القيمة الفارغة تحذف الصورة */
    @PluginMethod
    public void setCardImage(PluginCall call) {
        String k = call.getString("prayer", "");
        String data = call.getString("data", "");
        JSObject r = new JSObject();
        if (!k.matches("fajr|dhuhr|asr|maghrib|isha")) { r.put("ok", false); call.resolve(r); return; }
        java.io.File f = new java.io.File(getContext().getFilesDir(), "acard_" + k + ".jpg");
        try {
            if (data == null || data.isEmpty()) { if (f.exists()) f.delete(); }
            else {
                byte[] b = android.util.Base64.decode(data, android.util.Base64.DEFAULT);
                java.io.FileOutputStream o = new java.io.FileOutputStream(f);
                o.write(b); o.close();
            }
            r.put("ok", true);
        } catch (Exception e) { r.put("ok", false); }
        call.resolve(r);
    }

    /** صورة خلفية يضيفها المستخدم لويدجت «فائدة اليوم» (JPEG base64)؛ الفارغة تحذفها */
    @PluginMethod
    public void setWidgetPhoto(PluginCall call) {
        String id = call.getString("id", "");
        String data = call.getString("data", "");
        JSObject r = new JSObject();
        if (!id.matches("[a-z0-9]{3,24}")) { r.put("ok", false); call.resolve(r); return; }
        java.io.File f = new java.io.File(getContext().getFilesDir(), "wphoto_" + id + ".jpg");
        try {
            if (data == null || data.isEmpty()) { if (f.exists()) f.delete(); }
            else { java.io.FileOutputStream o = new java.io.FileOutputStream(f); o.write(android.util.Base64.decode(data, android.util.Base64.DEFAULT)); o.close(); }
            r.put("ok", true);
        } catch (Exception e) { r.put("ok", false); }
        WidgetHub.renderAllOnly(getContext());
        call.resolve(r);
    }

    /** إضافة ويدجت إلى الشاشة الرئيسية مباشرة من داخل التطبيق (أندرويد 8 فأحدث) */
    @PluginMethod
    public void pinWidget(PluginCall call) {
        Context c = getContext();
        String kind = call.getString("kind", "full");
        JSObject r = new JSObject();
        try {
            android.appwidget.AppWidgetManager m = android.appwidget.AppWidgetManager.getInstance(c);
            int idx = -1;
            for (int i = 0; i < WidgetHub.KINDS.length; i++) if (WidgetHub.KINDS[i].equals(kind)) idx = i;
            Class<?> cls = idx >= 0 ? WidgetHub.CLS[idx] : null;
            for (int i = 0; i < TasbihRender.KINDS.length; i++) if (TasbihRender.KINDS[i].equals(kind)) cls = TasbihRender.CLS[i];
            for (int i = 0; i < RafiqWidgets.KINDS.length; i++) if (RafiqWidgets.KINDS[i].equals(kind)) cls = RafiqWidgets.CLS[i];
            if ("my".equals(kind)) cls = WMyWidget.class;
            if (cls == null || Build.VERSION.SDK_INT < 26 || !m.isRequestPinAppWidgetSupported()) { r.put("ok", false); call.resolve(r); return; }
            boolean ok = m.requestPinAppWidget(new android.content.ComponentName(c, cls), null, null);
            r.put("ok", ok);
        } catch (Exception e) { r.put("ok", false); }
        call.resolve(r);
    }

    /** إلغاء/تفعيل الكتم العام (زر الجرس في الويدجت) من داخل التطبيق */
    @PluginMethod
    public void setMuted(PluginCall call) {
        Context c = getContext();
        AlarmScheduler.prefs(c).edit().putBoolean("muted", Boolean.TRUE.equals(call.getBoolean("on", false))).commit();
        try { WidgetHub.updateAll(c); } catch (Exception ignored) {}
        call.resolve();
    }

    /* ═══ «مركز تخصيص الإشعارات» ═══ */
    @PluginMethod
    public void setNoticeStyle(PluginCall call) {
        Context c = getContext();
        try {
            JSONObject d = new JSONObject(call.getData().toString());
            JSONObject cfg = d.optJSONObject("cfg");
            AlarmScheduler.prefs(c).edit().putString("nstyle", cfg == null ? "{}" : cfg.toString()).commit();
            StatusNotice.update(c);
            AlarmScheduler.scheduleWidgetTick(c);
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    /** إشعار تجريبي حقيقي (صامت) بالنمط المختار لنوع وصلاة محددين — للتأكد من شكله في الستارة وشاشة القفل */
    @PluginMethod
    public void noticeTest(PluginCall call) {
        Context c = getContext();
        try {
            JSONObject d = new JSONObject(call.getData().toString());
            if (d.has("cfg")) AlarmScheduler.prefs(c).edit().putString("nstyle", d.optJSONObject("cfg").toString()).commit();
            JSONObject ev = d.optJSONObject("ev");
            if (ev == null) ev = new JSONObject();
            ev.put("nkind", ev.optString("kind", "adhan"));
            ev.put("test", true);
            EntryNotice.postTest(c, ev);
            JSObject r = new JSObject();
            r.put("styled", NStyle.enabled(c, ev.optString("prayer", "")));
            call.resolve(r);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    /* ═══ «استوديو الويدجيت»: مزامنة التصاميم مع ويدجت «تصميمي الخاص» ═══ */
    @PluginMethod
    public void mwSync(PluginCall call) {
        Context c = getContext();
        try {
            JSONObject d = new JSONObject(call.getData().toString());
            JSONObject ds = d.optJSONObject("designs");
            MyWidgets.save(c, ds != null ? ds : new JSONObject(), d.optString("tpl", ""));
        } catch (Exception ignored) {}
        MyWidgets.updateAll(c);
        call.resolve();
    }

    @PluginMethod
    public void mwWidgets(PluginCall call) {
        Context c = getContext();
        JSObject r = new JSObject();
        JSArray a = new JSArray();
        JSONObject all = MyWidgets.designs(c);
        for (int id : MyWidgets.ids(c)) {
            JSObject o = new JSObject();
            o.put("id", id);
            String d = MyWidgets.designOf(c, id, all);
            o.put("design", d == null ? "" : d);
            a.put(o);
        }
        r.put("list", a);
        call.resolve(r);
    }

    @PluginMethod
    public void mwAssign(PluginCall call) {
        Integer id = call.getInt("id");
        String d = call.getString("design", "");
        if (id != null && d != null && !d.isEmpty()) MyWidgets.assign(getContext(), id, d);
        call.resolve();
    }

    /** حفظ ملف مُصدَّر (PNG/SVG/JSON/ZIP) في مجلد التنزيلات — لا يحتاج أذونات إضافية */
    @PluginMethod
    public void saveFile(PluginCall call) {
        Context c = getContext();
        JSObject r = new JSObject();
        String name = call.getString("name", "albaqiyat-widget");
        String mime = call.getString("mime", "application/octet-stream");
        String data = call.getString("data", "");
        name = name.replaceAll("[\\\\/:*?\"<>|]", "_");
        try {
            byte[] b = android.util.Base64.decode(data, android.util.Base64.DEFAULT);
            if (Build.VERSION.SDK_INT >= 29) {
                android.content.ContentValues v = new android.content.ContentValues();
                v.put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(android.provider.MediaStore.MediaColumns.MIME_TYPE, mime);
                v.put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS + "/Albaqiyat");
                Uri u = c.getContentResolver().insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (u == null) throw new Exception("insert");
                try (java.io.OutputStream o = c.getContentResolver().openOutputStream(u)) { o.write(b); }
                r.put("path", "Download/Albaqiyat/" + name);
            } else {
                java.io.File dir = c.getExternalFilesDir(android.os.Environment.DIRECTORY_DOWNLOADS);
                if (dir == null) dir = c.getFilesDir();
                java.io.File f = new java.io.File(dir, name);
                try (java.io.FileOutputStream o = new java.io.FileOutputStream(f)) { o.write(b); }
                r.put("path", f.getAbsolutePath());
            }
            r.put("ok", true);
        } catch (Exception e) { r.put("ok", false); r.put("error", String.valueOf(e.getMessage())); }
        call.resolve(r);
    }

    /* ═══ «مسبحة بلمسة»: مزامنة الأذكار والقالب والإعدادات مع ويدجت الشاشة الرئيسية ═══ */
    @PluginMethod
    public void tasbihSync(PluginCall call) {
        Context c = getContext();
        android.content.SharedPreferences.Editor e = TasbihStore.p(c).edit();
        try {
            JSONObject d = new JSONObject(call.getData().toString());
            if (d.has("list")) e.putString("list", d.getJSONArray("list").toString());
            if (d.has("tpl")) e.putString("tpl", d.getJSONObject("tpl").toString());
            if (d.has("goalNotif")) e.putBoolean("goalNotif", d.optBoolean("goalNotif"));
        } catch (Exception ignored) {}
        e.commit();
        TasbihRender.renderAll(c);
        call.resolve();
    }

    @PluginMethod
    public void tasbihWidgets(PluginCall call) {
        Context c = getContext();
        JSArray a = new JSArray();
        for (int id : TasbihRender.allIds(c)) {
            try {
                String k = TasbihRender.kindOf(c, id);
                JSONObject o = TasbihStore.ensure(c, id, k);
                a.put(new JSONObject().put("id", id).put("kind", k).put("cfg", o));
            } catch (Exception ignored) {}
        }
        JSObject r = new JSObject();
        r.put("list", a);
        call.resolve(r);
    }

    @PluginMethod
    public void tasbihSetWidget(PluginCall call) {
        Context c = getContext();
        int id = call.getInt("id", -1);
        try {
            JSONObject cur = TasbihStore.ensure(c, id, TasbihRender.kindOf(c, id));
            JSONObject n = new JSONObject(call.getData().getJSONObject("cfg").toString());
            n.remove("counts"); n.remove("rounds");
            if ("tbm".equals(TasbihRender.kindOf(c, id))) n.remove("kind");
            TasbihStore.merge(cur, n);
            if (call.getBoolean("resetCount", false)) { cur.put("counts", new JSONObject()); cur.put("done", false); cur.put("stopped", false); cur.put("msg", ""); }
            TasbihStore.save(c, id, cur);
            TasbihRender.render(c, android.appwidget.AppWidgetManager.getInstance(c), id, TasbihRender.kindOf(c, id));
        } catch (Exception ignored) {}
        call.resolve();
    }

    @PluginMethod
    public void tasbihStats(PluginCall call) {
        try { call.resolve(new JSObject(TasbihStore.stats(getContext()).toString())); } catch (Exception e) { call.resolve(new JSObject()); }
    }

    @PluginMethod
    public void tasbihResetStats(PluginCall call) { TasbihStore.resetStats(getContext()); TasbihRender.renderAll(getContext()); call.resolve(); }

    @PluginMethod
    public void tasbihReminders(PluginCall call) {
        Context c = getContext();
        TasbihStore.p(c).edit().putString("rem", call.getData().toString()).commit();
        TasbihStore.scheduleReminders(c);
        call.resolve();
    }

    /** مسار مطلوب من ويدجت (مثلاً فتح إعدادات المسبحة عند لمس اسم الذكر) */
    @PluginMethod
    public void takeRoute(PluginCall call) {
        android.content.SharedPreferences p = getContext().getSharedPreferences("app_meta", Context.MODE_PRIVATE);
        JSObject r = new JSObject();
        r.put("route", p.getString("route", ""));
        p.edit().remove("route").commit();
        call.resolve(r);
    }

    /* ═══ الساعة الذكية ═══ */
    @PluginMethod
    public void setWatch(PluginCall call) {
        AlarmScheduler.prefs(getContext()).edit().putBoolean("watch", call.getBoolean("on", false)).commit();
        call.resolve();
    }

    @PluginMethod
    public void watchTest(PluginCall call) {
        JSObject r = new JSObject();
        r.put("ok", WatchNotice.post(getContext(), 4802, "⌚ اختبار الساعة — الباقيات الصالحات", "إذا ظهر هذا على ساعتك فالتنبيهات تصل إليها ✓"));
        call.resolve(r);
    }

    /* ═══ الرفيق اليومي للعبادات ═══ */
    @PluginMethod
    public void rfSchedule(PluginCall call) {
        try {
            JSONObject d = new JSONObject(call.getData().toString());
            JSONArray ev = d.optJSONArray("events");
            JSONObject done = d.optJSONObject("done");
            RafiqEngine.setPlan(getContext(), ev == null ? new JSONArray() : ev, done == null ? new JSONObject() : done, d.optInt("snoozeMin", 15), d.optBoolean("on", true),
                d.optJSONObject("snap"), d.optBoolean("hideLock", false));
            call.resolve(new JSObject(RafiqEngine.status(getContext()).toString()));
        } catch (Exception e) { call.reject("rfSchedule"); }
    }

    /** ويدجت «مهمة مختارة»: قائمة النسخ، وتعيين مهمة لنسخة أو للقالب */
    @PluginMethod
    public void rfWidgets(PluginCall call) {
        Context c = getContext();
        JSArray a = new JSArray();
        android.appwidget.AppWidgetManager m = android.appwidget.AppWidgetManager.getInstance(c);
        for (int i = 0; i < RafiqWidgets.CLS.length; i++) {
            try { for (int id : m.getAppWidgetIds(new android.content.ComponentName(c, RafiqWidgets.CLS[i]))) a.put(new JSONObject().put("id", id).put("kind", RafiqWidgets.KINDS[i]).put("pick", RafiqEngine.p(c).getString("pick_" + id, ""))); } catch (Exception ignored) {}
        }
        JSObject r = new JSObject();
        r.put("list", a);
        r.put("pickTpl", RafiqEngine.p(c).getString("pickTpl", ""));
        call.resolve(r);
    }

    @PluginMethod
    public void rfSetPick(PluginCall call) {
        Context c = getContext();
        int id = call.getInt("id", -1);
        String t = call.getString("task", "");
        if (id < 0) RafiqEngine.p(c).edit().putString("pickTpl", t).commit();
        else { RafiqEngine.p(c).edit().putString("pick_" + id, t).commit(); RafiqWidgets.render(c, android.appwidget.AppWidgetManager.getInstance(c), id, "rpick"); }
        call.resolve();
    }

    @PluginMethod
    public void rfPull(PluginCall call) {
        JSObject r = new JSObject();
        try { r.put("acts", new JSArray(RafiqEngine.pull(getContext()).toString())); } catch (Exception e) { r.put("acts", new JSArray()); }
        call.resolve(r);
    }

    @PluginMethod
    public void rfStatus(PluginCall call) {
        try { call.resolve(new JSObject(RafiqEngine.status(getContext()).toString())); } catch (Exception e) { call.resolve(new JSObject()); }
    }

    @PluginMethod
    public void rfTest(PluginCall call) {
        JSObject r = new JSObject();
        r.put("ok", RafiqEngine.test(getContext()));
        call.resolve(r);
    }

    @PluginMethod
    public void compassStop(PluginCall call) { qPaused = null; stopCompass(); call.resolve(); }

    /* عند ظهور نافذة إذن الموقع أو الخروج من التطبيق يتوقف المستشعر (توفير البطارية)،
       ثم يعود تلقائياً عند الرجوع — سابقاً كان يبقى متوقفاً فتتجمّد بوصلة القبلة */
    private android.hardware.SensorEventListener qPaused = null;

    @Override
    protected void handleOnPause() {
        qPaused = qsl;
        stopCompass();
        super.handleOnPause();
    }

    @Override
    protected void handleOnResume() {
        super.handleOnResume();
        if (qPaused != null && qsm != null) {
            try {
                android.hardware.Sensor rv = qsm.getDefaultSensor(android.hardware.Sensor.TYPE_ROTATION_VECTOR);
                if (rv != null) {
                    qsl = qPaused;
                    qsm.registerListener(qsl, rv, android.hardware.SensorManager.SENSOR_DELAY_GAME);
                    android.hardware.Sensor mg = qsm.getDefaultSensor(android.hardware.Sensor.TYPE_MAGNETIC_FIELD);
                    if (mg != null) qsm.registerListener(qsl, mg, android.hardware.SensorManager.SENSOR_DELAY_UI);
                }
            } catch (Exception ignored) {}
        }
        qPaused = null;
    }

    /** المصحف بملء الشاشة: إخفاء شريط الحالة وشريط التنقل (يظهران مؤقتاً بالسحب من الحافة) */
    @PluginMethod
    public void setImmersive(PluginCall call) {
        final boolean on = Boolean.TRUE.equals(call.getBoolean("on", false));
        final android.app.Activity a = getActivity();
        if (a == null) { call.resolve(); return; }
        a.runOnUiThread(() -> {
            try {
                android.view.Window w = a.getWindow();
                if (Build.VERSION.SDK_INT >= 30) {
                    android.view.WindowInsetsController ic = w.getInsetsController();
                    if (ic != null) {
                        if (on) {
                            ic.hide(android.view.WindowInsets.Type.statusBars() | android.view.WindowInsets.Type.navigationBars());
                            ic.setSystemBarsBehavior(android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                        } else ic.show(android.view.WindowInsets.Type.statusBars() | android.view.WindowInsets.Type.navigationBars());
                    }
                } else {
                    android.view.View d = w.getDecorView();
                    d.setSystemUiVisibility(on ? (android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | android.view.View.SYSTEM_UI_FLAG_FULLSCREEN
                            | android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE) : android.view.View.SYSTEM_UI_FLAG_VISIBLE);
                }
            } catch (Exception ignored) {}
            call.resolve();
        });
    }
    static final int TEST_ID = 999990;

    /** تجربة حقيقية: منبّه فعلي بعد عدة دقائق بنفس طريقة الأذان (لاختبار وضع الطيران والشاشة مقفلة) */
    @PluginMethod
    public void testLater(PluginCall call) {
        Context c = getContext();
        try {
            JSONObject ev = new JSONObject(call.getData().toString());
            long at = System.currentTimeMillis() + call.getInt("minutes", 2) * 60000L;
            ev.put("id", TEST_ID);
            ev.put("at", at);
            if (!ev.has("kind")) ev.put("kind", "adhan");
            AlarmScheduler.prefs(c).edit().putString("test_ev", ev.toString()).commit();
            // السماح بتكرار التجربة
            JSONArray f = new JSONArray(AlarmScheduler.prefs(c).getString("fired", "[]"));
            JSONArray out = new JSONArray();
            for (int i = 0; i < f.length(); i++) if (f.optInt(i) != TEST_ID) out.put(f.optInt(i));
            AlarmScheduler.prefs(c).edit().putString("fired", out.toString()).commit();
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            boolean exact = AlarmScheduler.canExact(c);
            String m = AlarmScheduler.setEventAlarm(c, am, at, AlarmScheduler.pi(c, TEST_ID), exact);
            try { AlarmScheduler.setAlarm(am, at, AlarmScheduler.piBackup(c, TEST_ID), exact); } catch (Exception ignored) {}
            JSObject r = new JSObject();
            r.put("at", at);
            r.put("method", m);
            call.resolve(r);
        } catch (Exception ex) {
            call.reject(String.valueOf(ex.getMessage()));
        }
    }

    @PluginMethod
    public void schedule(PluginCall call) {
        Context c = getContext();
        JSArray ev = call.getArray("events");
        JSObject w = call.getObject("widget");
        android.content.SharedPreferences.Editor e = AlarmScheduler.prefs(c).edit();
        e.putString("events", ev != null ? ev.toString() : "[]");
        if (w != null) e.putString("widget", w.toString());
        e.commit();
        int n = AlarmScheduler.scheduleAll(c);
        WidgetHub.updateAll(c);
        JSObject r = new JSObject();
        r.put("count", n);
        r.put("exact", AlarmScheduler.canExact(c));
        call.resolve(r);
    }

    @PluginMethod
    public void status(PluginCall call) {
        Context c = getContext();
        JSObject r = new JSObject();
        r.put("exact", AlarmScheduler.canExact(c));
        boolean fs = true;
        if (Build.VERSION.SDK_INT >= 34) {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            fs = nm != null && nm.canUseFullScreenIntent();
        }
        r.put("fullScreen", fs);
        r.put("overlay", Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(c));
        boolean bat = true;
        if (Build.VERSION.SDK_INT >= 23) {
            PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
            bat = pm != null && pm.isIgnoringBatteryOptimizations(c.getPackageName());
        }
        r.put("battery", bat);
        r.put("playing", AdhanService.isPlaying());
        r.put("muted", AlarmScheduler.prefs(c).getBoolean("muted", false));
        r.put("method", AlarmScheduler.prefs(c).getString("method", ""));
        r.put("brand", Build.MANUFACTURER == null ? "" : Build.MANUFACTURER.toLowerCase());
        r.put("statusService", StatusService.running);
        r.put("log", AlarmScheduler.prefs(c).getString("log", "[]"));
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am != null && Build.VERSION.SDK_INT >= 21) {
            AlarmManager.AlarmClockInfo ni = am.getNextAlarmClock();
            r.put("nextClock", ni != null ? ni.getTriggerTime() : 0);
        }
        call.resolve(r);
    }

    @PluginMethod
    public void openSettings(PluginCall call) {
        Context c = getContext();
        String which = call.getString("which", "");
        Uri pkg = Uri.parse("package:" + c.getPackageName());
        Intent i = null;
        if ("exact".equals(which) && Build.VERSION.SDK_INT >= 31) i = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, pkg);
        else if ("fullscreen".equals(which) && Build.VERSION.SDK_INT >= 34) i = new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, pkg);
        else if ("overlay".equals(which) && Build.VERSION.SDK_INT >= 23) i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkg);
        else if ("battery".equals(which) && Build.VERSION.SDK_INT >= 23) i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkg);
        if ("autostart".equals(which)) {
            // إدارة تشغيل التطبيقات في هونر/هواوي وغيرها (لا يوجد إعداد موحّد في أندرويد)
            String[][] comps = {
                {"com.hihonor.systemmanager", "com.hihonor.systemmanager.startupmgr.ui.StartupNormalAppListActivity"},
                {"com.hihonor.systemmanager", "com.hihonor.systemmanager.optimize.process.ProtectActivity"},
                {"com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"},
                {"com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity"},
                {"com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"},
                {"com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"},
                {"com.oplus.battery", "com.oplus.powermanager.fuelgaue.PowerUsageModelActivity"},
                {"com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"},
                {"com.samsung.android.lool", "com.samsung.android.sm.battery.ui.BatteryActivity"}
            };
            for (String[] cp : comps) {
                Intent t = new Intent();
                t.setComponent(new android.content.ComponentName(cp[0], cp[1]));
                t.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                try { c.startActivity(t); call.resolve(); return; } catch (Exception ignored) {}
            }
        }
        if (i == null) i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            c.startActivity(i);
        } catch (Exception ex) {
            try {
                Intent d = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg);
                d.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                c.startActivity(d);
            } catch (Exception ignored) {}
        }
        call.resolve();
    }

    @PluginMethod
    public void stop(PluginCall call) {
        try {
            Intent s = new Intent(getContext(), AdhanService.class);
            s.setAction("STOP");
            getContext().startService(s);
        } catch (Exception ignored) {}
        call.resolve();
    }

    /** تجربة شاشة الأذان بعد ثوانٍ (لاختبار الصوت والشاشة) */
    @PluginMethod
    public void test(PluginCall call) {
        Context c = getContext();
        try {
            JSONObject ev = new JSONObject();
            long at = System.currentTimeMillis() + call.getInt("delay", 5) * 1000L;
            ev.put("id", 999999);
            ev.put("at", at);
            ev.put("kind", call.getString("kind", "adhan"));
            ev.put("prayer", call.getString("prayer", "fajr"));
            ev.put("name", call.getString("name", "الفجر"));
            ev.put("title", call.getString("title", "تجربة شاشة الأذان"));
            ev.put("body", call.getString("body", ""));
            ev.put("sound", call.getString("sound", "adhan_m1"));
            ev.put("time", call.getString("time", ""));
            ev.put("city", call.getString("city", ""));
            ev.put("who", call.getString("who", ""));
            ev.put("fadl", call.getString("fadl", ""));
            ev.put("iq", call.getDouble("iq", 0.0).longValue());
            ev.put("iqs", call.getString("iqs", ""));
            ev.put("fsrc", call.getString("fsrc", ""));
            ev.put("voice", call.getString("voice", "اقتربت الصلاة، الرجاء الاستعداد"));
            ev.put("adhanAt", call.getDouble("adhanAt", 0.0).longValue());
            ev.put("adhanS", call.getString("adhanS", ""));
            ev.put("hj", call.getString("hj", ""));
            ev.put("gr", call.getString("gr", ""));
            if ("adhan".equals(ev.optString("kind"))) IqamaNotice.post(c, ev);
            if ("pre".equals(ev.optString("kind"))) IqamaNotice.postPre(c, ev);
            Intent s = new Intent(c, AdhanService.class);
            s.putExtra("ev", ev.toString());
            // تشغيل فوري ما دام التطبيق مفتوحاً
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(s);
            else c.startService(s);
        } catch (Exception ex) {
            call.reject(ex.getMessage());
            return;
        }
        call.resolve();
    }
}
