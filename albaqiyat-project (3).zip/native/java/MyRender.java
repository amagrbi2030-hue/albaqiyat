package com.albaqiyat.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.Build;
import android.util.Base64;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * محرّك رسم «تصميمي الخاص» على أندرويد — نسخة مطابقة لمحرك المعاينة في التطبيق (mwRender):
 * نفس الإحداثيات النسبية (٪ من العرض/الارتفاع) ونفس أحجام الخطوط (٪ من الارتفاع) ونفس ترتيب الطبقات.
 * البيانات الحية (الوقت، المواقيت، التاريخ الهجري، الطقس، تقدّم الرفيق) تُقرأ من بيانات الويدجت المحفوظة.
 */
final class MyRender {
    private MyRender() {}

    // ── البيانات الحية ──
    static final class Data {
        Calendar now; boolean loc; String weekday = "", hd = "", hm = "", hy = "", gd = "", gm = "", gy = "", city = "";
        List<String[]> prayers = new ArrayList<>(); // {k, name, at, on(1/0), sun(1/0)}
        String nextN = null; long nextT = 0, nextIq = 0, sunrise = 0, third = 0;
        Integer toRam = null; String temp = "", wdesc = ""; float rf = 0;
    }

    static Data data(Context c, JSONObject sp) {
        Data D = new Data();
        D.now = Calendar.getInstance();
        long now = D.now.getTimeInMillis();
        JSONObject w;
        try { w = new JSONObject(AlarmScheduler.prefs(c).getString("widget", "{}")); } catch (Exception e) { w = new JSONObject(); }
        D.city = w.optString("city", "");
        JSONArray days = w.optJSONArray("days");
        Calendar t0 = Calendar.getInstance(); t0.set(Calendar.HOUR_OF_DAY, 0); t0.set(Calendar.MINUTE, 0); t0.set(Calendar.SECOND, 0); t0.set(Calendar.MILLISECOND, 0);
        long d0 = t0.getTimeInMillis(), d1 = d0 + 86400000L;
        int ti = -1;
        if (days != null) for (int i = 0; i < days.length(); i++) {
            JSONObject dd = days.optJSONObject(i); JSONArray it = dd == null ? null : dd.optJSONArray("items");
            long fa = 0; if (it != null) for (int j = 0; j < it.length(); j++) { JSONObject o = it.optJSONObject(j); if (o != null && "fajr".equals(o.optString("k"))) fa = o.optLong("at"); }
            if (fa >= d0 && fa < d1) { ti = i; break; }
        }
        // الصلاة القادمة (عبر الأيام)
        String nk = null;
        if (days != null) outer:
        for (int i = Math.max(0, ti); i < days.length(); i++) {
            JSONObject dd = days.optJSONObject(i); JSONArray it = dd == null ? null : dd.optJSONArray("items");
            if (it == null) continue;
            for (int j = 0; j < it.length(); j++) {
                JSONObject o = it.optJSONObject(j);
                if (o == null || "sunrise".equals(o.optString("k"))) continue;
                long at = o.optLong("at", 0);
                if (at > now) { nk = o.optString("k"); D.nextN = o.optString("name"); D.nextT = at; D.nextIq = o.optLong("iq", 0); break outer; }
            }
        }
        if (ti >= 0) {
            D.loc = true;
            JSONObject dd = days.optJSONObject(ti);
            D.weekday = dd.optString("wd"); D.hd = dd.optString("hjd"); D.hm = dd.optString("hjm"); D.hy = dd.optString("hjy").replaceAll("\\D", "");
            D.gd = dd.optString("grd"); D.gm = dd.optString("grm"); D.gy = dd.optString("gry").replaceAll("\\D", "");
            JSONArray it = dd.optJSONArray("items");
            long mag = 0;
            for (int j = 0; it != null && j < it.length(); j++) {
                JSONObject o = it.optJSONObject(j); if (o == null) continue;
                String k = o.optString("k");
                D.prayers.add(new String[]{k, o.optString("name"), String.valueOf(o.optLong("at")), k.equals(nk) ? "1" : "0", "sunrise".equals(k) ? "1" : "0"});
                if ("sunrise".equals(k)) D.sunrise = o.optLong("at");
                if ("maghrib".equals(k)) mag = o.optLong("at");
            }
            JSONObject nd = ti + 1 < days.length() ? days.optJSONObject(ti + 1) : null;
            JSONArray nit = nd == null ? null : nd.optJSONArray("items");
            long fj = 0; for (int j = 0; nit != null && j < nit.length(); j++) { JSONObject o = nit.optJSONObject(j); if (o != null && "fajr".equals(o.optString("k"))) fj = o.optLong("at"); }
            if (mag > 0 && fj > mag) D.third = mag + (fj - mag) * 2 / 3;
        } else {
            D.loc = false;
            java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("EEEE", new java.util.Locale("ar"));
            D.weekday = f.format(D.now.getTime());
            D.gd = String.valueOf(D.now.get(Calendar.DAY_OF_MONTH));
            D.gm = new java.text.SimpleDateFormat("MMMM", new java.util.Locale("ar")).format(D.now.getTime());
            D.gy = String.valueOf(D.now.get(Calendar.YEAR));
        }
        // رمضان: محسوب في التطبيق ليوم المزامنة، ويُطرح منه عدد الأيام المنقضية
        if (sp != null && sp.has("toRam") && !sp.isNull("toRam")) {
            try {
                int v = sp.optInt("toRam");
                java.text.SimpleDateFormat iso = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US);
                long base = iso.parse(sp.optString("toRamDay")).getTime();
                int el = (int) Math.round((d0 - base) / 86400000.0);
                if (v - el >= 0) D.toRam = v - el;
            } catch (Exception ignored) {}
        }
        try {
            JSONObject x = new JSONObject(AlarmScheduler.prefs(c).getString("wx", "{}"));
            if (x.has("t")) { D.temp = Math.round(x.optDouble("t")) + "°"; D.wdesc = WeatherFetcher.desc(x.optInt("code", 1)); }
        } catch (Exception ignored) {}
        try {
            List<RafiqWidgets.Occ> L = RafiqWidgets.day(c, RafiqWidgets.today());
            if (L != null) { int tot = 0, dn = 0; for (RafiqWidgets.Occ o : L) if (RafiqWidgets.isDue(o, now)) { tot++; if (o.done) dn++; } D.rf = tot > 0 ? (float) dn / tot : 0; }
        } catch (Throwable ignored) {}
        return D;
    }

    // ── أدوات ──
    static int col(String s, int def) {
        if (s == null) return def;
        s = s.trim();
        if (s.isEmpty() || "transparent".equals(s)) return 0;
        try {
            if (s.startsWith("#")) {
                String h = s.substring(1);
                if (h.length() == 3) h = "" + h.charAt(0) + h.charAt(0) + h.charAt(1) + h.charAt(1) + h.charAt(2) + h.charAt(2);
                if (h.length() == 6) return 0xFF000000 | Integer.parseInt(h, 16);
                if (h.length() == 8) { int rgb = Integer.parseInt(h.substring(0, 6), 16), a = Integer.parseInt(h.substring(6), 16); return (a << 24) | rgb; }
            }
            return Color.parseColor(s);
        } catch (Exception e) { return def; }
    }

    static int alphaMul(int c, float a) { return (Math.round(Color.alpha(c) * Math.max(0, Math.min(1, a))) << 24) | (c & 0xFFFFFF); }

    static String dig(String s, JSONObject sp) {
        if (!"ar".equals(sp.optString("digits", "ar"))) return s;
        StringBuilder b = new StringBuilder();
        for (char ch : s.toCharArray()) b.append(ch >= '0' && ch <= '9' ? (char) ('٠' + (ch - '0')) : ch);
        return b.toString();
    }

    static String hm(long t, JSONObject sp, boolean ap) {
        if (t <= 0) return "—";
        Calendar k = Calendar.getInstance(); k.setTimeInMillis(t);
        int h = k.get(Calendar.HOUR_OF_DAY), m = k.get(Calendar.MINUTE);
        String s = dig((h % 12 == 0 ? 12 : h % 12) + ":" + (m < 10 ? "0" : "") + m, sp);
        return ap ? s + (h < 12 ? " ص" : " م") : s;
    }

    static String tok(String t, Data D, JSONObject sp) {
        if (t == null || t.indexOf('{') < 0) return t == null ? "" : t;
        long now = D.now.getTimeInMillis();
        int cd = D.nextT > 0 ? (int) Math.max(0, Math.round((D.nextT - now) / 60000.0)) : 0;
        StringBuilder out = new StringBuilder();
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("\\{(\\w+)\\}").matcher(t);
        int last = 0;
        while (m.find()) {
            out.append(t, last, m.start());
            String k = m.group(1), v;
            switch (k) {
                case "weekday": v = D.weekday; break;
                case "hijri": v = D.hd.isEmpty() ? "" : dig(D.hd, sp) + " " + D.hm + " " + dig(D.hy, sp); break;
                case "hijri_d": v = dig(D.hd, sp); break;
                case "hijri_m": v = D.hm; break;
                case "hijri_y": v = dig(D.hy, sp); break;
                case "greg": v = D.gd.isEmpty() ? "" : dig(D.gd, sp) + " " + D.gm + " " + dig(D.gy, sp); break;
                case "greg_d": v = dig(D.gd, sp); break;
                case "greg_m": v = D.gm; break;
                case "greg_y": v = dig(D.gy, sp); break;
                case "time": v = hm(now, sp, false); break;
                case "next": v = D.nextN != null ? D.nextN : "—"; break;
                case "next_time": v = D.nextT > 0 ? hm(D.nextT, sp, true) : "—"; break;
                case "iqama": v = D.nextIq > 0 ? hm(D.nextIq, sp, true) : "—"; break;
                case "countdown": v = D.nextT > 0 ? dig((cd / 60) + ":" + (cd % 60 < 10 ? "0" : "") + (cd % 60), sp) : "—"; break;
                case "city": v = D.city.isEmpty() ? "—" : D.city; break;
                case "sunrise": v = D.sunrise > 0 ? hm(D.sunrise, sp, true) : "—"; break;
                case "lastthird": v = D.third > 0 ? hm(D.third, sp, true) : "—"; break;
                case "to_ramadan": v = D.toRam == null ? "—" : dig(String.valueOf(D.toRam), sp); break;
                case "temp": v = D.temp.isEmpty() ? "—" : dig(D.temp, sp); break;
                case "wdesc": v = D.wdesc.isEmpty() ? "—" : D.wdesc; break;
                default: v = m.group(0);
            }
            out.append(v);
            last = m.end();
        }
        out.append(t.substring(last));
        return out.toString();
    }

    static boolean dynamic(JSONObject sp) {
        JSONArray els = sp.optJSONArray("els");
        for (int i = 0; els != null && i < els.length(); i++) {
            JSONObject e = els.optJSONObject(i); if (e == null || e.optBoolean("hid")) continue;
            String t = e.optString("t");
            if ("clock".equals(t)) return true;
            if ("nextp".equals(t) && e.optBoolean("showCd")) return true;
            if ("text".equals(t) && (e.optString("text").contains("{time}") || e.optString("text").contains("{countdown}"))) return true;
        }
        return false;
    }

    // ── الخطوط ──
    static Typeface tfT, tfA, tfP;
    static Typeface face(Context c, String font) {
        try {
            if (tfT == null && Build.VERSION.SDK_INT >= 26) {
                tfT = c.getResources().getFont(c.getResources().getIdentifier("tajawal_bold", "font", c.getPackageName()));
                tfA = c.getResources().getFont(c.getResources().getIdentifier("amiri_bold", "font", c.getPackageName()));
                tfP = c.getResources().getFont(c.getResources().getIdentifier("plex_bold", "font", c.getPackageName()));
            }
        } catch (Throwable ignored) {}
        Typeface f;
        if ("amiri".equals(font) || "quran".equals(font)) f = tfA;
        else if ("plex".equals(font)) f = tfP;
        else if ("sys".equals(font)) f = Typeface.DEFAULT_BOLD;
        else f = tfT;
        return f != null ? f : Typeface.DEFAULT_BOLD;
    }

    static Paint tp(Context c, float fs, String fw, String font) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
        p.setTypeface(face(c, font));
        p.setTextSize(Math.max(4, fs));
        int w = 700; try { w = Integer.parseInt(fw); } catch (Exception ignored) {}
        p.setFakeBoldText(w >= 800);
        return p;
    }

    static List<String> wrap(Paint p, String txt, float maxW) {
        List<String> L = new ArrayList<>();
        String cur = "";
        for (String w : txt.split("\\s+")) {
            if (w.isEmpty()) continue;
            String t = cur.isEmpty() ? w : cur + " " + w;
            if (p.measureText(t) > maxW && !cur.isEmpty()) { L.add(cur); cur = w; } else cur = t;
        }
        if (!cur.isEmpty()) L.add(cur);
        return L;
    }

    /** كتلة نص بالتصغير التلقائي والالتفاف — مطابقة لـ mwTextBlock */
    static void textBlock(Context c, Canvas cv, String txt, float X, float Y, float W, float H, float fs, String fw, String font, String al, int color, float lh, float ls, boolean sh, float alpha) {
        if (txt == null || txt.isEmpty() || W <= 0 || H <= 0) return;
        float s = fs; Paint p = null; List<String> lines = null;
        for (int k = 0; k < 30; k++) {
            p = tp(c, s, fw, font);
            if (ls != 0 && Build.VERSION.SDK_INT >= 21) p.setLetterSpacing(ls / Math.max(1, s));
            lines = wrap(p, txt, W);
            boolean fit = lines.size() * s * lh <= H + 1;
            if (fit) for (String l : lines) if (p.measureText(l) > W + 1) { fit = false; break; }
            if (fit || s < 5) break;
            s *= .92f;
        }
        p.setColor(alphaMul(color, alpha));
        if (sh) p.setShadowLayer(s * .25f, 0, s * .06f, alphaMul(0x8C000000, alpha));
        float x;
        if ("right".equals(al)) { p.setTextAlign(Paint.Align.RIGHT); x = X + W; }
        else if ("left".equals(al)) { p.setTextAlign(Paint.Align.LEFT); x = X; }
        else { p.setTextAlign(Paint.Align.CENTER); x = X + W / 2; }
        float th = lines.size() * s * lh, y = Y + (H - th) / 2 + s * lh / 2;
        Paint.FontMetrics fm = p.getFontMetrics();
        float off = -(fm.ascent + fm.descent) / 2;
        for (String l : lines) { cv.drawText(l, x, y + off, p); y += s * lh; }
    }

    static Path rr(float x, float y, float w, float h, float r) {
        r = Math.max(0, Math.min(r, Math.min(w / 2, h / 2)));
        Path p = new Path();
        p.addRoundRect(new RectF(x, y, x + w, y + h), r, r, Path.Direction.CW);
        return p;
    }

    static Bitmap img(Context c, String src, float W, float H) {
        if (src == null || src.isEmpty()) return null;
        try {
            if (src.startsWith("ph_")) {
                int rid = c.getResources().getIdentifier("photo_" + src.substring(3), "drawable", c.getPackageName());
                if (rid == 0) return null;
                BitmapFactory.Options o = new BitmapFactory.Options(); o.inJustDecodeBounds = true;
                BitmapFactory.decodeResource(c.getResources(), rid, o);
                int ss = 1; while (o.outWidth / (ss * 2) >= W && o.outHeight / (ss * 2) >= H) ss *= 2;
                BitmapFactory.Options o2 = new BitmapFactory.Options(); o2.inSampleSize = ss;
                return BitmapFactory.decodeResource(c.getResources(), rid, o2);
            }
            if (src.startsWith("data:image/")) {
                byte[] b = Base64.decode(src.substring(src.indexOf(',') + 1), Base64.DEFAULT);
                return BitmapFactory.decodeByteArray(b, 0, b.length);
            }
        } catch (Throwable ignored) {}
        return null;
    }

    static void cover(Canvas cv, Bitmap im, float X, float Y, float W, float H, float alpha) {
        float sc = Math.max(W / im.getWidth(), H / im.getHeight()), dw = im.getWidth() * sc, dh = im.getHeight() * sc;
        Paint bp = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG); bp.setAlpha(Math.round(255 * alpha));
        cv.drawBitmap(im, null, new RectF(X + (W - dw) / 2, Y + (H - dh) / 2, X + (W + dw) / 2, Y + (H + dh) / 2), bp);
    }

    static double ar(JSONObject sp) {
        double a = sp.optDouble("ar", 0);
        if (a > 0) return a;
        switch (sp.optString("size", "m")) { case "s": return 1; case "l": return 1.05; case "w": return 4.2; case "t": return .52; default: return 2.1; }
    }

    /** رسم التصميم كاملاً في صورة بعرض W */
    static Bitmap render(Context c, JSONObject sp, int W) {
        double a = ar(sp);
        int H = Math.max(8, (int) Math.round(W / a));
        Bitmap bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bmp);
        Data D = data(c, sp);
        float kk = W / 300f, r = (float) (sp.optDouble("r", 20) / 100 * Math.min(W, H) * .55);
        JSONObject b = sp.optJSONObject("bg"); if (b == null) b = new JSONObject();
        String bt = b.optString("type", "gradient");
        Path clip = rr(0, 0, W, H, r);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        if (!"transparent".equals(bt)) {
            float shv = (float) sp.optDouble("sh", 0);
            if ("solid".equals(bt) || "image".equals(bt)) p.setColor(col(b.optString("c1"), 0xFF0F5132));
            else {
                double an = Math.toRadians(b.optDouble("ang", 180)); float cx = W / 2f, cy = H / 2f, L = (float) (Math.abs(W * Math.sin(an)) + Math.abs(H * Math.cos(an)));
                p.setShader(new LinearGradient(cx - (float) Math.sin(an) * L / 2, cy + (float) Math.cos(an) * L / 2, cx + (float) Math.sin(an) * L / 2, cy - (float) Math.cos(an) * L / 2,
                        col(b.optString("c1"), 0xFF0F5132), col(b.optString("c2"), 0xFF0B3A27), Shader.TileMode.CLAMP));
            }
            p.setAlpha(Math.round(255 * (float) b.optDouble("op", 1) * (p.getShader() == null ? Color.alpha(p.getColor()) / 255f : 1)));
            if (shv > 0) p.setShadowLayer(shv * kk, 0, shv * kk / 3, 0x59000000);
            cv.drawPath(clip, p);
            p.clearShadowLayer(); p.setShader(null);
        }
        cv.save();
        cv.clipPath(clip);
        if ("image".equals(bt)) {
            Bitmap im = img(c, b.optString("img"), W, H);
            if (im != null) { cover(cv, im, 0, 0, W, H, 1); im.recycle(); }
            int dim = b.optInt("dim", 0);
            if (dim > 0) cv.drawColor(Math.round(dim / 100f * 255) << 24);
        }
        int glow = sp.optInt("glow", 0);
        if (glow > 0) {
            int gc = col(sp.optString("gc"), 0xFFD8B45A) & 0xFFFFFF;
            Paint g = new Paint(Paint.ANTI_ALIAS_FLAG);
            g.setShader(new RadialGradient(W * .85f, 0, Math.max(W, H) * .8f, new int[]{(Math.min(255, Math.round(glow * 1.6f)) << 24) | gc, gc}, null, Shader.TileMode.CLAMP));
            cv.drawRect(0, 0, W, H, g);
        }
        pattern(cv, W, H, sp);
        JSONArray els = sp.optJSONArray("els");
        List<JSONObject> L = new ArrayList<>();
        for (int i = 0; els != null && i < els.length(); i++) { JSONObject e = els.optJSONObject(i); if (e != null) L.add(e); }
        java.util.Collections.sort(L, (x, y) -> Integer.compare(x.optInt("z"), y.optInt("z")));
        for (JSONObject e : L) try { el(c, cv, e, W, H, D, sp); } catch (Throwable ignored) {}
        cv.restore();
        float bw = (float) sp.optDouble("bw", 0) * kk;
        if (bw > 0) {
            Paint s = new Paint(Paint.ANTI_ALIAS_FLAG); s.setStyle(Paint.Style.STROKE); s.setStrokeWidth(bw); s.setColor(col(sp.optString("bc"), 0xFFD8B45A));
            cv.drawPath(rr(bw / 2, bw / 2, W - bw, H - bw, Math.max(0, r - bw / 2)), s);
        }
        return bmp;
    }

    static void pattern(Canvas cv, int W, int H, JSONObject sp) {
        String pat = sp.optString("pat", "none");
        if ("none".equals(pat)) return;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        int pc = col(sp.optString("pc"), 0xFFD8B45A);
        p.setColor(alphaMul(pc, (float) sp.optDouble("pop", .15)));
        p.setStrokeWidth(Math.max(.6f, H / 220f));
        float st = Math.max(22, H / 4.2f);
        for (float y = -st; y < H + st; y += st) for (float x = -st; x < W + st; x += st) {
            if ("star".equals(pat)) {
                Path q = new Path();
                for (int i = 0; i < 16; i++) { double a = Math.PI * i / 8 - Math.PI / 2; float rr = i % 2 == 1 ? st * .2f : st * .42f; float px = x + (float) Math.cos(a) * rr, py = y + (float) Math.sin(a) * rr; if (i == 0) q.moveTo(px, py); else q.lineTo(px, py); }
                q.close(); p.setStyle(Paint.Style.STROKE); cv.drawPath(q, p);
            } else if ("lattice".equals(pat)) {
                p.setStyle(Paint.Style.STROKE); cv.drawLine(x, y, x + st, y + st, p); cv.drawLine(x + st, y, x, y + st, p);
            } else if ("arabesque".equals(pat)) {
                p.setStyle(Paint.Style.STROKE); cv.drawCircle(x, y, st * .5f, p); cv.drawCircle(x + st / 2, y + st / 2, st * .22f, p);
            } else if ("dots".equals(pat)) {
                p.setStyle(Paint.Style.FILL); cv.drawCircle(x + st / 2, y + st / 2, Math.max(1, st * .04f), p);
            }
        }
    }

    static final String[] DAYS = {"ح", "ن", "ث", "ر", "خ", "ج", "س"};

    static void el(Context c, Canvas cv, JSONObject e, int W, int H, Data D, JSONObject sp) {
        if (e.optBoolean("hid")) return;
        float X = (float) e.optDouble("x") / 100 * W, Y = (float) e.optDouble("y") / 100 * H, BW = (float) e.optDouble("w") / 100 * W, BH = (float) e.optDouble("h") / 100 * H, u = H / 100f;
        float op = (float) e.optDouble("op", 1);
        String T = e.optString("t"), font = e.optString("font", "tajawal"), fw = e.optString("fw", "700"), al = e.optString("al", "center");
        int C = col(e.optString("c"), 0xFFFFFFFF), C2 = col(e.optString("c2"), 0xFFD8B45A);
        float fs = (float) e.optDouble("fs", 10) * u;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        switch (T) {
            case "shape": {
                String kind = e.optString("kind", "rect");
                int fill = col(e.optString("fill"), 0), stroke = col(e.optString("stroke"), 0);
                float sw = (float) e.optDouble("sw", 0);
                if ("line".equals(kind)) {
                    p.setStyle(Paint.Style.STROKE); p.setColor(alphaMul(stroke != 0 ? stroke : fill, op)); p.setStrokeWidth(Math.max(1, sw > 0 ? sw * u / 4 : u * .6f));
                    cv.drawLine(X, Y + BH / 2, X + BW, Y + BH / 2, p); return;
                }
                Path sh = new Path();
                if ("circle".equals(kind)) sh.addOval(new RectF(X, Y, X + BW, Y + BH), Path.Direction.CW);
                else sh = rr(X, Y, BW, BH, "pill".equals(kind) ? BH / 2 : (float) e.optDouble("r", 0) / 100 * Math.min(BW, BH) * 2);
                if (fill != 0) { p.setColor(alphaMul(fill, op)); cv.drawPath(sh, p); }
                if (stroke != 0 && sw > 0) { p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(sw * u / 4); p.setColor(alphaMul(stroke, op)); cv.drawPath(sh, p); }
                return;
            }
            case "text": {
                String txt = tok(e.optString("text"), D, sp);
                int pill = col(e.optString("pill"), 0);
                if (pill != 0) { p.setColor(alphaMul(pill, op)); cv.drawPath(rr(X, Y, BW, BH, BH / 2), p); }
                float pad = pill != 0 ? BH * .35f : 0;
                textBlock(c, cv, txt, X + pad, Y, BW - pad * 2, BH, fs, fw, font, al, C, (float) e.optDouble("lh", 1.25), (float) e.optDouble("ls", 0), e.optBoolean("sh"), op);
                return;
            }
            case "clock": {
                String st = e.optString("style", "digital");
                int hh = D.now.get(Calendar.HOUR_OF_DAY), mi = D.now.get(Calendar.MINUTE);
                if ("digital".equals(st)) {
                    textBlock(c, cv, hm(D.now.getTimeInMillis(), sp, e.optBoolean("ampm")), X, Y, BW, BH, BH * .8f, fw, font, "center", C, 1.25f, 0, false, op);
                } else if ("flip".equals(st)) {
                    String h = dig(String.format(java.util.Locale.US, "%02d", hh % 12 == 0 ? 12 : hh % 12), sp), m = dig(String.format(java.util.Locale.US, "%02d", mi), sp);
                    float g = BW * .06f, cw = (BW - g) / 2;
                    int bgc = col(e.optString("bg"), 0xFF2A2A2E); if (e.optString("bg").isEmpty()) bgc = 0xFF2A2A2E;
                    String[] vs = {m, h}; float[] xs = {X, X + cw + g};
                    for (int i = 0; i < 2; i++) {
                        p.setColor(alphaMul(bgc, op)); cv.drawPath(rr(xs[i], Y, cw, BH, BH * .14f), p);
                        p.setColor(alphaMul(0x59000000, op)); float lw = Math.max(1, BH * .012f); cv.drawRect(xs[i], Y + BH / 2 - lw, xs[i] + cw, Y + BH / 2 + Math.max(1, BH * .024f) - lw, p);
                        textBlock(c, cv, vs[i], xs[i], Y, cw, BH, BH * .62f, "700", font, "center", C, 1.25f, 0, false, op);
                    }
                } else {
                    float cx = X + BW / 2, cy = Y + BH / 2, R = Math.min(BW, BH) / 2;
                    int bgc = col(e.optString("bg"), 0);
                    if (bgc != 0) { p.setColor(alphaMul(bgc, op)); cv.drawCircle(cx, cy, R, p); }
                    p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(Math.max(1, R * .03f)); p.setColor(alphaMul(C, op * .5f)); cv.drawCircle(cx, cy, R * .96f, p);
                    p.setColor(alphaMul(C, op));
                    for (int i = 1; i <= 12; i++) {
                        double a = i * Math.PI / 6 - Math.PI / 2;
                        if ("analogAr".equals(st)) {
                            Paint t = tp(c, R * .2f, "700", font); t.setColor(alphaMul(C, op)); t.setTextAlign(Paint.Align.CENTER);
                            Paint.FontMetrics fm = t.getFontMetrics();
                            JSONObject arD = new JSONObject(); try { arD.put("digits", "ar"); } catch (Exception ignored) {}
                            cv.drawText(dig(String.valueOf(i), arD), cx + (float) Math.cos(a) * R * .78f, cy + (float) Math.sin(a) * R * .78f - (fm.ascent + fm.descent) / 2, t);
                        } else {
                            float k2 = i % 3 != 0 ? .88f : .92f;
                            p.setStrokeWidth(Math.max(1, R * (i % 3 != 0 ? .025f : .05f)));
                            cv.drawLine(cx + (float) Math.cos(a) * R * .82f, cy + (float) Math.sin(a) * R * .82f, cx + (float) Math.cos(a) * R * k2, cy + (float) Math.sin(a) * R * k2, p);
                        }
                    }
                    double hd = ((hh % 12) + mi / 60.0) * Math.PI / 6 - Math.PI / 2, md = mi * Math.PI / 30 - Math.PI / 2;
                    p.setStrokeCap(Paint.Cap.ROUND);
                    p.setStrokeWidth(R * .07f); cv.drawLine(cx, cy, cx + (float) Math.cos(hd) * R * .5f, cy + (float) Math.sin(hd) * R * .5f, p);
                    p.setStrokeWidth(R * .045f); cv.drawLine(cx, cy, cx + (float) Math.cos(md) * R * .74f, cy + (float) Math.sin(md) * R * .74f, p);
                    p.setStyle(Paint.Style.FILL); p.setColor(alphaMul(C2, op)); cv.drawCircle(cx, cy, R * .06f, p);
                }
                return;
            }
            case "nextp": {
                List<Object[]> lines = new ArrayList<>();
                lines.add(new Object[]{D.nextN != null ? D.nextN : (D.loc ? "—" : "حدّد موقعك"), fs, C, "800"});
                if (e.optBoolean("showTime") && D.nextN != null) lines.add(new Object[]{hm(D.nextT, sp, true), fs * .8f, C2, "700"});
                if (e.optBoolean("showIq") && D.nextN != null && D.nextIq > 0) lines.add(new Object[]{"الإقامة: " + hm(D.nextIq, sp, true), fs * .42f, C, "500"});
                if (e.optBoolean("showCd") && D.nextN != null) { int c3 = col(e.optString("c3"), 0); lines.add(new Object[]{tok("{countdown}", D, sp), fs * .5f, c3 != 0 ? c3 : C, "700"}); }
                float tot = 0; for (Object[] l : lines) tot += (float) l[1] * 1.15f;
                float k = Math.min(1, BH / tot), y = Y + (BH - tot * k) / 2;
                for (Object[] l : lines) { float s = (float) l[1] * k; textBlock(c, cv, (String) l[0], X, y, BW, s * 1.15f, s, (String) l[3], font, al, (int) l[2], 1.25f, 0, false, op); y += s * 1.15f; }
                return;
            }
            case "prayers": {
                List<String[]> P = new ArrayList<>();
                for (String[] q : D.prayers) if (e.optBoolean("sunrise") || "0".equals(q[4])) P.add(q);
                if (P.isEmpty()) { textBlock(c, cv, "حدّد موقعك لعرض المواقيت", X, Y, BW, BH, fs, "500", font, "center", C, 1.25f, 0, false, op); return; }
                int n = P.size(); boolean times = e.optBoolean("times", true);
                for (int i = 0; i < n; i++) {
                    String[] q = P.get(i); boolean on = "1".equals(q[3]); int cc = on ? C2 : C; long at = Long.parseLong(q[2]);
                    if ("row".equals(e.optString("dir", "row"))) {
                        float cw = BW / n, x = X + BW - (i + 1) * cw;
                        textBlock(c, cv, q[1], x, Y, cw, times ? BH * .5f : BH, fs, on ? "800" : "600", font, "center", cc, 1.25f, 0, false, op);
                        if (times) textBlock(c, cv, hm(at, sp, false), x, Y + BH * .5f, cw, BH * .5f, fs * .95f, "700", font, "center", cc, 1.25f, 0, false, op);
                    } else {
                        float rh = BH / n, y = Y + i * rh;
                        textBlock(c, cv, q[1], times ? X + BW * .5f : X, y, times ? BW * .5f : BW, rh, fs, on ? "800" : "600", font, "right", cc, 1.25f, 0, false, op);
                        if (times) textBlock(c, cv, hm(at, sp, false), X, y, BW * .5f, rh, fs, "700", font, "left", cc, 1.25f, 0, false, op);
                    }
                }
                return;
            }
            case "calendar": {
                int bgc = col(e.optString("bg"), 0);
                if (bgc != 0) { p.setColor(alphaMul(bgc, op)); cv.drawPath(rr(X, Y, BW, BH, Math.min(BW, BH) * .08f), p); }
                Calendar now = D.now; int yy = now.get(Calendar.YEAR), mm = now.get(Calendar.MONTH), dd = now.get(Calendar.DAY_OF_MONTH);
                if ("week".equals(e.optString("kind"))) {
                    Calendar s0 = (Calendar) now.clone(); s0.add(Calendar.DAY_OF_MONTH, -(now.get(Calendar.DAY_OF_WEEK) - 1));
                    float cw = BW / 7;
                    for (int i = 0; i < 7; i++) {
                        Calendar d = (Calendar) s0.clone(); d.add(Calendar.DAY_OF_MONTH, i);
                        float x = X + BW - (i + 1) * cw; boolean on = d.get(Calendar.DAY_OF_MONTH) == dd;
                        textBlock(c, cv, DAYS[i], x, Y, cw, BH * .45f, BH * .24f, "500", "tajawal", "center", C, 1.25f, 0, false, op);
                        if (on) { p.setColor(alphaMul(C2, op)); cv.drawPath(rr(x + cw * .15f, Y + BH * .5f, cw * .7f, BH * .44f, BH * .2f), p); }
                        textBlock(c, cv, dig(String.valueOf(d.get(Calendar.DAY_OF_MONTH)), sp), x, Y + BH * .5f, cw, BH * .44f, BH * .28f, "700", "tajawal", "center", on ? 0xFF1A1A1A : C, 1.25f, 0, false, op);
                    }
                } else {
                    Calendar f = Calendar.getInstance(); f.set(yy, mm, 1);
                    int first = f.get(Calendar.DAY_OF_WEEK) - 1, days = f.getActualMaximum(Calendar.DAY_OF_MONTH), rows = (int) Math.ceil((first + days) / 7.0);
                    boolean head = e.optBoolean("head", true);
                    float hh = head ? BH * .16f : 0, cw = BW / 7, rh = (BH - hh - BH * .12f) / rows;
                    if (head) textBlock(c, cv, D.gm + " " + dig(String.valueOf(yy), sp), X, Y, BW, hh, hh * .62f, "700", "tajawal", "center", C, 1.25f, 0, false, op);
                    for (int i = 0; i < 7; i++) textBlock(c, cv, DAYS[i], X + BW - (i + 1) * cw, Y + hh, cw, BH * .12f, BH * .07f, "500", "tajawal", "center", C, 1.25f, 0, false, op);
                    for (int k = 1; k <= days; k++) {
                        int idx = first + k - 1, r = idx / 7, cl = idx % 7; float x = X + BW - (cl + 1) * cw, y = Y + hh + BH * .12f + r * rh;
                        if (k == dd) { p.setColor(alphaMul(C2, op)); cv.drawPath(rr(x + cw * .12f, y + rh * .08f, cw * .76f, rh * .84f, rh * .3f), p); }
                        textBlock(c, cv, dig(String.valueOf(k), sp), x, y, cw, rh, Math.min(rh * .55f, cw * .42f), k == dd ? "800" : "500", "tajawal", "center", k == dd ? 0xFF1A1A1A : C, 1.25f, 0, false, op);
                    }
                }
                return;
            }
            case "moon": {
                float R = Math.min(BW, BH) / 2 * .92f;
                double syn = 29.530588853; long ref = 947182440000L; // 2000-01-06 18:14 UTC
                double ph = ((((D.now.getTimeInMillis() - ref) / 864e5) % syn + syn) % syn) / syn, f = (1 - Math.cos(2 * Math.PI * ph)) / 2;
                int sz = Math.max(8, (int) Math.ceil(R * 2 * 2));
                Bitmap oc = Bitmap.createBitmap(sz, sz, Bitmap.Config.ARGB_8888); Canvas o = new Canvas(oc); float r = sz / 2f;
                Paint q = new Paint(Paint.ANTI_ALIAS_FLAG); q.setColor(C); o.drawCircle(r, r, r, q);
                q.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_OUT)); o.drawCircle(r + (ph < .5 ? -1 : 1) * 2 * r * (float) f, r, r * 1.02f, q);
                q.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_OVER)); q.setColor(col(e.optString("dark"), 0x55000000)); if (e.optString("dark").isEmpty()) q.setColor(0x55000000); o.drawCircle(r, r, r, q);
                Paint bp = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG); bp.setAlpha(Math.round(255 * op));
                cv.drawBitmap(oc, null, new RectF(X + BW / 2 - R, Y + BH / 2 - R, X + BW / 2 + R, Y + BH / 2 + R), bp); oc.recycle();
                return;
            }
            case "ayah": {
                // النص القرآني يأتي حرفياً من التطبيق (QT.text) دون أي تعديل
                String t = e.optString("txt"); boolean br = e.optBoolean("br", true), ref = e.optBoolean("ref", true);
                String full = (br ? "﴿ " : "") + t + (br ? " ﴾" : "");
                float rh = ref ? BH * .2f : 0;
                textBlock(c, cv, full, X, Y, BW, BH - rh, fs, "400", "quran", al, C, 1.6f, 0, false, op);
                if (ref) textBlock(c, cv, "سورة " + e.optString("sname") + " · " + dig(String.valueOf(e.optInt("a")), sp), X, Y + BH - rh, BW, rh, Math.min(rh * .6f, fs * .55f), "500", "tajawal", al, alphaMul(C, 0xBB / 255f), 1.25f, 0, false, op);
                return;
            }
            case "dhikr": {
                boolean cnt = e.optBoolean("count"); float ch = cnt ? BH * .32f : 0;
                textBlock(c, cv, e.optString("txt"), X, Y, BW, BH - ch, fs, "700", font, "center", C, 1.5f, 0, false, op);
                if (cnt) {
                    int v = 0;
                    try { String day = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(D.now.getTime()); if (day.equals(sp.optString("toRamDay"))) v = e.optInt("cnt", 0); } catch (Exception ignored) {}
                    textBlock(c, cv, dig(String.valueOf(v), sp), X, Y + BH - ch, BW, ch, ch * .8f, "800", "tajawal", "center", C2, 1.25f, 0, false, op);
                }
                return;
            }
            case "icon": {
                String d = ICONS.get(e.optString("name", "star"));
                if (d == null) return;
                float s = Math.min(BW, BH);
                Path ip = svgPath(d);
                if (ip == null) return;
                android.graphics.Matrix mx = new android.graphics.Matrix(); mx.setScale(s / 24, s / 24); mx.postTranslate(X + (BW - s) / 2, Y + (BH - s) / 2); ip.transform(mx);
                if (e.optBoolean("fill")) { p.setStyle(Paint.Style.FILL); p.setColor(alphaMul(C, op)); cv.drawPath(ip, p); }
                p.setStyle(Paint.Style.STROKE); p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeJoin(Paint.Join.ROUND); p.setStrokeWidth((float) e.optDouble("sw", 1.6) * s / 24); p.setColor(alphaMul(C, op)); cv.drawPath(ip, p);
                return;
            }
            case "image": {
                cv.save(); cv.clipPath(rr(X, Y, BW, BH, (float) e.optDouble("r", 0) / 100 * Math.min(BW, BH) * 2));
                Bitmap im = img(c, e.optString("src"), BW, BH);
                if (im != null) { cover(cv, im, X, Y, BW, BH, op); im.recycle(); } else { p.setColor(alphaMul(0x44888888, op)); cv.drawRect(X, Y, X + BW, Y + BH, p); }
                int dim = e.optInt("dim", 0); if (dim > 0) { p.setColor(alphaMul(Math.round(dim / 100f * 255) << 24, op)); cv.drawRect(X, Y, X + BW, Y + BH, p); }
                cv.restore();
                return;
            }
            case "player": {
                textBlock(c, cv, e.optString("title"), X, Y, BW, BH * .3f, BH * .2f, "700", "tajawal", "center", C, 1.25f, 0, false, op);
                textBlock(c, cv, e.optString("sub"), X, Y + BH * .28f, BW, BH * .2f, BH * .13f, "400", "tajawal", "center", alphaMul(C, 0xAA / 255f), 1.25f, 0, false, op);
                float cy = Y + BH * .64f, s = BH * .13f; p.setColor(alphaMul(C, op));
                for (int k = -1; k <= 1; k++) {
                    float cx = X + BW / 2 + k * BW * .25f; Path q = new Path();
                    if (k == 0) { q.moveTo(cx - s * .5f, cy - s * .7f); q.lineTo(cx + s * .7f, cy); q.lineTo(cx - s * .5f, cy + s * .7f); q.close(); }
                    else { int d = k; q.moveTo(cx - d * s * .5f, cy - s * .5f); q.lineTo(cx + d * s * .3f, cy); q.lineTo(cx - d * s * .5f, cy + s * .5f); q.close(); float rx = cx + d * s * .3f - (d > 0 ? 0 : s * .12f); q.addRect(rx, cy - s * .5f, rx + s * .12f, cy + s * .5f, Path.Direction.CW); }
                    cv.drawPath(q, p);
                }
                p.setColor(alphaMul(C, op * 0x44 / 255f)); cv.drawPath(rr(X + BW * .05f, Y + BH * .86f, BW * .9f, BH * .05f, BH * .03f), p);
                p.setColor(alphaMul(C2, op)); cv.drawPath(rr(X + BW * .5f, Y + BH * .86f, BW * .45f, BH * .05f, BH * .03f), p);
                return;
            }
            case "progress": {
                float f = Math.min(1, D.rf);
                if ("ring".equals(e.optString("kind"))) {
                    float cx = X + BW / 2, cy = Y + BH / 2, R = Math.min(BW, BH) / 2 * .85f;
                    p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(R * .18f); p.setColor(alphaMul(C2, op)); cv.drawCircle(cx, cy, R, p);
                    if (f > 0) { p.setColor(alphaMul(C, op)); p.setStrokeCap(Paint.Cap.ROUND); cv.drawArc(new RectF(cx - R, cy - R, cx + R, cy + R), -90, -f * 360, false, p); }
                    textBlock(c, cv, dig(String.valueOf(Math.round(f * 100)), sp) + "٪", X, Y, BW, BH, R * .5f, "800", "tajawal", "center", C, 1.25f, 0, false, op);
                } else {
                    p.setColor(alphaMul(C2, op)); cv.drawPath(rr(X, Y, BW, BH, BH / 2), p);
                    p.setColor(alphaMul(C, op)); if (f > 0) cv.drawPath(rr(X + BW * (1 - f), Y, BW * f, BH, BH / 2), p);
                }
                return;
            }
            default:
        }
    }

    static final java.util.HashMap<String, String> ICONS = new java.util.HashMap<>();
    static {
        ICONS.put("kaaba", "M4 8l8-4 8 4v10l-8 4-8-4zM4 8l8 4 8-4M12 12v10M4 11l8 4 8-4");
        ICONS.put("rosary", "M12 3a4 4 0 1 0 0 .01M8 7c-3 3-4 7-2 10M16 7c3 3 4 7 2 10M6 17a6 6 0 0 0 12 0M12 20v2");
        ICONS.put("quran", "M3 6c3-1 6-1 9 1 3-2 6-2 9-1v12c-3-1-6-1-9 1-3-2-6-2-9-1zM12 7v12");
        ICONS.put("moon", "M15.5 4.2a8 8 0 1 0 4.3 12.8A7 7 0 0 1 15.5 4.2z");
        ICONS.put("sun", "M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8zM12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1L7 17M17 7l2.1-2.1");
        ICONS.put("mosque", "M5 21v-8h14v8M7 13a5 5 0 0 1 10 0M2 21h20M10.5 21v-3a1.5 1.5 0 0 1 3 0v3M12 4v4M20 21V9M19 9h2l-1-2z");
        ICONS.put("star", "M12 2l2.6 6.4L21 9l-5 4.4 1.6 6.6L12 16.6 6.4 20l1.6-6.6L3 9l6.4-.6z");
        ICONS.put("lantern", "M9 3h6M10 3v2h4V3M8 5h8l1 4-1 9H8L7 9zM9 18v2h6v-2M12 9v6");
        ICONS.put("bell", "M6 16V11a6 6 0 0 1 12 0v5l2 2H4zM10 20a2 2 0 0 0 4 0");
        ICONS.put("phone", "M6 3h4l2 5-3 2a11 11 0 0 0 5 5l2-3 5 2v4a2 2 0 0 1-2 2A17 17 0 0 1 4 5a2 2 0 0 1 2-2z");
        ICONS.put("person", "M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM4 21a8 8 0 0 1 16 0");
        ICONS.put("cloud", "M7 18h10a4 4 0 0 0 0-8 6 6 0 0 0-11.5 1.5A3.5 3.5 0 0 0 7 18z");
        ICONS.put("heart", "M12 20s-7-4.5-7-10a4 4 0 0 1 7-2.5A4 4 0 0 1 19 10c0 5.5-7 10-7 10z");
        ICONS.put("book", "M4 4h7a2 2 0 0 1 2 2v14a2 2 0 0 0-2-2H4zM20 4h-7a2 2 0 0 0-2 2v14a2 2 0 0 1 2-2h7z");
    }

    /** محلّل مسارات SVG صغير (M L H V C A Z بأحرفها الكبيرة والصغيرة) — يكفي لأيقونات الاستوديو */
    static Path svgPath(String d) {
        try {
            Path p = new Path();
            java.util.regex.Matcher m = java.util.regex.Pattern.compile("[MmLlHhVvCcAaZz]|-?\\d*\\.?\\d+(?:e-?\\d+)?").matcher(d);
            List<String> tk = new ArrayList<>(); while (m.find()) tk.add(m.group());
            int i = 0; char cmd = 'M'; float x = 0, y = 0, sx = 0, sy = 0;
            while (i < tk.size()) {
                String s = tk.get(i);
                if (Character.isLetter(s.charAt(0))) { cmd = s.charAt(0); i++; if (cmd == 'Z' || cmd == 'z') { p.close(); x = sx; y = sy; continue; } }
                boolean rel = Character.isLowerCase(cmd);
                switch (Character.toUpperCase(cmd)) {
                    case 'M': { float nx = f(tk, i++), ny = f(tk, i++); if (rel) { nx += x; ny += y; } p.moveTo(nx, ny); x = sx = nx; y = sy = ny; cmd = rel ? 'l' : 'L'; break; }
                    case 'L': { float nx = f(tk, i++), ny = f(tk, i++); if (rel) { nx += x; ny += y; } p.lineTo(nx, ny); x = nx; y = ny; break; }
                    case 'H': { float nx = f(tk, i++); if (rel) nx += x; p.lineTo(nx, y); x = nx; break; }
                    case 'V': { float ny = f(tk, i++); if (rel) ny += y; p.lineTo(x, ny); y = ny; break; }
                    case 'C': { float a = f(tk, i++), b = f(tk, i++), c2 = f(tk, i++), d2 = f(tk, i++), e = f(tk, i++), g = f(tk, i++);
                        if (rel) { a += x; b += y; c2 += x; d2 += y; e += x; g += y; } p.cubicTo(a, b, c2, d2, e, g); x = e; y = g; break; }
                    case 'A': { float rx = f(tk, i++), ry = f(tk, i++), rot = f(tk, i++); int la = (int) f(tk, i++), swp = (int) f(tk, i++); float nx = f(tk, i++), ny = f(tk, i++);
                        if (rel) { nx += x; ny += y; } arc(p, x, y, rx, ry, rot, la != 0, swp != 0, nx, ny); x = nx; y = ny; break; }
                    default: i++;
                }
            }
            return p;
        } catch (Throwable t) { return null; }
    }

    static float f(List<String> t, int i) { return Float.parseFloat(t.get(i)); }

    /** تحويل قوس SVG إلى منحنيات بيزيه */
    static void arc(Path p, float x0, float y0, float rx, float ry, float rotDeg, boolean large, boolean sweep, float x, float y) {
        if (rx == 0 || ry == 0) { p.lineTo(x, y); return; }
        double phi = Math.toRadians(rotDeg), cp = Math.cos(phi), sp = Math.sin(phi);
        double dx = (x0 - x) / 2, dy = (y0 - y) / 2, x1 = cp * dx + sp * dy, y1 = -sp * dx + cp * dy;
        rx = Math.abs(rx); ry = Math.abs(ry);
        double lam = x1 * x1 / (rx * rx) + y1 * y1 / (ry * ry); if (lam > 1) { rx *= Math.sqrt(lam); ry *= Math.sqrt(lam); }
        double num = rx * rx * ry * ry - rx * rx * y1 * y1 - ry * ry * x1 * x1, den = rx * rx * y1 * y1 + ry * ry * x1 * x1;
        double co = (large == sweep ? -1 : 1) * Math.sqrt(Math.max(0, num / den));
        double cxp = co * rx * y1 / ry, cyp = -co * ry * x1 / rx;
        double cx = cp * cxp - sp * cyp + (x0 + x) / 2, cy = sp * cxp + cp * cyp + (y0 + y) / 2;
        double t1 = Math.atan2((y1 - cyp) / ry, (x1 - cxp) / rx), t2 = Math.atan2((-y1 - cyp) / ry, (-x1 - cxp) / rx), dt = t2 - t1;
        if (sweep && dt < 0) dt += 2 * Math.PI; else if (!sweep && dt > 0) dt -= 2 * Math.PI;
        int segs = (int) Math.ceil(Math.abs(dt) / (Math.PI / 2)); double step = dt / segs, k = 4.0 / 3 * Math.tan(step / 4);
        double t = t1;
        for (int s = 0; s < segs; s++) {
            double c1 = Math.cos(t), s1 = Math.sin(t), c2 = Math.cos(t + step), s2 = Math.sin(t + step);
            double ax = c1 - k * s1, ay = s1 + k * c1, bx = c2 + k * s2, by = s2 - k * c2;
            p.cubicTo((float) (cx + rx * ax * cp - ry * ay * sp), (float) (cy + rx * ax * sp + ry * ay * cp),
                    (float) (cx + rx * bx * cp - ry * by * sp), (float) (cy + rx * bx * sp + ry * by * cp),
                    (float) (cx + rx * c2 * cp - ry * s2 * sp), (float) (cy + rx * c2 * sp + ry * s2 * cp));
            t += step;
        }
    }
}
