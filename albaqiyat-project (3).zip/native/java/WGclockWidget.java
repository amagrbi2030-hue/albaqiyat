package com.albaqiyat.app;

public class WGclockWidget extends BaseWidget {
    @Override
    protected String kind() { return "gclock"; }
}
