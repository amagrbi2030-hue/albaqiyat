package com.albaqiyat.app;

public class WRfRing extends RafiqWidget {
    @Override
    protected String kind() { return "rring"; }
}
