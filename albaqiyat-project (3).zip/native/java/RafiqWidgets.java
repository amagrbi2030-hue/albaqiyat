package com.albaqiyat.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * ويدجت «الرفيق اليومي»: ست ويدجت حقيقية قابلة لإعادة التحجيم، تقرأ مصدر البيانات الموحّد
 * (لقطة المهام التي يرسلها التطبيق + حالة الإنجاز المحلية التي يحدّثها الإشعار/الويدجت).
 * المظهر من «استوديو المظاهر» نفسه (WidgetModel.load(c, kind)).
 */
final class RafiqWidgets {
    private RafiqWidgets() {}
    static final String[] KINDS = {"rtasks", "rquran", "rring", "rprayer", "rstats", "rpick"};
    static final Class<?>[] CLS = {WRfTasks.class, WRfQuran.class, WRfRing.class, WRfPrayer.class, WRfStats.class, WRfPick.class};
    static final int[][] DEF = {{300, 150}, {220, 150}, {150, 150}, {300, 150}, {300, 150}, {220, 150}};
    static final String A_INC = "com.albaqiyat.app.RF_INC", A_PICK = "com.albaqiyat.app.RF_PICK", A_WREF = "com.albaqiyat.app.RF_WREF";

    static String kindOf(Context c, int id) {
        try {
            android.appwidget.AppWidgetProviderInfo pi = AppWidgetManager.getInstance(c).getAppWidgetInfo(id);
            if (pi != null) for (int i = 0; i < CLS.length; i++) if (pi.provider.getClassName().equals(CLS[i].getName())) return KINDS[i];
        } catch (Exception ignored) {}
        return "rtasks";
    }

    static boolean any(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        for (Class<?> k : CLS) try { if (m.getAppWidgetIds(new ComponentName(c, k)).length > 0) return true; } catch (Exception ignored) {}
        return false;
    }

    static void updateAll(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        for (int i = 0; i < CLS.length; i++) {
            try { for (int id : m.getAppWidgetIds(new ComponentName(c, CLS[i]))) render(c, m, id, KINDS[i]); } catch (Exception ignored) {}
        }
        scheduleRefresh(c);
        try { MyWidgets.updateAll(c); } catch (Throwable ignored) {}
    }

    // ── البيانات ──
    static final class Occ {
        String id, n, ic, mode, route, cat, pk; long s, e, l, sn; int target, amt; boolean done, cancel; long doneAt;
        String st = "sched";
    }

    static String today() { return new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(new java.util.Date()); }

    static java.util.List<Occ> day(Context c, String iso) {
        java.util.ArrayList<Occ> L = new java.util.ArrayList<>();
        JSONObject snap = RafiqEngine.obj(c, "snap");
        JSONObject days = snap.optJSONObject("days");
        JSONArray a = days == null ? null : days.optJSONArray(iso);
        if (a == null) return null;
        JSONObject done = RafiqEngine.obj(c, "done"), amts = RafiqEngine.obj(c, "amt"), snz = RafiqEngine.obj(c, "snz");
        long now = System.currentTimeMillis();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            Occ x = new Occ();
            x.id = o.optString("id"); x.n = o.optString("n"); x.ic = o.optString("ic"); x.mode = o.optString("m", "tap"); x.route = o.optString("r", "rafiq"); x.cat = o.optString("c"); x.pk = o.optString("pk");
            x.s = o.optLong("s"); x.e = o.optLong("e"); x.l = o.optLong("l"); x.target = Math.max(1, o.optInt("t", 1));
            x.amt = Math.max(o.optInt("a", 0), amts.optInt(x.id, 0));
            x.cancel = o.optBoolean("x", false);
            x.doneAt = o.optLong("d", 0); if (done.has(x.id)) x.doneAt = done.optLong(x.id, now);
            x.done = x.doneAt > 0;
            x.sn = Math.max(o.optLong("z", 0), snz.optLong(x.id, 0));
            if (x.done) x.st = "done";
            else if (x.cancel) x.st = "cancel";
            else if (now < x.s) x.st = "sched";
            else if (x.sn > now) x.st = "snoozed";
            else if (now <= x.l) x.st = x.amt > 0 ? "prog" : "due";
            else x.st = iso.compareTo(today()) < 0 ? "missed" : "late";
            L.add(x);
        }
        return L;
    }

    static boolean isDue(Occ o, long now) { return !o.cancel && (o.done || o.s <= now); }

    static String stName(String st) {
        switch (st) {
            case "done": return "مكتملة ✓"; case "due": return "حان وقتها"; case "prog": return "قيد الإنجاز"; case "late": return "متأخرة";
            case "snoozed": return "مؤجلة"; case "missed": return "فائتة"; case "cancel": return "ملغاة"; default: return "مجدولة";
        }
    }

    static String ar(long n) {
        String s = String.valueOf(n); StringBuilder b = new StringBuilder();
        for (char ch : s.toCharArray()) b.append(ch >= '0' && ch <= '9' ? (char) ('٠' + (ch - '0')) : ch);
        return b.toString();
    }

    static String clock(long ms) {
        java.util.Calendar k = java.util.Calendar.getInstance(); k.setTimeInMillis(ms);
        int h = k.get(java.util.Calendar.HOUR_OF_DAY), m = k.get(java.util.Calendar.MINUTE);
        return ar(h % 12 == 0 ? 12 : h % 12) + ":" + ar(m / 10) + ar(m % 10) + (h < 12 ? " ص" : " م");
    }

    static String unit(Occ o) { return "pages".equals(o.mode) ? "صفحة" : "minutes".equals(o.mode) ? "دقيقة" : "مرة"; }

    // ── الإجراءات ──
    static PendingIntent bcast(Context c, String action, String occ, int wid, int k) {
        Intent i = new Intent(c, RafiqReceiver.class);
        i.setAction(action);
        i.setData(Uri.parse("rafiqw://" + k + "/" + wid + "/" + Uri.encode(occ == null ? "" : occ)));
        if (occ != null) i.putExtra("occ", occ);
        i.putExtra("wid", wid);
        i.putExtra("src", "widget");
        return PendingIntent.getBroadcast(c, (wid * 31 + k) & 0x3FFFFFFF, i, AlarmScheduler.piFlags());
    }

    static PendingIntent open(Context c, String route, int wid, int k) {
        Intent li = c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
        if (li == null) return null;
        li.setData(Uri.parse("rafiqw://open/" + wid + "/" + k + "/" + Uri.encode(route)));
        li.putExtra("route", route);
        li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(c, (wid * 37 + k) & 0x3FFFFFFF, li, AlarmScheduler.piFlags());
    }

    /** +خطوة لمهمة قابلة للقياس من الويدجت */
    static void inc(Context c, String occ, int step, String src) {
        java.util.List<Occ> L = day(c, occ.substring(occ.indexOf('@') + 1));
        Occ x = null;
        if (L != null) for (Occ o : L) if (o.id.equals(occ)) x = o;
        if (x == null || x.done) return;
        int a = x.amt + Math.max(1, step);
        synchronized (RafiqEngine.LOCK) {
            JSONObject amts = RafiqEngine.obj(c, "amt");
            try { amts.put(occ, a); } catch (Exception ignored) {}
            RafiqEngine.trim(amts, 300);
            RafiqEngine.p(c).edit().putString("amt", amts.toString()).commit();
        }
        RafiqEngine.act(c, "amt", occ, System.currentTimeMillis(), a, src);
        if (a >= x.target) RafiqEngine.markDone(c, occ, src);
        else updateAll(c);
    }

    static void cyclePick(Context c, int wid) {
        JSONArray tasks = RafiqEngine.obj(c, "snap").optJSONArray("tasks");
        if (tasks == null || tasks.length() == 0) return;
        String cur = RafiqEngine.p(c).getString("pick_" + wid, "");
        int i = -1;
        for (int k = 0; k < tasks.length(); k++) if (cur.equals(tasks.optJSONObject(k).optString("id"))) i = k;
        String nx = tasks.optJSONObject((i + 1) % tasks.length()).optString("id");
        RafiqEngine.p(c).edit().putString("pick_" + wid, nx).commit();
        render(c, AppWidgetManager.getInstance(c), wid, "rpick");
    }

    // ── الرسم ──
    static int[] size(Context c, AppWidgetManager m, int id, String kind) {
        int ki = 0; for (int i = 0; i < KINDS.length; i++) if (KINDS[i].equals(kind)) ki = i;
        int w = DEF[ki][0], h = DEF[ki][1];
        try {
            Bundle o = m.getAppWidgetOptions(id);
            boolean land = c.getResources().getConfiguration().orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE;
            int a = o.getInt(land ? AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH : AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0);
            int b = o.getInt(land ? AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT : AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0);
            if (a > 0) w = a; if (b > 0) h = b;
        } catch (Exception ignored) {}
        return new int[]{w, h};
    }

    /** ٠ صغير، ١ متوسط، ٢ كبير — حسب المساحة الفعلية */
    static int cls(int w, int h) { return (w < 170 || h < 100) ? 0 : h >= 220 ? 2 : 1; }

    static Bitmap ring(float frac, int track, int col) {
        int s = 240;
        Bitmap b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(20); p.setStrokeCap(Paint.Cap.ROUND);
        RectF r = new RectF(16, 16, s - 16, s - 16);
        p.setColor(track); cv.drawArc(r, 0, 360, false, p);
        p.setColor(col);
        if (frac > 0) cv.drawArc(r, -90, -360 * Math.min(1f, frac), false, p); // عكس عقارب الساعة (اتجاه عربي)
        return b;
    }

    static Bitmap bar(float frac, int track, int col) {
        int w = 400, h = 16;
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(track); cv.drawRoundRect(new RectF(0, 0, w, h), h / 2f, h / 2f, p);
        if (frac > 0) { p.setColor(col); float fw = Math.max(h, w * Math.min(1f, frac)); cv.drawRoundRect(new RectF(w - fw, 0, w, h), h / 2f, h / 2f, p); }
        return b;
    }

    static Bitmap bars(int[][] v, int track, int col, int txt) {
        int w = 560, h = 200, n = v.length;
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        int max = 1; for (int[] x : v) max = Math.max(max, x[0]);
        float gap = 14, bw = (w - gap * (n + 1)) / n;
        for (int i = 0; i < n; i++) {
            float x1 = w - gap - i * (bw + gap), x0 = x1 - bw; // الأحدث يميناً… ثم نعكس ليكون اليوم يساراً؟ نُبقي اليوم على اليسار
            int idx = n - 1 - i;
            float hh = v[idx][0] == 0 ? 6 : Math.max(10, (h - 10) * v[idx][0] / (float) max);
            p.setColor(track); cv.drawRoundRect(new RectF(x0, h - hh, x1, h), 8, 8, p);
            if (v[idx][0] > 0 && v[idx][1] > 0) { p.setColor(col); float dh = hh * v[idx][1] / (float) v[idx][0]; cv.drawRoundRect(new RectF(x0, h - dh, x1, h), 8, 8, p); }
        }
        return b;
    }

    static void render(Context c, AppWidgetManager mgr, int id, String kind) {
        try { render0(c, mgr, id, kind); } catch (Throwable ignored) {}
    }

    private static void render0(Context c, AppWidgetManager mgr, int id, String kind) {
        WidgetModel m = WidgetModel.load(c, kind);
        int[] sz = size(c, mgr, id, kind);
        int k = cls(sz[0], sz[1]);
        String iso = today();
        long now = System.currentTimeMillis();
        java.util.List<Occ> L = day(c, iso);
        boolean have = L != null;
        if (L == null) L = new java.util.ArrayList<>();
        int due = 0, done = 0;
        Occ next = null, cur = null;
        for (Occ o : L) {
            if (isDue(o, now)) { due++; if (o.done) done++; }
            if ("sched".equals(o.st) && next == null) next = o;
            if (cur == null && ("due".equals(o.st) || "prog".equals(o.st) || "late".equals(o.st) || "snoozed".equals(o.st))) cur = o;
        }
        float frac = due == 0 ? 0 : done / (float) due;
        int track = WSkinArt.alpha(m.text, 0x40), acc = m.accent, tx = m.text, tx2 = m.text2;
        String layoutKind = "rtasks".equals(kind) && k == 0 ? "rring" : kind;
        int lay = "rtasks".equals(layoutKind) ? R.layout.rf_list : "rring".equals(layoutKind) ? R.layout.rf_ring : "rprayer".equals(layoutKind) ? R.layout.rf_prayer
            : "rstats".equals(layoutKind) ? R.layout.rf_stats : R.layout.rf_pick;
        RemoteViews v = new RemoteViews(c.getPackageName(), lay);
        Bundle opts = null; try { opts = mgr.getAppWidgetOptions(id); } catch (Exception ignored) {}
        v.setImageViewBitmap(R.id.rf_bg, WidgetArt.skinPlain(c, opts, sz[0], sz[1], m, false));
        PendingIntent openMain = open(c, "rafiq", id, 1);
        if (openMain != null) v.setOnClickPendingIntent(R.id.rf_root, openMain);
        String pct = ar(Math.round(frac * 100)) + "٪", cnt = ar(done) + " من " + ar(due);
        String nextTxt = !have ? "افتح التطبيق لتحديث مهام اليوم" : next != null ? "التالية: " + next.n + " · " + clock(next.s) : due > 0 && done == due ? "أتممت ما حان وقته — تقبّل الله" : "لا مهام قادمة اليوم";

        if (R.layout.rf_ring == lay) {
            v.setImageViewBitmap(R.id.rf_ring, ring(frac, track, acc));
            v.setTextViewText(R.id.rf_pct, pct); v.setTextColor(R.id.rf_pct, tx);
            v.setTextViewText(R.id.rf_cnt, cnt); v.setTextColor(R.id.rf_cnt, tx2);
            v.setTextViewText(R.id.rf_title, "الإنجاز اليومي"); v.setTextColor(R.id.rf_title, tx);
            v.setTextViewText(R.id.rf_next, cur != null ? cur.n + " — " + stName(cur.st) : nextTxt); v.setTextColor(R.id.rf_next, tx2);
            v.setViewVisibility(R.id.rf_next, k == 0 && sz[1] < 120 ? View.GONE : View.VISIBLE);
            v.setViewVisibility(R.id.rf_title, sz[1] < 90 ? View.GONE : View.VISIBLE);
        } else if (R.layout.rf_list == lay) {
            v.setImageViewBitmap(R.id.rf_ring, ring(frac, track, acc));
            v.setTextViewText(R.id.rf_title, "المهام الدينية اليومية"); v.setTextColor(R.id.rf_title, tx);
            v.setTextViewText(R.id.rf_sub, cnt + " · " + pct); v.setTextColor(R.id.rf_sub, tx2);
            v.setTextColor(R.id.rf_open, acc);
            v.setTextViewText(R.id.rf_next, nextTxt); v.setTextColor(R.id.rf_next, tx2);
            // الأولوية: حان وقتها والمتأخرة ثم القادمة ثم المكتملة
            java.util.ArrayList<Occ> show = new java.util.ArrayList<>();
            for (String want : new String[]{"due", "prog", "late", "snoozed", "sched", "done"}) for (Occ o : L) if (want.equals(o.st)) show.add(o);
            int rows = k == 2 ? 4 : Math.max(1, Math.min(2, (sz[1] - 84) / 38));
            int[] RID = {R.id.rf_row0, R.id.rf_row1, R.id.rf_row2, R.id.rf_row3}, IC = {R.id.rf_ic0, R.id.rf_ic1, R.id.rf_ic2, R.id.rf_ic3},
                NM = {R.id.rf_n0, R.id.rf_n1, R.id.rf_n2, R.id.rf_n3}, TM = {R.id.rf_t0, R.id.rf_t1, R.id.rf_t2, R.id.rf_t3}, BT = {R.id.rf_b0, R.id.rf_b1, R.id.rf_b2, R.id.rf_b3};
            for (int i = 0; i < 4; i++) {
                if (i >= rows || i >= show.size()) { v.setViewVisibility(RID[i], View.GONE); continue; }
                Occ o = show.get(i);
                v.setViewVisibility(RID[i], View.VISIBLE);
                v.setTextViewText(IC[i], o.ic);
                v.setTextViewText(NM[i], o.n); v.setTextColor(NM[i], tx);
                String sub = stName(o.st) + (o.s > 0 && o.e - o.s < 20 * 3600000L ? " · " + clock(o.s) : "") + (!"tap".equals(o.mode) ? " · " + ar(o.amt) + "/" + ar(o.target) : "");
                v.setTextViewText(TM[i], sub); v.setTextColor(TM[i], "late".equals(o.st) ? 0xFFFFB38A : tx2);
                boolean act = "due".equals(o.st) || "prog".equals(o.st) || "late".equals(o.st) || "snoozed".equals(o.st);
                if (o.done) { v.setTextViewText(BT[i], "✓"); v.setTextColor(BT[i], acc); v.setOnClickPendingIntent(BT[i], open(c, "rafiq:" + o.id, id, 10 + i)); }
                else if (act) {
                    boolean tap = "tap".equals(o.mode);
                    v.setTextViewText(BT[i], tap ? "○" : "+١"); v.setTextColor(BT[i], acc);
                    v.setOnClickPendingIntent(BT[i], tap ? bcast(c, RafiqEngine.A_DONE, o.id, id, 10 + i) : bcast(c, A_INC, o.id, id, 10 + i));
                } else { v.setTextViewText(BT[i], "·"); v.setTextColor(BT[i], tx2); v.setOnClickPendingIntent(BT[i], open(c, "rafiq:" + o.id, id, 10 + i)); }
                PendingIntent op = open(c, "rafiq:" + o.id, id, 20 + i);
                if (op != null) v.setOnClickPendingIntent(RID[i], op);
            }
            int more = show.size() - Math.min(rows, show.size());
            v.setTextViewText(R.id.rf_more, more > 0 ? "و" + ar(more) + " مهام أخرى — المس للفتح" : have && L.isEmpty() ? "لا مهام مفعّلة اليوم — أضفها من الرفيق اليومي" : "");
            v.setTextColor(R.id.rf_more, tx2);
            v.setViewVisibility(R.id.rf_next, k == 2 || rows >= 2 ? View.VISIBLE : View.GONE);
        } else if (R.layout.rf_prayer == lay) {
            String nn = m.next != null ? m.next.optString("name", "") : "";
            v.setTextViewText(R.id.rf_title, m.ok ? (nn.isEmpty() ? "الصلاة القادمة" : "صلاة " + nn.replace("صلاة ", "")) : "حدّد موقعك في التطبيق"); v.setTextColor(R.id.rf_title, tx);
            if (m.ok && m.next != null) {
                long at = m.next.optLong("at");
                v.setViewVisibility(R.id.rf_cd, View.VISIBLE);
                v.setChronometer(R.id.rf_cd, SystemClock.elapsedRealtime() + (at - now), null, true);
                if (Build.VERSION.SDK_INT >= 24) v.setChronometerCountDown(R.id.rf_cd, true);
                v.setTextColor(R.id.rf_cd, acc);
            } else v.setViewVisibility(R.id.rf_cd, View.GONE);
            v.setTextViewText(R.id.rf_sub, "مهام اليوم: " + cnt + " · " + pct); v.setTextColor(R.id.rf_sub, tx2);
            v.setImageViewBitmap(R.id.rf_bar, bar(frac, track, acc));
            String[] pk = {"fajr", "dhuhr", "asr", "maghrib", "isha"}, pn = {"الفجر", "الظهر", "العصر", "المغرب", "العشاء"};
            int[] PI = {R.id.rf_p0, R.id.rf_p1, R.id.rf_p2, R.id.rf_p3, R.id.rf_p4};
            for (int i = 0; i < 5; i++) {
                Occ po = null; for (Occ o : L) if (pk[i].equals(o.pk)) po = o;
                String sym = po == null ? "—" : po.done ? "✓" : "late".equals(po.st) ? "!" : "sched".equals(po.st) ? "○" : "●";
                v.setTextViewText(PI[i], pn[i] + "\n" + sym);
                v.setTextColor(PI[i], po != null && po.done ? acc : po != null && "late".equals(po.st) ? 0xFFFFB38A : tx);
                PendingIntent op = po != null ? open(c, "rafiq:" + po.id, id, 30 + i) : open(c, "prayer", id, 30 + i);
                if (op != null) v.setOnClickPendingIntent(PI[i], op);
            }
            v.setViewVisibility(R.id.rf_chips, k == 0 ? View.GONE : View.VISIBLE);
            v.setViewVisibility(R.id.rf_bar, sz[1] < 90 ? View.GONE : View.VISIBLE);
        } else if (R.layout.rf_stats == lay) {
            JSONObject snap = RafiqEngine.obj(c, "snap");
            JSONArray wk = snap.optJSONArray("week");
            int[][] vals = new int[7][2];
            int wd = 0, wn = 0;
            for (int i = 0; i < 7; i++) {
                JSONArray x = wk == null ? null : wk.optJSONArray(i);
                if (x != null) { vals[i][0] = x.optInt(1); vals[i][1] = x.optInt(2); if (iso.equals(x.optString(0))) { vals[i][0] = due; vals[i][1] = done; } }
                wd += vals[i][0]; wn += vals[i][1];
            }
            JSONArray mo = snap.optJSONArray("month");
            int md = mo == null ? 0 : mo.optInt(0), mn = mo == null ? 0 : mo.optInt(1);
            String tdKey = wk != null && wk.length() == 7 ? wk.optJSONArray(6).optString(0) : "";
            if (iso.equals(tdKey)) { md += due - (wk.optJSONArray(6).optInt(1)); mn += done - (wk.optJSONArray(6).optInt(2)); }
            v.setTextViewText(R.id.rf_title, "إحصائيات الإنجاز"); v.setTextColor(R.id.rf_title, tx);
            v.setTextViewText(R.id.rf_k0, "اليوم\n" + pct); v.setTextViewText(R.id.rf_k1, "الأسبوع\n" + (wd > 0 ? ar(Math.round(wn * 100f / wd)) + "٪" : "—"));
            v.setTextViewText(R.id.rf_k2, "الشهر\n" + (md > 0 ? ar(Math.round(mn * 100f / Math.max(1, md))) + "٪" : "—"));
            for (int r : new int[]{R.id.rf_k0, R.id.rf_k1, R.id.rf_k2}) v.setTextColor(r, tx);
            v.setImageViewBitmap(R.id.rf_bars, bars(vals, track, acc, tx2));
            v.setViewVisibility(R.id.rf_bars, k == 0 ? View.GONE : View.VISIBLE);
            v.setTextViewText(R.id.rf_sub, wd > 0 ? "آخر ٧ أيام: " + ar(wn) + " من " + ar(wd) : "تظهر الإحصائيات بعد تسجيل الإنجاز");
            v.setTextColor(R.id.rf_sub, tx2);
            PendingIntent st = open(c, "rfStats", id, 2);
            if (st != null) v.setOnClickPendingIntent(R.id.rf_root, st);
        } else { // rquran / rpick
            Occ o = null;
            if ("rquran".equals(kind)) { for (Occ x : L) if ("quran".equals(x.cat)) { o = x; break; } }
            else {
                String tid = RafiqEngine.p(c).getString("pick_" + id, RafiqEngine.p(c).getString("pickTpl", ""));
                for (Occ x : L) if (x.id.startsWith(tid + "@")) o = x;
                if (o == null && cur != null) o = cur;
                if (o == null && next != null) o = next;
            }
            v.setViewVisibility(R.id.rf_cycle, "rpick".equals(kind) ? View.VISIBLE : View.GONE);
            v.setOnClickPendingIntent(R.id.rf_cycle, bcast(c, A_PICK, null, id, 3));
            v.setTextColor(R.id.rf_cycle, tx2);
            if (o == null) {
                v.setTextViewText(R.id.rf_ic, "rquran".equals(kind) ? "📖" : "⭐");
                v.setTextViewText(R.id.rf_title, "rquran".equals(kind) ? "ورد القرآن الكريم" : "مهمة مختارة"); v.setTextColor(R.id.rf_title, tx);
                v.setTextViewText(R.id.rf_sub, !have ? "افتح التطبيق لتحديث مهام اليوم" : "rquran".equals(kind) ? "لا ورد قرآن اليوم — أضفه من الرفيق اليومي" : "لا مهام اليوم — المس ⇄ للتبديل");
                v.setTextColor(R.id.rf_sub, tx2);
                v.setImageViewBitmap(R.id.rf_bar, bar(0, track, acc));
                v.setViewVisibility(R.id.rf_btns, View.GONE);
            } else {
                v.setTextViewText(R.id.rf_ic, o.ic);
                v.setTextViewText(R.id.rf_title, o.n); v.setTextColor(R.id.rf_title, tx);
                boolean meas = !"tap".equals(o.mode);
                String sub = stName(o.st) + (o.e - o.s < 20 * 3600000L ? " · " + clock(o.s) + "–" + clock(o.e) : " · طوال اليوم") + (meas ? " · " + ar(o.amt) + " / " + ar(o.target) + " " + unit(o) : "");
                v.setTextViewText(R.id.rf_sub, sub); v.setTextColor(R.id.rf_sub, "late".equals(o.st) ? 0xFFFFB38A : tx2);
                v.setImageViewBitmap(R.id.rf_bar, bar(o.done ? 1f : meas ? o.amt / (float) o.target : 0f, track, acc));
                boolean act = !o.done && !o.cancel && !"sched".equals(o.st);
                v.setViewVisibility(R.id.rf_btns, sz[1] < 95 && k == 0 ? View.GONE : View.VISIBLE);
                v.setViewVisibility(R.id.rf_inc, meas && act ? View.VISIBLE : View.GONE);
                v.setTextViewText(R.id.rf_inc, "+١ " + ("pages".equals(o.mode) ? "صفحة" : "")); v.setTextColor(R.id.rf_inc, tx);
                v.setOnClickPendingIntent(R.id.rf_inc, bcast(c, A_INC, o.id, id, 4));
                v.setTextViewText(R.id.rf_done, o.done ? "✓ مكتملة" : act ? "✓ تم" : "مجدولة"); v.setTextColor(R.id.rf_done, o.done || act ? acc : tx2);
                if (act) v.setOnClickPendingIntent(R.id.rf_done, bcast(c, RafiqEngine.A_DONE, o.id, id, 5));
                else { PendingIntent op = open(c, "rafiq:" + o.id, id, 5); if (op != null) v.setOnClickPendingIntent(R.id.rf_done, op); }
                String route = "quran".equals(o.cat) ? "surahs" : "adhkar".equals(o.cat) ? "morning" : "dhikr".equals(o.cat) || "post".equals(o.cat) ? "tasbih" : "prayer".equals(o.cat) ? "prayer" : "rafiq:" + o.id;
                v.setTextViewText(R.id.rf_go, "quran".equals(o.cat) ? "📖 المصحف" : "adhkar".equals(o.cat) ? "الأذكار" : "dhikr".equals(o.cat) || "post".equals(o.cat) ? "المسبحة" : "فتح");
                v.setTextColor(R.id.rf_go, tx);
                PendingIntent go = open(c, route, id, 6);
                if (go != null) v.setOnClickPendingIntent(R.id.rf_go, go);
                PendingIntent op = open(c, "rafiq:" + o.id, id, 7);
                if (op != null) v.setOnClickPendingIntent(R.id.rf_root, op);
            }
        }
        mgr.updateAppWidget(id, v);
    }

    /** تحديث عند أقرب تغيّر في الحالة (بداية/نهاية مهلة/منتصف الليل) — منبّه غير دقيق لتوفير البطارية */
    static void scheduleRefresh(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        Intent i = new Intent(c, RafiqReceiver.class); i.setAction(A_WREF);
        PendingIntent pi = PendingIntent.getBroadcast(c, 77101, i, AlarmScheduler.piFlags());
        am.cancel(pi);
        if (!any(c)) return;
        long now = System.currentTimeMillis(), best;
        java.util.Calendar mid = java.util.Calendar.getInstance();
        mid.add(java.util.Calendar.DAY_OF_YEAR, 1); mid.set(java.util.Calendar.HOUR_OF_DAY, 0); mid.set(java.util.Calendar.MINUTE, 0); mid.set(java.util.Calendar.SECOND, 5);
        best = mid.getTimeInMillis();
        java.util.List<Occ> L = day(c, today());
        if (L != null) for (Occ o : L) for (long t : new long[]{o.s, o.l, o.sn}) if (t > now + 30000 && t < best) best = t;
        try {
            if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC, best + 5000, pi);
            else am.set(AlarmManager.RTC, best + 5000, pi);
        } catch (Exception ignored) {}
    }
}
