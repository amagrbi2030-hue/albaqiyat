package com.albaqiyat.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

/**
 * ويدجت «تصميمي الخاص»: تعرض تصميماً من «استوديو الويدجت» كما يظهر في المعاينة،
 * مع تحديث حيّ للوقت والمواقيت والتاريخ. التصاميم تُحفظ في ملف داخلي (قد تحتوي صوراً).
 */
final class MyWidgets {
    private MyWidgets() {}
    static final String A_TICK = "com.albaqiyat.app.MY_TICK";
    static final int[] CELL = {
            R.id.my_c0, R.id.my_c1, R.id.my_c2, R.id.my_c3, R.id.my_c4, R.id.my_c5, R.id.my_c6, R.id.my_c7,
            R.id.my_c8, R.id.my_c9, R.id.my_c10, R.id.my_c11, R.id.my_c12, R.id.my_c13, R.id.my_c14, R.id.my_c15};

    static SharedPreferences p(Context c) { return c.getSharedPreferences("mywidget", Context.MODE_PRIVATE); }

    static File file(Context c) { return new File(c.getFilesDir(), "mw_designs.json"); }

    static JSONObject designs(Context c) {
        try (FileInputStream in = new FileInputStream(file(c))) {
            byte[] b = new byte[(int) file(c).length()];
            int n = 0; while (n < b.length) { int r = in.read(b, n, b.length - n); if (r < 0) break; n += r; }
            return new JSONObject(new String(b, 0, n, "UTF-8"));
        } catch (Exception e) { return new JSONObject(); }
    }

    static void save(Context c, JSONObject d, String tpl) {
        try (FileOutputStream out = new FileOutputStream(file(c))) { out.write(d.toString().getBytes("UTF-8")); } catch (Exception ignored) {}
        if (tpl != null && !tpl.isEmpty()) p(c).edit().putString("tpl", tpl).commit();
    }

    static int[] ids(Context c) {
        try { return AppWidgetManager.getInstance(c).getAppWidgetIds(new ComponentName(c, WMyWidget.class)); } catch (Exception e) { return new int[0]; }
    }

    static String designOf(Context c, int id, JSONObject all) {
        String d = p(c).getString("w_" + id, null);
        if (d != null && all.has(d)) return d;
        String t = p(c).getString("tpl", null);
        if (t == null || !all.has(t)) { java.util.Iterator<String> it = all.keys(); t = it.hasNext() ? it.next() : null; }
        if (t != null) p(c).edit().putString("w_" + id, t).commit();
        return t;
    }

    static void assign(Context c, int id, String design) {
        p(c).edit().putString("w_" + id, design).commit();
        render(c, AppWidgetManager.getInstance(c), id);
        scheduleTick(c);
    }

    static void updateAll(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        for (int id : ids(c)) render(c, m, id);
        scheduleTick(c);
    }

    static void render(Context c, AppWidgetManager mgr, int id) {
        try { render0(c, mgr, id); } catch (Throwable t) {
            try { RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.my_widget); mgr.updateAppWidget(id, v); } catch (Throwable ignored) {}
        }
    }

    private static void render0(Context c, AppWidgetManager mgr, int id) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.my_widget);
        JSONObject all = designs(c);
        String did = designOf(c, id, all);
        JSONObject sp = did == null ? null : all.optJSONObject(did);
        float dens = c.getResources().getDisplayMetrics().density;
        int wdp = 250, hdp = 120;
        try {
            Bundle o = mgr.getAppWidgetOptions(id);
            boolean land = c.getResources().getConfiguration().orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE;
            int a = o.getInt(land ? AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH : AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0);
            int b = o.getInt(land ? AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT : AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0);
            if (a > 0) wdp = a; if (b > 0) hdp = b;
        } catch (Exception ignored) {}
        if (sp == null) {
            v.setTextViewText(R.id.my_empty, "افتح «استوديو الويدجيت» في التطبيق وصمّم ويدجيتك");
            v.setViewVisibility(R.id.my_empty, android.view.View.VISIBLE);
            PendingIntent op = open(c, "mwStudio", id, 99);
            if (op != null) v.setOnClickPendingIntent(R.id.my_root, op);
            mgr.updateAppWidget(id, v);
            return;
        }
        v.setViewVisibility(R.id.my_empty, android.view.View.GONE);
        double ar = MyRender.ar(sp);
        float bw = wdp * dens, bh = hdp * dens;
        float iw = bw, ih = (float) (bw / ar);
        if (ih > bh) { ih = bh; iw = (float) (bh * ar); }
        // حد ذاكرة صور الويدجت: عرض أقصى ٩٠٠ بكسل
        int W = (int) Math.max(60, Math.min(900, iw));
        Bitmap bmp = MyRender.render(c, sp, W);
        v.setImageViewBitmap(R.id.my_img, bmp);
        v.setContentDescription(R.id.my_img, sp.optString("name", "تصميمي"));
        // مناطق اللمس: شبكة ٤×٤ تُربط بإجراء العنصر الظاهر في مركز كل خلية
        float ox = (bw - iw) / 2, oy = (bh - ih) / 2;
        JSONArray els = sp.optJSONArray("els");
        for (int k = 0; k < 16; k++) {
            float cx = ((k % 4) + .5f) * bw / 4, cy = ((k / 4) + .5f) * bh / 4;
            float dx = (cx - ox) / iw * 100, dy = (cy - oy) / ih * 100;
            String act = "app"; int bz = Integer.MIN_VALUE;
            for (int i = 0; els != null && i < els.length(); i++) {
                JSONObject e = els.optJSONObject(i);
                if (e == null || e.optBoolean("hid")) continue;
                String a = e.optString("act", "");
                if (a.isEmpty()) continue;
                double x = e.optDouble("x"), y = e.optDouble("y"), w = e.optDouble("w"), h = e.optDouble("h");
                if (dx >= x && dx <= x + w && dy >= y && dy <= y + h && e.optInt("z") >= bz) { bz = e.optInt("z"); act = a; }
            }
            PendingIntent pi = action(c, act, id, k);
            if (pi != null) v.setOnClickPendingIntent(CELL[k], pi);
        }
        mgr.updateAppWidget(id, v);
    }

    static PendingIntent action(Context c, String act, int wid, int k) {
        if (act.startsWith("tel:")) {
            Intent i = new Intent(Intent.ACTION_DIAL, Uri.parse(act));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            return PendingIntent.getActivity(c, (wid * 53 + k) & 0x3FFFFFFF, i, AlarmScheduler.piFlags());
        }
        return open(c, "app".equals(act) ? "" : act, wid, k);
    }

    static PendingIntent open(Context c, String route, int wid, int k) {
        Intent li = c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
        if (li == null) return null;
        li.setData(Uri.parse("myw://open/" + wid + "/" + k + "/" + Uri.encode(route)));
        if (!route.isEmpty()) li.putExtra("route", route);
        li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(c, (wid * 53 + k) & 0x3FFFFFFF, li, AlarmScheduler.piFlags());
    }

    /** تحديث كل دقيقة فقط إن احتوى تصميم مضاف على ساعة أو عدّ تنازلي، وإلا عند أقرب تغيّر في المواقيت أو منتصف الليل */
    static void scheduleTick(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        Intent i = new Intent(c, WMyWidget.class); i.setAction(A_TICK);
        PendingIntent pi = PendingIntent.getBroadcast(c, 77301, i, AlarmScheduler.piFlags());
        am.cancel(pi);
        int[] ids = ids(c);
        if (ids.length == 0) return;
        JSONObject all = designs(c);
        boolean dyn = false;
        for (int id : ids) { String d = designOf(c, id, all); JSONObject sp = d == null ? null : all.optJSONObject(d); if (sp != null && MyRender.dynamic(sp)) dyn = true; }
        long now = System.currentTimeMillis(), at;
        if (dyn) at = (now / 60000 + 1) * 60000 + 500;
        else {
            java.util.Calendar mid = java.util.Calendar.getInstance();
            mid.add(java.util.Calendar.DAY_OF_YEAR, 1); mid.set(java.util.Calendar.HOUR_OF_DAY, 0); mid.set(java.util.Calendar.MINUTE, 0); mid.set(java.util.Calendar.SECOND, 5);
            at = Math.min(mid.getTimeInMillis(), now + 15 * 60000L);
            long wm = WidgetModel.nextChange(c);
            if (wm > now) at = Math.min(at, wm + 2000);
        }
        try {
            // منبّه غير موقظ: لا يعمل والشاشة مطفأة، فلا يستهلك البطارية
            if (dyn && Build.VERSION.SDK_INT >= 23) {
                try { am.setExact(AlarmManager.RTC, at, pi); } catch (SecurityException se) { am.set(AlarmManager.RTC, at, pi); }
            } else am.set(AlarmManager.RTC, at, pi);
        } catch (Exception ignored) {}
    }
}
