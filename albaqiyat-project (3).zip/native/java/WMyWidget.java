package com.albaqiyat.app;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

/** مزوّد ويدجت «تصميمي الخاص» (قابلة لإعادة التحجيم، وتظهر في قائمة الأدوات) */
public class WMyWidget extends AppWidgetProvider {
    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        for (int id : ids) MyWidgets.render(c, m, id);
        MyWidgets.scheduleTick(c);
    }

    @Override
    public void onAppWidgetOptionsChanged(Context c, AppWidgetManager m, int id, Bundle o) {
        MyWidgets.render(c, m, id);
    }

    @Override
    public void onReceive(Context c, Intent i) {
        String a = i.getAction();
        if (MyWidgets.A_TICK.equals(a) || Intent.ACTION_TIME_CHANGED.equals(a) || Intent.ACTION_TIMEZONE_CHANGED.equals(a) || "android.intent.action.TIME_SET".equals(a)) {
            MyWidgets.updateAll(c);
            return;
        }
        super.onReceive(c, i);
    }

    @Override
    public void onDeleted(Context c, int[] ids) {
        android.content.SharedPreferences.Editor e = MyWidgets.p(c).edit();
        for (int id : ids) e.remove("w_" + id);
        e.commit();
    }

    @Override
    public void onRestored(Context c, int[] oldIds, int[] newIds) {
        android.content.SharedPreferences p = MyWidgets.p(c);
        android.content.SharedPreferences.Editor e = p.edit();
        for (int i = 0; i < oldIds.length && i < newIds.length; i++) { String v = p.getString("w_" + oldIds[i], null); if (v != null) e.putString("w_" + newIds[i], v).remove("w_" + oldIds[i]); }
        e.commit();
    }
}
