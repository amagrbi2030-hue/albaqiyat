package com.albaqiyat.app;

public class WTasbih41 extends TasbihWidget {
    @Override
    protected String kind() { return "tb41"; }
}
