package com.albaqiyat.app;

public class WCalli3Widget extends BaseWidget {
    @Override
    protected String kind() { return "calli3"; }
}
