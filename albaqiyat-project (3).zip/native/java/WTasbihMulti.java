package com.albaqiyat.app;

public class WTasbihMulti extends TasbihWidget {
    @Override
    protected String kind() { return "tbm"; }
}
