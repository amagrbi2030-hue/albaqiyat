package com.albaqiyat.app;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Iterator;

/**
 * «الرفيق اليومي للعبادات»: محرك الإشعارات الأصلي.
 * يحسب التطبيق (JS) أحداث التنبيه للأيام القادمة من قواعد كل مهمة ومواقيت الصلاة،
 * ويخزّنها هنا. المحرك يضبط منبّهاً واحداً متسلسلاً لأقرب حدث، وعند إطلاقه يتحقق
 * من حالة المهمة (لا تذكير لمهمة مكتملة، لا تكرار، لا إشعارات قديمة منتهية).
 * إجراءات الإشعار (تم / لاحقاً) تُنفَّذ هنا فوراً وتُسجَّل ليقرأها التطبيق عند فتحه.
 */
final class RafiqEngine {
    private RafiqEngine() {}
    static final Object LOCK = new Object();
    static final String CH = "rafiq_v1";
    static final String A_FIRE = "com.albaqiyat.app.RF_FIRE";
    static final String A_DONE = "com.albaqiyat.app.RF_DONE";
    static final String A_SNOOZE = "com.albaqiyat.app.RF_SNOOZE";
    static final int RC_ALARM = 77100;
    static final long STALE_MS = 15 * 60 * 1000L;

    static SharedPreferences p(Context c) { return c.getSharedPreferences("rafiq", Context.MODE_PRIVATE); }

    static JSONArray arr(Context c, String k) { try { return new JSONArray(p(c).getString(k, "[]")); } catch (Exception e) { return new JSONArray(); } }
    static JSONObject obj(Context c, String k) { try { return new JSONObject(p(c).getString(k, "{}")); } catch (Exception e) { return new JSONObject(); } }

    /** من التطبيق: استبدال قائمة الأحداث القادمة وحالة الإنجاز */
    static void setPlan(Context c, JSONArray events, JSONObject done, int snoozeMin, boolean on, JSONObject snap, boolean hideLock) {
        synchronized (LOCK) {
            // حالة الإنجاز من التطبيق هي المرجع (يدعم تصحيح المستخدم)، مع إبقاء ما سجّله الإشعار ولم يقرأه التطبيق بعد
            JSONObject d = new JSONObject();
            try {
                Iterator<String> it = done.keys(); while (it.hasNext()) { String k = it.next(); d.put(k, done.optLong(k)); }
                JSONArray acts = arr(c, "acts");
                for (int i = 0; i < acts.length(); i++) { JSONObject a = acts.optJSONObject(i); if (a != null && "done".equals(a.optString("a"))) d.put(a.optString("occ"), a.optLong("at")); }
            } catch (Exception ignored) {}
            // تنظيف: الاحتفاظ بآخر ٤٠٠ فقط
            trim(d, 400);
            // مقادير التقدّم المحلية: نُبقي ما لم يقرأه التطبيق بعد، ونحذف ما صار في اللقطة
            JSONObject amts = obj(c, "amt"), snz = obj(c, "snz");
            JSONArray acts = arr(c, "acts");
            JSONObject keepA = new JSONObject(), keepZ = new JSONObject();
            try {
                for (int i = 0; i < acts.length(); i++) { JSONObject a = acts.optJSONObject(i); if (a == null) continue;
                    if ("amt".equals(a.optString("a")) && amts.has(a.optString("occ"))) keepA.put(a.optString("occ"), amts.optInt(a.optString("occ")));
                    if ("snooze".equals(a.optString("a"))) keepZ.put(a.optString("occ"), a.optLong("until")); }
            } catch (Exception ignored) {}
            SharedPreferences.Editor ed = p(c).edit().putString("events", events.toString()).putString("done", d.toString()).putString("amt", keepA.toString()).putString("snz", keepZ.toString())
                .putInt("snoozeMin", Math.max(5, snoozeMin)).putBoolean("on", on).putBoolean("hideLock", hideLock);
            if (snap != null) ed.putString("snap", snap.toString());
            ed.commit();
        }
        // إلغاء إشعارات مهام اكتملت
        try {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            Iterator<String> it = done.keys();
            while (nm != null && it.hasNext()) nm.cancel(nid(it.next()));
        } catch (Exception ignored) {}
        scheduleNext(c);
        RafiqWidgets.updateAll(c);
    }

    static void trim(JSONObject o, int max) {
        if (o.length() <= max) return;
        java.util.ArrayList<String> ks = new java.util.ArrayList<>();
        Iterator<String> it = o.keys(); while (it.hasNext()) ks.add(it.next());
        java.util.Collections.sort(ks);
        for (int i = 0; i < ks.size() - max; i++) o.remove(ks.get(i));
    }

    static int nid(String occ) { return 520000 + (occ.hashCode() & 0x7FFFF); }

    static PendingIntent alarmPi(Context c) {
        Intent i = new Intent(c, RafiqReceiver.class);
        i.setAction(A_FIRE);
        return PendingIntent.getBroadcast(c, RC_ALARM, i, AlarmScheduler.piFlags());
    }

    /** منبّه واحد متسلسل لأقرب حدث قادم لم يُطلَق ولم تكتمل مهمته */
    static void scheduleNext(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        PendingIntent pi = alarmPi(c);
        am.cancel(pi);
        long best = Long.MAX_VALUE, now = System.currentTimeMillis();
        synchronized (LOCK) {
            if (!p(c).getBoolean("on", true)) return;
            JSONArray ev = arr(c, "events");
            JSONObject done = obj(c, "done"), fired = obj(c, "fired");
            for (int i = 0; i < ev.length(); i++) {
                JSONObject e = ev.optJSONObject(i);
                if (e == null) continue;
                long t = e.optLong("t");
                if (fired.has(e.optString("id")) || t < now - STALE_MS) continue;
                String kd = e.optString("kind");
                if (!"summary".equals(kd) && !"weekly".equals(kd) && done.has(e.optString("occ"))) continue;
                if (t < best) best = t;
            }
        }
        if (best == Long.MAX_VALUE) return;
        long at = Math.max(best, now + 1000);
        try {
            if (Build.VERSION.SDK_INT >= 23 && AlarmScheduler.canExact(c)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            else if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            else am.set(AlarmManager.RTC_WAKEUP, at, pi);
        } catch (Exception e) {
            try { am.set(AlarmManager.RTC_WAKEUP, at, pi); } catch (Exception ignored) {}
        }
    }

    /** إطلاق كل الأحداث المستحقة الآن */
    static void fire(Context c) {
        long now = System.currentTimeMillis();
        java.util.ArrayList<JSONObject> post = new java.util.ArrayList<>();
        synchronized (LOCK) {
            JSONArray ev = arr(c, "events");
            JSONObject done = obj(c, "done"), fired = obj(c, "fired");
            for (int i = 0; i < ev.length(); i++) {
                JSONObject e = ev.optJSONObject(i);
                if (e == null) continue;
                String id = e.optString("id");
                long t = e.optLong("t");
                if (t > now + 30000 || fired.has(id)) continue;
                try { fired.put(id, now); } catch (Exception ignored) {}
                if (now - t > STALE_MS) continue; // إشعار قديم انتهت صلاحيته (بعد إغلاق/إعادة تشغيل): لا يُرسل
                boolean summary = "summary".equals(e.optString("kind")) || "weekly".equals(e.optString("kind"));
                if (!summary && done.has(e.optString("occ"))) continue; // لا تذكير لمهمة مكتملة
                post.add(e);
            }
            trim(fired, 500);
            p(c).edit().putString("fired", fired.toString()).commit();
        }
        // تجنب إشعارين للمهمة نفسها في الدفعة نفسها: نرسل آخر مرحلة فقط
        java.util.HashMap<String, JSONObject> last = new java.util.LinkedHashMap<>();
        for (JSONObject e : post) last.put(e.optString("occ"), e);
        for (JSONObject e : last.values()) {
            String kd = e.optString("kind");
            boolean ok = "summary".equals(kd) || "weekly".equals(kd) ? postSummary(c, e) : postTask(c, e);
            if (ok) act(c, "sent", e.optString("occ"), now, 0, e.optString("kind"));
        }
        scheduleNext(c);
    }

    static boolean channel(Context c, NotificationManager nm) {
        if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(CH) == null) {
            NotificationChannel ch = new NotificationChannel(CH, "الرفيق اليومي للعبادات", NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("تنبيهات مواعيد المهام والتذكير بما لم يُنجز");
            nm.createNotificationChannel(ch);
        }
        return Build.VERSION.SDK_INT < 24 || nm.areNotificationsEnabled();
    }

    static PendingIntent openPi(Context c, String occ) {
        Intent li = c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
        if (li == null) return null;
        li.setData(Uri.parse("rafiq://open/" + Uri.encode(occ)));
        li.putExtra("route", "rafiq" + (occ.isEmpty() ? "" : ":" + occ));
        li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(c, nid(occ) + 3, li, AlarmScheduler.piFlags());
    }

    static PendingIntent actPi(Context c, String action, JSONObject e, int k) {
        Intent i = new Intent(c, RafiqReceiver.class);
        i.setAction(action);
        String occ = e.optString("occ");
        i.setData(Uri.parse("rafiq://" + k + "/" + Uri.encode(occ)));
        i.putExtra("occ", occ);
        i.putExtra("title", e.optString("title"));
        return PendingIntent.getBroadcast(c, nid(occ) + k, i, AlarmScheduler.piFlags());
    }

    static int icon(Context c) {
        int ic = c.getResources().getIdentifier("ic_stat_salah", "drawable", c.getPackageName());
        return ic != 0 ? ic : android.R.drawable.ic_popup_reminder;
    }

    static boolean postTask(Context c, JSONObject e) {
        try {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null || !channel(c, nm)) return false;
            String occ = e.optString("occ");
            android.app.Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new android.app.Notification.Builder(c, CH) : new android.app.Notification.Builder(c);
            b.setSmallIcon(icon(c)).setContentTitle(e.optString("title")).setContentText(e.optString("body"))
             .setStyle(new android.app.Notification.BigTextStyle().bigText(e.optString("body")))
             .setAutoCancel(true).setOnlyAlertOnce(false).setCategory(android.app.Notification.CATEGORY_REMINDER).setWhen(System.currentTimeMillis());
            int tg = e.optInt("tg", 0);
            if (tg > 1) { // مؤشر تقدّم للمهام القابلة للقياس
                int a = Math.max(e.optInt("amt", 0), obj(c, "amt").optInt(occ, 0));
                b.setProgress(tg, Math.min(tg, a), false);
                b.setSubText(a + " / " + tg);
            }
            if (Build.VERSION.SDK_INT >= 21 && p(c).getBoolean("hideLock", false)) {
                b.setVisibility(android.app.Notification.VISIBILITY_PRIVATE);
                android.app.Notification.Builder pub = Build.VERSION.SDK_INT >= 26 ? new android.app.Notification.Builder(c, CH) : new android.app.Notification.Builder(c);
                pub.setSmallIcon(icon(c)).setContentTitle("الرفيق اليومي").setContentText("لديك مهمة حان وقتها");
                b.setPublicVersion(pub.build());
            }
            PendingIntent op = openPi(c, occ);
            if (op != null) b.setContentIntent(op);
            b.addAction(new android.app.Notification.Action.Builder(0, "تم الإنجاز ✓", actPi(c, A_DONE, e, 1)).build());
            b.addAction(new android.app.Notification.Action.Builder(0, "ذكّرني لاحقاً", actPi(c, A_SNOOZE, e, 2)).build());
            if (op != null) b.addAction(new android.app.Notification.Action.Builder(0, "فتح المهمة", op).build());
            // نمط «التنبيهات اليومية الدينية» من مركز تخصيص الإشعارات (الأزرار تبقى كما هي)
            try {
                if (NStyle.spec(c, "").optBoolean("daily", true)) {
                    NStyle.Info in = new NStyle.Info();
                    in.kind = "daily"; in.label = NStyle.label("daily");
                    in.title = e.optString("title"); in.sub = e.optString("body");
                    if (tg > 1) { in.progMax = tg; in.progVal = Math.max(e.optInt("amt", 0), obj(c, "amt").optInt(occ, 0)); in.timeText = in.progVal + " من " + tg; }
                    NStyle.apply(c, b, in);
                }
            } catch (Throwable ignored) {}
            nm.notify(nid(occ), b.build()); // نفس المعرّف لكل مراحل المهمة: يستبدل ولا يتكرر
            return true;
        } catch (Exception ex) { return false; }
    }

    static boolean postSummary(Context c, JSONObject e) {
        try {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null || !channel(c, nm)) return false;
            JSONArray occs = e.optJSONArray("occs");
            JSONObject done = obj(c, "done");
            int tot = occs == null ? 0 : occs.length(), n = 0;
            for (int i = 0; i < tot; i++) if (done.has(occs.optString(i))) n++;
            if (tot == 0) return false;
            boolean wk = "weekly".equals(e.optString("kind"));
            String body = wk ? "أنجزت هذا الأسبوع " + n + " من " + tot + " مهمة (" + Math.round(n * 100f / tot) + "٪). بارك الله في وقتك."
                : n >= tot ? "أنجزت مهامك اليوم كلها (" + n + ") — تقبّل الله منك"
                : "أنجزت " + n + " من " + tot + " مهمة اليوم، وبقي " + (tot - n) + ". ما زال في الوقت متّسع.";
            android.app.Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new android.app.Notification.Builder(c, CH) : new android.app.Notification.Builder(c);
            b.setSmallIcon(icon(c)).setContentTitle(wk ? "حصاد الأسبوع — الرفيق اليومي" : "ملخص اليوم — الرفيق اليومي").setContentText(body)
             .setStyle(new android.app.Notification.BigTextStyle().bigText(body)).setAutoCancel(true);
            PendingIntent op = openPi(c, "");
            if (op != null) b.setContentIntent(op);
            nm.notify(wk ? 519998 : 519999, b.build());
            return true;
        } catch (Exception ex) { return false; }
    }

    static void act(Context c, String a, String occ, long at, long until, String kind) {
        synchronized (LOCK) {
            try {
                JSONArray acts = arr(c, "acts");
                acts.put(new JSONObject().put("a", a).put("occ", occ).put("at", at).put("until", until).put("kind", kind == null ? "" : kind));
                while (acts.length() > 600) acts.remove(0);
                p(c).edit().putString("acts", acts.toString()).commit();
            } catch (Exception ignored) {}
        }
    }

    /** زر «تم الإنجاز» في الإشعار */
    static void markDone(Context c, String occ) { markDone(c, occ, "notif"); }

    static void markDone(Context c, String occ, String src) {
        long now = System.currentTimeMillis();
        synchronized (LOCK) {
            JSONObject d = obj(c, "done");
            try { d.put(occ, now); } catch (Exception ignored) {}
            p(c).edit().putString("done", d.toString()).commit();
        }
        act(c, "done", occ, now, 0, src == null ? "notif" : src);
        cancel(c, occ);
        scheduleNext(c);
        RafiqWidgets.updateAll(c);
    }

    /** زر «ذكّرني لاحقاً»: حدث جديد بعد مدة التأجيل، وحذف المراحل التي تقع قبله */
    static void snooze(Context c, String occ, String title) {
        long now = System.currentTimeMillis();
        long until;
        synchronized (LOCK) {
            until = now + p(c).getInt("snoozeMin", 15) * 60000L;
            try {
                JSONArray ev = arr(c, "events"), out = new JSONArray();
                for (int i = 0; i < ev.length(); i++) {
                    JSONObject e = ev.optJSONObject(i);
                    if (e == null) continue;
                    if (occ.equals(e.optString("occ")) && e.optLong("t") < until) continue;
                    out.put(e);
                }
                out.put(new JSONObject().put("id", occ + ":s" + now).put("occ", occ).put("t", until).put("kind", "snooze")
                    .put("title", title).put("body", "تذكير مؤجل — يمكنك إنجازها الآن أو تأجيلها مرة أخرى."));
                p(c).edit().putString("events", out.toString()).commit();
            } catch (Exception ignored) {}
        }
        synchronized (LOCK) {
            JSONObject z = obj(c, "snz");
            try { z.put(occ, until); } catch (Exception ignored) {}
            p(c).edit().putString("snz", z.toString()).commit();
        }
        act(c, "snooze", occ, now, until, "notif");
        cancel(c, occ);
        scheduleNext(c);
        RafiqWidgets.updateAll(c);
    }

    static void cancel(Context c, String occ) {
        try { NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE); if (nm != null) nm.cancel(nid(occ)); } catch (Exception ignored) {}
    }

    static JSONArray pull(Context c) {
        synchronized (LOCK) {
            JSONArray a = arr(c, "acts");
            p(c).edit().putString("acts", "[]").commit();
            return a;
        }
    }

    static JSONObject status(Context c) {
        JSONObject r = new JSONObject();
        try {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            boolean notif = nm != null && (Build.VERSION.SDK_INT < 24 || nm.areNotificationsEnabled());
            boolean chOk = true;
            if (nm != null && Build.VERSION.SDK_INT >= 26) {
                NotificationChannel ch = nm.getNotificationChannel(CH);
                chOk = ch == null || ch.getImportance() != NotificationManager.IMPORTANCE_NONE;
            }
            r.put("notif", notif).put("channel", chOk).put("exact", AlarmScheduler.canExact(c)).put("sdk", Build.VERSION.SDK_INT);
            JSONArray ev = arr(c, "events");
            long now = System.currentTimeMillis(), next = 0;
            JSONObject fired = obj(c, "fired"), done = obj(c, "done");
            int pending = 0;
            for (int i = 0; i < ev.length(); i++) {
                JSONObject e = ev.optJSONObject(i);
                if (e == null || fired.has(e.optString("id")) || e.optLong("t") < now) continue;
                if (!"summary".equals(e.optString("kind")) && done.has(e.optString("occ"))) continue;
                pending++;
                if (next == 0 || e.optLong("t") < next) next = e.optLong("t");
            }
            r.put("pending", pending).put("next", next);
        } catch (Exception ignored) {}
        return r;
    }

    /** إشعار حقيقي فوري لاختبار الإذن والقناة (لا يُعرض نجاح إن رفض النظام) */
    static boolean test(Context c) {
        try {
            JSONObject e = new JSONObject().put("occ", "test").put("title", "اختبار الرفيق اليومي").put("body", "إذا ظهر هذا الإشعار فالتنبيهات تعمل على هاتفك ✓");
            return postTask(c, e);
        } catch (Exception ex) { return false; }
    }
}
