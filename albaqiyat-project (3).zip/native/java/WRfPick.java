package com.albaqiyat.app;

public class WRfPick extends RafiqWidget {
    @Override
    protected String kind() { return "rpick"; }
}
