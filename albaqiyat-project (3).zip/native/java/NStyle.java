package com.albaqiyat.app;

import android.app.Notification;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.Build;
import android.os.SystemClock;
import android.util.TypedValue;
import android.view.View;
import android.widget.RemoteViews;
import org.json.JSONObject;

/**
 * «مركز تصميم الإشعارات»: يطبّق نمط الإشعار المختار (عام أو لكل صلاة) على إشعارات أندرويد الفعلية
 * عبر عروض مخصّصة (RemoteViews + DecoratedCustomViewStyle) متوافقة مع قيود النظام:
 *  • الخلفية صورة صغيرة مرسومة (تدرّج + زخرفة + إطار) — دون صور كبيرة.
 *  • العدّ التنازلي Chronometer يرسمه النظام كل ثانية دون إعادة إنشاء الإشعار.
 *  • شريط التقدّم يُحدَّث كل دقيقة فقط أثناء نافذة الأذان/الإقامة (من خلال الخدمة الأمامية القائمة أصلاً).
 * الألوان محسوبة مسبقاً في التطبيق (nstyle) فتطابق المعاينة الحيّة. النمط «system» يُبقي إشعار أندرويد القياسي.
 */
final class NStyle {
    private NStyle() {}

    /** بيانات الإشعار المشتركة */
    static final class Info {
        String kind = "";       // adhan, iqama, pre, iqcd, next, iqpre, entry, end, daily
        String prayer = "";     // fajr..isha أو فارغ
        String label = "";      // سطر صغير علوي
        String title = "";      // العنوان
        String sub = "";        // سطر ثانوي
        String center = "";     // اسم الصلاة في المنتصف (نمط الهلال)
        String t1 = "", t2 = ""; // «الأذان 12:04» و«الإقامة 12:19»
        String next = "";       // «ثم العصر 03:23»
        long target = 0;        // نهاية العدّ التنازلي (0 = بلا عدّاد)
        long from = 0;          // بداية شريط التقدّم
        String timeText = "";   // وقت ثابت يُعرض بدل العدّاد
        int progMax = 0, progVal = 0; // تقدّم بالأعداد (مهام الرفيق)
    }

    static JSONObject spec(Context c, String prayer) {
        try {
            JSONObject all = new JSONObject(AlarmScheduler.prefs(c).getString("nstyle", "{}"));
            JSONObject g = all.optJSONObject("g");
            JSONObject p = all.optJSONObject("p");
            JSONObject own = p != null && prayer != null && !prayer.isEmpty() ? p.optJSONObject(prayer) : null;
            return own != null ? own : (g != null ? g : new JSONObject());
        } catch (Exception e) { return new JSONObject(); }
    }

    static boolean enabled(Context c, String prayer) {
        JSONObject s = spec(c, prayer);
        return s.has("style") && !"system".equals(s.optString("style"));
    }

    static int col(JSONObject s, String k, int def) {
        String v = s.optString(k, "");
        try { return v.isEmpty() ? def : Color.parseColor(v); } catch (Exception e) { return def; }
    }

    /** يطبّق النمط على المُنشئ. يُرجع false إذا بقي الإشعار قياسياً */
    static boolean apply(Context c, Notification.Builder b, Info in) {
        if (Build.VERSION.SDK_INT < 24) return false;
        JSONObject s = spec(c, in.prayer);
        if (!s.has("style") || "system".equals(s.optString("style"))) return false;
        try {
            RemoteViews small = views(c, s, in, false);
            b.setCustomContentView(small);
            b.setCustomHeadsUpContentView(small);
            if (!"compact".equals(s.optString("size", "expanded"))) b.setCustomBigContentView(views(c, s, in, true));
            b.setStyle(new Notification.DecoratedCustomViewStyle());
            b.setColor(col(s, "accent", 0xFFC69A3A));
            return true;
        } catch (Throwable t) { return false; }
    }

    static float dp(Context c) { return c.getResources().getDisplayMetrics().density; }

    static RemoteViews views(Context c, JSONObject s, Info in, boolean big) {
        boolean center = big && "center".equals(s.optString("layout"));
        int lay = big ? (center ? R.layout.ntf_big_c : R.layout.ntf_big) : R.layout.ntf_small;
        RemoteViews v = new RemoteViews(c.getPackageName(), lay);
        int tx = col(s, "text", 0xFFFFFFFF), sub = col(s, "sub", 0xCCFFFFFF), ac = col(s, "accent", 0xFFD8B45A);
        float fs = (float) Math.max(.8, Math.min(1.3, s.optDouble("fs", 1)));
        boolean digital = s.optBoolean("digital", false);
        // الخلفية والأيقونة
        v.setImageViewBitmap(R.id.n_bg, bg(c, s, in, big ? 340 : 340, big ? (center ? 196 : 176) : 64));
        v.setImageViewBitmap(R.id.n_icon, icon(c, s, in, ac, big ? 46 : 34));
        // النصوص
        txt(v, R.id.n_title, in.title, tx, (big ? 16 : 14.5f) * fs, true);
        txt(v, R.id.n_sub, in.sub, sub, (big ? 12.5f : 11.5f) * fs, false);
        if (big) {
            txt(v, R.id.n_label, in.label, ac, 11 * fs, true);
            txt(v, R.id.n_t1, in.t1, tx, 12.5f * fs, true);
            txt(v, R.id.n_t2, in.t2, tx, 12.5f * fs, true);
            txt(v, R.id.n_next, in.next, sub, 11.5f * fs, false);
            if (center) txt(v, R.id.n_center, in.center.isEmpty() ? in.title : in.center, tx, 24 * fs, true);
            v.setViewVisibility(R.id.n_times, in.t1.isEmpty() && in.t2.isEmpty() ? View.GONE : View.VISIBLE);
            v.setViewVisibility(R.id.n_div, s.optBoolean("divider", false) ? View.VISIBLE : View.GONE);
            v.setInt(R.id.n_div, "setBackgroundColor", ac);
            // شريط التقدّم
            int prog = -1;
            if (in.progMax > 0) prog = Math.round(1000f * Math.min(in.progVal, in.progMax) / in.progMax);
            else if (in.target > 0 && in.from > 0 && in.target > in.from) {
                long now = System.currentTimeMillis();
                prog = (int) Math.max(0, Math.min(1000, (now - in.from) * 1000 / (in.target - in.from)));
            }
            if (prog >= 0) {
                v.setViewVisibility(R.id.n_prog, View.VISIBLE);
                v.setProgressBar(R.id.n_prog, 1000, prog, false);
                if (Build.VERSION.SDK_INT >= 31) {
                    v.setColorStateList(R.id.n_prog, "setProgressTintList", ColorStateList.valueOf(ac));
                    v.setColorStateList(R.id.n_prog, "setProgressBackgroundTintList", ColorStateList.valueOf((tx & 0xFFFFFF) | 0x33000000));
                }
            } else v.setViewVisibility(R.id.n_prog, View.GONE);
        }
        // العدّاد أو الوقت
        if (in.target > System.currentTimeMillis()) {
            v.setViewVisibility(R.id.n_cd, View.VISIBLE);
            v.setViewVisibility(R.id.n_time, View.GONE);
            v.setChronometer(R.id.n_cd, SystemClock.elapsedRealtime() + (in.target - System.currentTimeMillis()), null, true);
            v.setChronometerCountDown(R.id.n_cd, true);
            v.setTextColor(R.id.n_cd, digital ? ac : tx);
            v.setTextViewTextSize(R.id.n_cd, TypedValue.COMPLEX_UNIT_SP, (big ? (center ? 26 : 22) : 17) * fs);
        } else {
            v.setViewVisibility(R.id.n_cd, View.GONE);
            v.setViewVisibility(R.id.n_time, in.timeText.isEmpty() ? View.GONE : View.VISIBLE);
            txt(v, R.id.n_time, in.timeText, digital ? ac : tx, (big ? 20 : 16) * fs, true);
        }
        return v;
    }

    static void txt(RemoteViews v, int id, String s, int color, float sp, boolean bold) {
        if (s == null || s.isEmpty()) { v.setViewVisibility(id, View.GONE); return; }
        v.setViewVisibility(id, View.VISIBLE);
        v.setTextViewText(id, s);
        v.setTextColor(id, color);
        v.setTextViewTextSize(id, TypedValue.COMPLEX_UNIT_SP, sp);
    }

    // ── رسم الخلفية ──
    static Bitmap bg(Context c, JSONObject s, Info in, int wdp, int hdp) {
        float d = Math.min(1.25f, dp(c));
        int w = Math.round(wdp * d), h = Math.round(hdp * d);
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        Path clip = new Path(); clip.addRoundRect(new RectF(0, 0, w, h), 12 * d, 12 * d, Path.Direction.CW);
        cv.clipPath(clip);
        int c1 = col(s, "bg1", 0xFF0F5132), c2 = col(s, "bg2", 0xFF0B3A27), ac = col(s, "accent", 0xFFD8B45A);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new LinearGradient(0, 0, w, h, c1, c2, Shader.TileMode.CLAMP));
        cv.drawRect(0, 0, w, h, p);
        p.setShader(null);
        String st = s.optString("style");
        boolean orn = s.optBoolean("orn", true);
        int oc = col(s, "orn", (ac & 0xFFFFFF) | 0x2E000000);
        if (orn) ornament(cv, w, h, d, s.optString("pattern", "star"), oc);
        if ("glass".equals(st)) {
            Paint g = new Paint(Paint.ANTI_ALIAS_FLAG);
            g.setShader(new LinearGradient(0, 0, 0, h * .6f, 0x33FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
            cv.drawRect(0, 0, w, h, g);
            // توهّج أخضر خلف الأيقونة (يمين، اتجاه RTL)
            g.setShader(new RadialGradient(w - 36 * d, h / 2f, 46 * d, (ac & 0xFFFFFF) | 0x66000000, ac & 0xFFFFFF, Shader.TileMode.CLAMP));
            cv.drawRect(0, 0, w, h, g);
        }
        if ("crescent".equals(st)) { // قوس محراب خفيف في الخلفية
            Paint a = new Paint(Paint.ANTI_ALIAS_FLAG);
            a.setStyle(Paint.Style.STROKE); a.setStrokeWidth(1.4f * d); a.setColor((ac & 0xFFFFFF) | 0x40000000);
            float cx = w / 2f, top = h * .08f, bw = Math.min(w * .42f, h * 1.1f);
            Path m = new Path();
            m.moveTo(cx - bw / 2, h); m.lineTo(cx - bw / 2, h * .5f);
            m.cubicTo(cx - bw / 2, h * .22f, cx - bw * .12f, top + h * .08f, cx, top);
            m.cubicTo(cx + bw * .12f, top + h * .08f, cx + bw / 2, h * .22f, cx + bw / 2, h * .5f);
            m.lineTo(cx + bw / 2, h);
            cv.drawPath(m, a);
        }
        if (s.optBoolean("frame", false)) {
            Paint f = new Paint(Paint.ANTI_ALIAS_FLAG);
            f.setStyle(Paint.Style.STROKE); f.setColor(ac); f.setStrokeWidth(1.6f * d);
            float i1 = 4 * d;
            cv.drawRoundRect(new RectF(i1, i1, w - i1, h - i1), 10 * d, 10 * d, f);
            if ("royal".equals(st)) {
                f.setStrokeWidth(.8f * d); f.setColor((ac & 0xFFFFFF) | 0x99000000);
                float i2 = 8 * d;
                cv.drawRoundRect(new RectF(i2, i2, w - i2, h - i2), 7 * d, 7 * d, f);
                // ركنيات ذهبية
                Paint k = new Paint(Paint.ANTI_ALIAS_FLAG); k.setColor(ac);
                for (float[] q : new float[][]{{i1, i1}, {w - i1, i1}, {i1, h - i1}, {w - i1, h - i1}}) star(cv, q[0], q[1], 4 * d, 2 * d, k);
            }
        }
        return b;
    }

    static void star(Canvas cv, float cx, float cy, float R, float r, Paint p) {
        Path s = new Path();
        for (int i = 0; i < 16; i++) { double a = Math.PI * i / 8 - Math.PI / 2; float rr = i % 2 == 0 ? R : r; float x = cx + (float) Math.cos(a) * rr, y = cy + (float) Math.sin(a) * rr; if (i == 0) s.moveTo(x, y); else s.lineTo(x, y); }
        s.close(); cv.drawPath(s, p);
    }

    static void ornament(Canvas cv, int w, int h, float d, String pat, int col) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(Math.max(1f, .9f * d)); p.setColor(col);
        float st = 26 * d;
        if ("lattice".equals(pat)) { for (float x = -h; x < w + h; x += st * .8f) { cv.drawLine(x, 0, x + h, h, p); cv.drawLine(x + h, 0, x, h, p); } return; }
        if ("dots".equals(pat)) { p.setStyle(Paint.Style.FILL); for (float y = st / 2; y < h; y += st / 1.6f) for (float x = st / 2; x < w; x += st / 1.6f) cv.drawCircle(x, y, 1.1f * d, p); return; }
        if ("arabesque".equals(pat)) { for (float y = 0; y <= h + st; y += st) for (float x = 0; x <= w + st; x += st) cv.drawCircle(x, y, st * .55f, p); return; }
        // نجمة ثمانية متكررة (افتراضي)
        for (float y = 0; y <= h + st; y += st * 1.2f) for (float x = ((int) (y / (st * 1.2f)) % 2) * st * .6f; x <= w + st; x += st * 1.2f) {
            Path s = new Path();
            for (int i = 0; i < 16; i++) { double a = Math.PI * i / 8; float rr = i % 2 == 0 ? st * .42f : st * .3f; float px = x + (float) Math.cos(a) * rr, py = y + (float) Math.sin(a) * rr; if (i == 0) s.moveTo(px, py); else s.lineTo(px, py); }
            s.close(); cv.drawPath(s, p);
        }
    }

    // ── الأيقونة ──
    static Bitmap icon(Context c, JSONObject s, Info in, int ac, int sdp) {
        float d = Math.min(2f, dp(c));
        int sz = Math.round(sdp * d);
        Bitmap b = Bitmap.createBitmap(sz, sz, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        String st = s.optString("style");
        int ic = col(s, "icon", ac);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        // خلفية دائرية أو مثمّنة للأيقونة
        int ib = col(s, "iconBg", 0);
        if (ib != 0) {
            p.setColor(ib);
            if ("geo".equals(st) || "royal".equals(st)) star(cv, sz / 2f, sz / 2f, sz * .5f, sz * .44f, p);
            else cv.drawCircle(sz / 2f, sz / 2f, sz * .48f, p);
        }
        if ("glass".equals(st)) { // إضاءة خضراء خفيفة
            Paint g = new Paint(Paint.ANTI_ALIAS_FLAG); g.setColor((ic & 0xFFFFFF) | 0x55000000);
            g.setMaskFilter(new BlurMaskFilter(sz * .18f, BlurMaskFilter.Blur.NORMAL));
            cv.drawCircle(sz / 2f, sz / 2f, sz * .3f, g);
        }
        String kind = s.optString("iconKind", "prayer");
        float u = sz / 24f * .78f;
        cv.save();
        cv.translate(sz / 2f - 12 * u, sz / 2f - 12 * u);
        if ("prayer".equals(kind) && !in.prayer.isEmpty()) WidgetArt.drawIcon(cv, in.prayer, u, ic, false, 1.8f * u);
        else {
            String d0 = ICONS.containsKey(kind) ? ICONS.get(kind) : ICONS.get("crescent");
            Path ip = MyRender.svgPath(d0);
            if (ip != null) {
                android.graphics.Matrix mx = new android.graphics.Matrix(); mx.setScale(u, u); ip.transform(mx);
                Paint sp = new Paint(Paint.ANTI_ALIAS_FLAG); sp.setStyle(Paint.Style.STROKE); sp.setStrokeWidth(1.8f * u);
                sp.setStrokeCap(Paint.Cap.ROUND); sp.setStrokeJoin(Paint.Join.ROUND); sp.setColor(ic);
                if ("crescent".equals(kind)) { sp.setStyle(Paint.Style.FILL); }
                cv.drawPath(ip, sp);
            }
        }
        cv.restore();
        return b;
    }

    static final java.util.HashMap<String, String> ICONS = new java.util.HashMap<>();
    static {
        ICONS.put("crescent", "M15.5 4.2a8 8 0 1 0 4.3 12.8A7 7 0 0 1 15.5 4.2z");
        ICONS.put("mosque", "M5 21v-8h14v8M7 13a5 5 0 0 1 10 0M2 21h20M10.5 21v-3a1.5 1.5 0 0 1 3 0v3M12 4v4M20 21V9M19 9h2l-1-2z");
        ICONS.put("star", "M12 2.5l2.4 3.2 3.9-.8-.8 3.9 3.2 2.4-3.2 2.4.8 3.9-3.9-.8-2.4 3.2-2.4-3.2-3.9.8.8-3.9L3.3 11.2l3.2-2.4-.8-3.9 3.9.8z");
        ICONS.put("lantern", "M9 3h6M10 3v2h4V3M8 5h8l1 4-1 9H8L7 9zM9 18v2h6v-2M12 9v6");
        ICONS.put("bell", "M6 16V11a6 6 0 0 1 12 0v5l2 2H4zM10 20a2 2 0 0 0 4 0");
        ICONS.put("kaaba", "M4 8l8-4 8 4v10l-8 4-8-4zM4 8l8 4 8-4M12 12v10M4 11l8 4 8-4");
    }

    static String label(String kind) {
        switch (kind) {
            case "adhan": return "حان وقت الأذان";
            case "iqama": return "حان وقت الإقامة";
            case "pre": return "اقترب وقت الأذان";
            case "iqpre": return "اقتربت الإقامة";
            case "iqcd": return "العدّ التنازلي للإقامة";
            case "next": return "الصلاة القادمة";
            case "end": return "اقتراب خروج الوقت";
            case "entry": return "دخل وقت الصلاة";
            case "daily": return "تذكير يومي";
        }
        return "";
    }

    /** يملأ أوقات الأذان والإقامة والصلاة التالية من بيانات الويدجت (تعمل دون إنترنت) */
    static void fillTimes(Context c, Info in, String prayer) {
        try {
            WidgetModel m = WidgetModel.load(c);
            if (!m.ok) return;
            JSONObject o = null, after = null;
            if (m.cur != null && prayer.equals(m.cur.optString("k"))) { o = m.cur; after = m.next; }
            else if (m.next != null && prayer.equals(m.next.optString("k"))) { o = m.next; after = m.after; }
            if (o == null) return;
            in.t1 = "الأذان  " + o.optString("s", "");
            if (o.has("iqs") && !o.optString("iqs").isEmpty()) in.t2 = "الإقامة  " + o.optString("iqs");
            if (after != null) in.next = "ثم " + after.optString("name", "") + "  " + after.optString("s", "");
        } catch (Exception ignored) {}
    }

    /** بيانات إشعار منبّه (أذان/إقامة/قبل الأذان/اقتراب الإقامة/خروج الوقت/دخول الوقت) */
    static Info fromEvent(Context c, JSONObject ev, String kind) {
        Info in = new Info();
        in.kind = kind;
        in.prayer = ev.optString("prayer", "");
        in.label = label(kind);
        in.title = ev.optString("title", "");
        in.center = ev.optString("name", "");
        in.sub = ev.optString("body", "");
        if (in.sub.isEmpty()) in.sub = ev.optString("city", "");
        fillTimes(c, in, in.prayer);
        long now = System.currentTimeMillis();
        if ("pre".equals(kind)) { long at = ev.optLong("adhanAt", 0); if (at > now) { in.target = at; in.from = ev.optLong("at", now); } }
        else if ("iqpre".equals(kind) || "adhan".equals(kind)) { long iq = ev.optLong("iqAt", 0); if (iq > now) { in.target = iq; in.from = "adhan".equals(kind) ? ev.optLong("at", now) : ev.optLong("adhanAt", ev.optLong("at", now)); } }
        if (in.target == 0) in.timeText = ev.optString("time", "");
        return in;
    }

    /** بيانات جاهزة من التطبيق (الإشعار التجريبي) */
    static Info fromJson(JSONObject o) {
        Info in = new Info();
        in.kind = o.optString("kind"); in.prayer = o.optString("prayer"); in.label = o.optString("label", label(in.kind));
        in.title = o.optString("title"); in.sub = o.optString("sub"); in.center = o.optString("name");
        in.t1 = o.optString("t1"); in.t2 = o.optString("t2"); in.next = o.optString("next");
        in.target = o.optLong("target", 0); in.from = o.optLong("from", 0); in.timeText = o.optString("time");
        in.progMax = o.optInt("progMax", 0); in.progVal = o.optInt("progVal", 0);
        return in;
    }

    /** الإشعار الذكي من نموذج الويدجت */
    static Info fromModel(Context c, WidgetModel m, String kind) {
        Info in = new Info();
        in.kind = kind;
        JSONObject o = "iqcd".equals(kind) ? m.cur : m.next;
        if (o == null) return in;
        in.prayer = o.optString("k", "");
        String nm = o.optString("name", "");
        in.center = nm;
        in.label = label(kind);
        if ("iqcd".equals(kind)) { in.title = "الإقامة بعد — صلاة " + nm; in.target = o.optLong("iq"); in.from = o.optLong("at"); }
        else if ("pre".equals(kind)) { in.title = "الأذان بعد — صلاة " + nm; in.target = o.optLong("at"); in.from = in.target - StatusNotice.PRE; }
        else { in.title = "صلاة " + nm + "  " + o.optString("s", ""); in.target = o.optLong("at"); in.from = m.fromAt; }
        in.sub = m.city;
        fillTimes(c, in, in.prayer);
        return in;
    }
}
