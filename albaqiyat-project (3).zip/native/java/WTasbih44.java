package com.albaqiyat.app;

public class WTasbih44 extends TasbihWidget {
    @Override
    protected String kind() { return "tb44"; }
}
