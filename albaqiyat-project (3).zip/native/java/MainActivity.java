package com.albaqiyat.app;

import android.content.SharedPreferences;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.ViewGroup;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebView;
import com.getcapacitor.BridgeActivity;
import com.getcapacitor.BridgeWebViewClient;

public class MainActivity extends BridgeActivity {
    private static final int BG = 0xFF0F5132;
    private final Handler h = new Handler(Looper.getMainLooper());
    private long pausedAt = 0;
    private boolean recreating = false;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(AdhanPlugin.class);
        super.onCreate(savedInstanceState);
        keepRoute(getIntent());
        // لون خلفية التطبيق بدل الأبيض أثناء التحميل أو إعادة الرسم
        try { getWindow().setBackgroundDrawable(new ColorDrawable(BG)); } catch (Exception ignored) {}
        try { if (getBridge() != null && getBridge().getWebView() != null) getBridge().getWebView().setBackgroundColor(BG); } catch (Exception ignored) {}
        // إذا أنهى النظام عملية عرض الصفحة في الخلفية (لتوفير الذاكرة) تُعاد الشاشة تلقائياً بدل الصفحة البيضاء
        try {
            if (getBridge() != null) {
                getBridge().setWebViewClient(new BridgeWebViewClient(getBridge()) {
                    @Override
                    public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                        try {
                            ViewGroup parent = (ViewGroup) view.getParent();
                            if (parent != null) parent.removeView(view);
                            view.destroy();
                        } catch (Exception ignored) {}
                        restart();
                        return true;
                    }
                });
            }
        } catch (Exception ignored) {}
        // عند تثبيت نسخة جديدة من التطبيق: مسح أي نسخة قديمة محفوظة من الواجهة حتى تظهر التعديلات فوراً
        try {
            long installed = getPackageManager().getPackageInfo(getPackageName(), 0).lastUpdateTime;
            SharedPreferences p = getSharedPreferences("app_meta", MODE_PRIVATE);
            if (p.getLong("last_update", 0) != installed) {
                p.edit().putLong("last_update", installed).apply();
                if (getBridge() != null && getBridge().getWebView() != null) {
                    getBridge().getWebView().clearCache(true);
                    getBridge().getWebView().reload();
                }
            }
        } catch (Exception ignored) {}
    }

    /** مسار مرسل من ويدجت (route) يحفظ ليقرأه التطبيق عند الجاهزية */
    private void keepRoute(android.content.Intent i) {
        try {
            String r = i == null ? null : i.getStringExtra("route");
            if (r != null && !r.isEmpty()) getSharedPreferences("app_meta", MODE_PRIVATE).edit().putString("route", r).commit();
        } catch (Exception ignored) {}
    }

    @Override
    protected void onNewIntent(android.content.Intent intent) {
        super.onNewIntent(intent);
        keepRoute(intent);
        try { if (getBridge() != null) getBridge().getWebView().evaluateJavascript("window.__takeRoute&&window.__takeRoute()", null); } catch (Exception ignored) {}
    }

    private void restart() {
        if (recreating) return;
        recreating = true;
        h.post(new Runnable() { public void run() { recreate(); } });
    }

    @Override
    public void onPause() {
        super.onPause();
        pausedAt = System.currentTimeMillis();
    }

    /** عند الرجوع إلى التطبيق: إعادة رسم الصفحة، ثم فحص أنها حيّة وغير فارغة؛ وإلا تُعاد تحميلها */
    @Override
    public void onResume() {
        super.onResume();
        if (pausedAt == 0) return;
        final WebView wv = getBridge() != null ? getBridge().getWebView() : null;
        if (wv == null) return;
        try { wv.setBackgroundColor(BG); wv.invalidate(); wv.requestLayout(); } catch (Exception ignored) {}
        final boolean[] answered = {false};
        h.postDelayed(new Runnable() { public void run() {
            try {
                wv.evaluateJavascript("(window.__alive&&window.__alive())||'none'", new android.webkit.ValueCallback<String>() {
                    public void onReceiveValue(String v) {
                        answered[0] = true;
                        if (v == null || v.contains("empty") || v.contains("none") || "null".equals(v)) safeReload(wv);
                    }
                });
            } catch (Exception e) { safeReload(wv); }
        }}, 900);
        // الصفحة لا تستجيب (عملية العرض معلّقة): إعادة تحميل
        h.postDelayed(new Runnable() { public void run() { if (!answered[0]) safeReload(wv); } }, 5000);
    }

    private void safeReload(WebView wv) {
        try { wv.reload(); } catch (Exception e) { restart(); }
    }

    @Override
    public void onDestroy() {
        h.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
