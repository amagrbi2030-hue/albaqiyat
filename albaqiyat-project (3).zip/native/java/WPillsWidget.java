package com.albaqiyat.app;

public class WPillsWidget extends BaseWidget {
    @Override
    protected String kind() { return "pills"; }
}
