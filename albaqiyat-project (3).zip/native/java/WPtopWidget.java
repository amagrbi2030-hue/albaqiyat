package com.albaqiyat.app;

public class WPtopWidget extends BaseWidget {
    @Override
    protected String kind() { return "ptop"; }
}
