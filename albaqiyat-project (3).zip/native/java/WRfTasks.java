package com.albaqiyat.app;

public class WRfTasks extends RafiqWidget {
    @Override
    protected String kind() { return "rtasks"; }
}
