package com.albaqiyat.app;

import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.Bundle;

/** رسم خلفيات الودجت بألوان الثيم: تدرّج + زخرفة نجوم ثمانية شبه شفافة + هلال ذهبي رقيق */
public class WidgetArt {
    public static final int THEME = 0, GLASS = 1, SKY = 2, MINIMAL = 3, PHASE = 4, MIHRAB = 5, ROYAL = 6, SUN = 7;

    static int alpha(int c, int a) { return (c & 0x00FFFFFF) | (a << 24); }

    static int mix(int a, int b, float t) {
        int r = (int) (Color.red(a) + (Color.red(b) - Color.red(a)) * t);
        int g = (int) (Color.green(a) + (Color.green(b) - Color.green(a)) * t);
        int bl = (int) (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t);
        return Color.rgb(r, g, bl);
    }

    /** شفافية الخلفية حسب النمط: كلاسيكي (معتم) / زجاجي (شبه شفاف) / شفاف */
    static int lookAlpha(WidgetModel m) {
        if (m == null) return 0xFF;
        if ("glass".equals(m.look)) return 0xA6;
        if ("clear".equals(m.look)) return 0x48;
        return 0xFF;
    }

    static boolean classic(WidgetModel m) { return m == null || !( "glass".equals(m.look) || "clear".equals(m.look)); }

    /** تدرّج الألوان المختارة من المكتبة (لونان أو أكثر) — أو التدرّج الافتراضي */
    static Shader gradShader(WidgetModel m, float w, float h, Shader def, float darken) {
        if (m != null && m.grad != null && m.grad.length >= 2) {
            int[] g = new int[m.grad.length];
            for (int i = 0; i < g.length; i++) g[i] = darken > 0 ? mix(m.grad[i], 0xFF0A0C10, darken) : m.grad[i];
            return new LinearGradient(w, 0, 0, h, g, null, Shader.TileMode.CLAMP); // من أعلى اليمين (عربي)
        }
        return def;
    }

    /** يرسم الخلفية بالتظليل المعطى مع شفافية النمط */
    static void fillBase(Canvas cv, RectF rect, Paint p, WidgetModel m) {
        p.setAlpha(lookAlpha(m));
        cv.drawRect(rect, p);
        p.setAlpha(0xFF);
    }

    /** لمسات النمط الأخيرة: لمعة وإطار أبيض للزجاجي، إطار رقيق للشفاف */
    static void finishLook(Canvas cv, int w, int h, float rad, float k, WidgetModel m) {
        if (classic(m)) return;
        boolean glass = "glass".equals(m.look);
        if (glass) {
            Paint hi = new Paint(Paint.ANTI_ALIAS_FLAG);
            hi.setShader(new LinearGradient(0, 0, 0, h * 0.5f, 0x3AFFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
            cv.drawRect(0, 0, w, h, hi);
            Paint sh = new Paint(Paint.ANTI_ALIAS_FLAG);
            sh.setShader(new LinearGradient(w * 0.25f, 0, w * 0.6f, h, new int[]{0x00FFFFFF, 0x1CFFFFFF, 0x00FFFFFF}, new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
            cv.drawRect(0, 0, w, h, sh);
        }
        Paint bp = new Paint(Paint.ANTI_ALIAS_FLAG);
        bp.setStyle(Paint.Style.STROKE);
        bp.setStrokeWidth(Math.max(1f, (glass ? 1.4f : 1.1f) * k));
        bp.setColor(glass ? 0x8CFFFFFF : 0x66FFFFFF);
        float ins = bp.getStrokeWidth() / 2;
        cv.drawRoundRect(new RectF(ins, ins, w - ins, h - ins), rad - ins, rad - ins, bp);
    }

    static int[] sky(String k) {
        if ("fajr".equals(k)) return new int[]{0xFF1B2350, 0xFF6A4C7E};
        if ("dhuhr".equals(k)) return new int[]{0xFF1F5C8A, 0xFF4F8DB8};
        if ("asr".equals(k)) return new int[]{0xFF7A5222, 0xFFB98838};
        if ("maghrib".equals(k)) return new int[]{0xFF3A1E4A, 0xFFB0543C};
        return new int[]{0xFF07122A, 0xFF16304F};
    }

    /** زخرفة الخلفية حسب الاختيار: نجوم ثمانية، شبكة هندسية، دوائر متداخلة، أهلّة ونجوم، نقاط، أو بدون */
    static void ornament(Canvas cv, int w, int h, float k, WidgetModel m, int col, float stepDp) {
        String o = m == null ? "star" : m.orn;
        if ("none".equals(o)) return;
        Paint sp = new Paint(Paint.ANTI_ALIAS_FLAG);
        sp.setStyle(Paint.Style.STROKE);
        sp.setStrokeWidth(Math.max(1f, 1.05f * k));
        sp.setColor(col);
        float step = stepDp * k;
        if ("lattice".equals(o)) {
            for (float x = -h; x < w + h; x += step * 0.7f) { cv.drawLine(x, 0, x + h, h, sp); cv.drawLine(x + h, 0, x, h, sp); }
            return;
        }
        if ("circles".equals(o)) {
            float r = step * 0.5f;
            for (float y = 0; y < h + r; y += r) for (float x = 0; x < w + r; x += r) cv.drawCircle(x, y, r, sp);
            return;
        }
        if ("dots".equals(o)) {
            Paint dp = new Paint(Paint.ANTI_ALIAS_FLAG);
            dp.setColor(col);
            float s2 = step * 0.45f;
            for (float y = s2 / 2; y < h; y += s2) for (float x = s2 / 2; x < w; x += s2) cv.drawCircle(x, y, 1.3f * k, dp);
            return;
        }
        if ("crescent".equals(o)) {
            Paint fp = new Paint(Paint.ANTI_ALIAS_FLAG);
            fp.setColor(col);
            java.util.Random rnd = new java.util.Random(11);
            int n = (int) Math.max(8, (w * h) / (step * step) * 0.9f);
            for (int i = 0; i < n; i++) {
                float x = rnd.nextFloat() * w, y = rnd.nextFloat() * h, R = (4 + rnd.nextFloat() * 7) * k;
                if (i % 3 == 0) {
                    Path a = new Path(); a.addCircle(x, y, R, Path.Direction.CW);
                    Path b = new Path(); b.addCircle(x + R * 0.45f, y - R * 0.2f, R * 0.9f, Path.Direction.CW);
                    a.op(b, Path.Op.DIFFERENCE);
                    cv.drawPath(a, fp);
                } else cv.drawPath(star8(x, y, R * 0.55f), fp);
            }
            return;
        }
        for (float y = -step / 2; y < h + step; y += step)
            for (float x = (((int) (y / step)) % 2 == 0 ? 0 : step / 2); x < w + step; x += step)
                cv.drawPath(star8(x, y, step * 0.36f), sp);
    }

    static Path star8(float cx, float cy, float R) {
        Path p = new Path();
        float r = R * 0.72f;
        for (int i = 0; i < 16; i++) {
            double a = Math.PI / 8 * i - Math.PI / 2;
            float rad = i % 2 == 0 ? R : r;
            float x = (float) (cx + rad * Math.cos(a)), y = (float) (cy + rad * Math.sin(a));
            if (i == 0) p.moveTo(x, y); else p.lineTo(x, y);
        }
        p.close();
        return p;
    }

    static int[] phaseSky(String p) {
        if ("fajr".equals(p)) return new int[]{0xFF1B2452, 0xFF5B4A86, 0xFFD99A8C};
        if ("morning".equals(p)) return new int[]{0xFF3D7EC2, 0xFF7FB6E3, 0xFFF4D9A0};
        if ("dhuhr".equals(p)) return new int[]{0xFF1E6FB8, 0xFF4FA3DE, 0xFFA8D8F2};
        if ("sunset".equals(p)) return new int[]{0xFF3B2150, 0xFFB4513E, 0xFFF2A65A};
        return new int[]{0xFF050A1C, 0xFF0D1E3D, 0xFF1C3358};
    }

    /** خلفيات الويدجت الجديدة: سماء حسب الوقت، محراب، ملكي، شمس */
    public static Bitmap bg2(Context c, Bundle opts, int defWdp, int defHdp, int style, WidgetModel m) {
        float d = c.getResources().getDisplayMetrics().density;
        int wdp = 0, hdp = 0;
        if (opts != null) {
            wdp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0);
            hdp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0);
        }
        if (wdp <= 0) wdp = defWdp;
        if (hdp <= 0) hdp = defHdp;
        float scale = Math.min(1f, 900f / (Math.max(wdp, hdp) * d));
        float k = d * scale;
        int w = Math.max(40, (int) (wdp * k)), h = Math.max(40, (int) (hdp * k));
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        float rad = (m.sk ? m.radius : 24) * k;
        RectF rect = m.sk ? WSkinArt.inner(w, h, k, m) : new RectF(0, 0, w, h);
        if (m.sk) WSkinArt.outerShadow(cv, rect, rad, k, m);
        Path clip = new Path();
        clip.addRoundRect(rect, rad, rad, Path.Direction.CW);
        cv.clipPath(clip);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        int gold = m.gold;
        boolean night = "night".equals(m.phase);

        if (m.sk) {
            boolean skyOn = (style == PHASE || style == SUN) && m.timeSky;
            WSkinArt.paint(cv, rect, k, m, skyOn ? phaseSky(m.phase) : null);
            gold = m.accent;
            if (skyOn && night) {
                Paint st = new Paint(Paint.ANTI_ALIAS_FLAG);
                java.util.Random rnd = new java.util.Random(7);
                for (int i = 0; i < 46; i++) {
                    st.setColor(alpha(0xFFFFFFFF, 60 + rnd.nextInt(140)));
                    cv.drawCircle(rnd.nextFloat() * w, rnd.nextFloat() * h * 0.75f, (0.6f + rnd.nextFloat() * 1.3f) * k, st);
                }
            }
        } else if (style == PHASE || style == SUN) {
            int[] sk = phaseSky(m.phase);
            p.setShader(new LinearGradient(0, 0, 0, h, sk, null, Shader.TileMode.CLAMP));
            fillBase(cv, rect, p, m);
            if (night) {
                Paint st = new Paint(Paint.ANTI_ALIAS_FLAG);
                java.util.Random rnd = new java.util.Random(7);
                for (int i = 0; i < 46; i++) {
                    st.setColor(alpha(0xFFFFFFFF, 60 + rnd.nextInt(140)));
                    cv.drawCircle(rnd.nextFloat() * w, rnd.nextFloat() * h * 0.75f, (0.6f + rnd.nextFloat() * 1.3f) * k, st);
                }
            }
        } else if (style == ROYAL) {
            if (m.grad != null) p.setShader(gradShader(m, w, h, null, 0f));
            else if (m.custom) p.setShader(new LinearGradient(0, 0, w, h, new int[]{mix(m.c2, 0xFF000000, 0.35f), m.c2, m.c1}, null, Shader.TileMode.CLAMP));
            else { p.setShader(new LinearGradient(0, 0, w, h, new int[]{0xFF06281B, 0xFF0B3A27, 0xFF125536}, null, Shader.TileMode.CLAMP)); gold = 0xFFD8B45A; }
            fillBase(cv, rect, p, m);
        } else { // MIHRAB
            p.setShader(gradShader(m, w, h, new LinearGradient(0, 0, w, h, mix(m.c2, 0xFF000000, 0.25f), m.c1, Shader.TileMode.CLAMP), 0f));
            fillBase(cv, rect, p, m);
        }

        // زخرفة نجوم ثمانية خافتة
        if (!m.sk) {
        if (style == ROYAL || style == MIHRAB) ornament(cv, w, h, k, m, alpha(gold, 0x1A), 40);
        else if (!"star".equals(m.orn)) ornament(cv, w, h, k, m, alpha(0xFFFFFFFF, 0x12), 46);
        // توهّج
        Paint g = new Paint(Paint.ANTI_ALIAS_FLAG);
        g.setShader(new RadialGradient(w * 0.5f, h * 0.42f, Math.max(w, h) * 0.55f, alpha(night ? 0xFFFFFFFF : gold, night ? 0x10 : 0x2A), 0, Shader.TileMode.CLAMP));
        cv.drawRect(rect, g);
        }

        if (style == MIHRAB) {
            // قوس المحراب المزدوج
            Paint ap = new Paint(Paint.ANTI_ALIAS_FLAG);
            ap.setStyle(Paint.Style.STROKE);
            ap.setStrokeWidth(Math.max(1.2f, 1.6f * k));
            ap.setColor(alpha(gold, 0xB0));
            for (int j = 0; j < 2; j++) {
                float in = (12 + j * 9) * k;
                float top = (20 + j * 9) * k;
                Path a = new Path();
                a.moveTo(in, h - in);
                a.lineTo(in, h * 0.42f);
                a.cubicTo(in, h * 0.2f, w * 0.38f, top + h * 0.06f, w / 2f, top);
                a.cubicTo(w * 0.62f, top + h * 0.06f, w - in, h * 0.2f, w - in, h * 0.42f);
                a.lineTo(w - in, h - in);
                if (j == 1) ap.setColor(alpha(gold, 0x55));
                cv.drawPath(a, ap);
            }
            Paint sf = new Paint(Paint.ANTI_ALIAS_FLAG);
            sf.setColor(alpha(gold, 0xC0));
            cv.drawPath(star8(w / 2f, 12 * k, 6 * k), sf);
        }

        if (style == ROYAL) {
            // هلال في الزاوية + إطار مزدوج
            float R = Math.min(w, h) * 0.13f;
            float cx = w - R * 1.6f, cy = R * 1.6f;
            Path a = new Path(); a.addCircle(cx, cy, R, Path.Direction.CW);
            Path bb = new Path(); bb.addCircle(cx - R * 0.42f, cy - R * 0.2f, R * 0.88f, Path.Direction.CW);
            a.op(bb, Path.Op.DIFFERENCE);
            Paint cp = new Paint(Paint.ANTI_ALIAS_FLAG);
            cp.setColor(alpha(gold, 0x99));
            cv.drawPath(a, cp);
            Paint ip = new Paint(Paint.ANTI_ALIAS_FLAG);
            ip.setStyle(Paint.Style.STROKE);
            ip.setStrokeWidth(Math.max(1f, 0.8f * k));
            ip.setColor(alpha(gold, 0x55));
            float ins2 = 7 * k;
            cv.drawRoundRect(new RectF(ins2, ins2, w - ins2, h - ins2), rad - ins2, rad - ins2, ip);
        }

        if (style == SUN) {
            // قوس الشمس من الشروق إلى الغروب
            float ax = 22 * k, ay = h * 0.62f, aw = w - 2 * ax, ah = h * 0.42f;
            RectF arc = new RectF(ax, ay - ah, ax + aw, ay + ah);
            Paint ap = new Paint(Paint.ANTI_ALIAS_FLAG);
            ap.setStyle(Paint.Style.STROKE);
            ap.setStrokeWidth(Math.max(1.2f, 1.5f * k));
            ap.setColor(alpha(0xFFFFFFFF, 0x66));
            ap.setPathEffect(new android.graphics.DashPathEffect(new float[]{5 * k, 5 * k}, 0));
            cv.drawArc(arc, 180, 180, false, ap);
            Paint hz = new Paint(Paint.ANTI_ALIAS_FLAG);
            hz.setColor(alpha(gold, 0x88));
            hz.setStrokeWidth(Math.max(1f, 1f * k));
            cv.drawLine(ax - 8 * k, ay, ax + aw + 8 * k, ay, hz);
            long now = System.currentTimeMillis();
            float f;
            boolean day = m.sunrise > 0 && m.sunset > m.sunrise && now >= m.sunrise && now <= m.sunset;
            if (day) f = (now - m.sunrise) / (float) (m.sunset - m.sunrise);
            else f = 0.5f;
            double ang = Math.PI * (1 - f); // من اليسار إلى اليمين
            float sx = (float) (ax + aw / 2 + Math.cos(ang) * aw / 2);
            float sy = (float) (ay - Math.sin(ang) * ah);
            Paint sun = new Paint(Paint.ANTI_ALIAS_FLAG);
            if (day) {
                sun.setShader(new RadialGradient(sx, sy, 22 * k, new int[]{0xFFFFF4C2, 0xFFF6C447, 0x00F6C447}, new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP));
                cv.drawCircle(sx, sy, 22 * k, sun);
            } else {
                Path mo = new Path(); mo.addCircle(sx, sy, 10 * k, Path.Direction.CW);
                Path cut = new Path(); cut.addCircle(sx + 5 * k, sy - 3 * k, 9 * k, Path.Direction.CW);
                mo.op(cut, Path.Op.DIFFERENCE);
                sun.setColor(0xFFF3E7B8);
                cv.drawPath(mo, sun);
            }
        }

        Paint bp = new Paint(Paint.ANTI_ALIAS_FLAG);
        bp.setStyle(Paint.Style.STROKE);
        bp.setStrokeWidth(Math.max(1f, 1.2f * k));
        bp.setColor(alpha(gold, style == PHASE || style == SUN ? 0x55 : 0x99));
        float ins = bp.getStrokeWidth() / 2;
        if (m.sk) WSkinArt.frame(cv, rect, k, m);
        else {
            if (classic(m)) cv.drawRoundRect(new RectF(ins, ins, w - ins, h - ins), rad - ins, rad - ins, bp);
            finishLook(cv, w, h, rad, k, m);
        }
        return b;
    }

    public static Bitmap bg(Context c, Bundle opts, int defWdp, int defHdp, int style, WidgetModel m, String skyKey, boolean crescent) {
        float d = c.getResources().getDisplayMetrics().density;
        int wdp = 0, hdp = 0;
        if (opts != null) {
            wdp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0);
            hdp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0);
        }
        if (wdp <= 0) wdp = defWdp;
        if (hdp <= 0) hdp = defHdp;
        float scale = Math.min(1f, 900f / (Math.max(wdp, hdp) * d));
        float k = d * scale;
        int w = Math.max(40, (int) (wdp * k)), h = Math.max(40, (int) (hdp * k));
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        float rad = (m.sk ? m.radius : 24) * k;
        RectF rect = m.sk ? WSkinArt.inner(w, h, k, m) : new RectF(0, 0, w, h);
        if (m.sk) WSkinArt.outerShadow(cv, rect, rad, k, m);
        Path clip = new Path();
        clip.addRoundRect(rect, rad, rad, Path.Direction.CW);
        cv.clipPath(clip);

        int c1, c2;
        if (style == GLASS) { c1 = alpha(mix(m.c2, 0xFF000000, 0.35f), 0xC8); c2 = alpha(mix(m.c1, 0xFF000000, 0.2f), 0xB0); }
        else if (style == SKY) { int[] s = sky(skyKey); c1 = s[0]; c2 = s[1]; }
        else if (style == MINIMAL) { c1 = m.c1; c2 = mix(m.c1, m.c2, 0.6f); }
        else { c1 = mix(m.c2, 0xFF000000, 0.15f); c2 = m.c1; }
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Shader def = new LinearGradient(0, 0, w, h, c1, c2, Shader.TileMode.CLAMP);
        if (m.sk) WSkinArt.paint(cv, rect, k, m, style == SKY && m.timeSky ? sky(skyKey) : null);
        else {
        p.setShader(style == SKY ? def : gradShader(m, w, h, def, style == GLASS ? 0.2f : 0f));
        fillBase(cv, rect, p, m);

        // توهّج ذهبي ناعم
        Paint g = new Paint(Paint.ANTI_ALIAS_FLAG);
        g.setShader(new RadialGradient(w * 0.85f, h * 0.1f, Math.max(w, h) * 0.6f, alpha(m.gold, style == MINIMAL ? 0x18 : 0x30), 0, Shader.TileMode.CLAMP));
        cv.drawRect(rect, g);

        // الزخرفة المختارة
        if (style != MINIMAL) ornament(cv, w, h, k, m, alpha(m.gold, style == GLASS ? 0x1C : 0x16), 54);
        }

        // هلال ذهبي رقيق
        if (crescent && !"none".equals(m.orn)) {
            float R = Math.min(w, h) * 0.32f;
            float cx = w * 0.12f, cy = h * 0.22f;
            Path a = new Path(); a.addCircle(cx, cy, R, Path.Direction.CW);
            Path bb = new Path(); bb.addCircle(cx + R * 0.42f, cy - R * 0.18f, R * 0.92f, Path.Direction.CW);
            a.op(bb, Path.Op.DIFFERENCE);
            Paint cp = new Paint(Paint.ANTI_ALIAS_FLAG);
            cp.setColor(alpha(m.gold, 0x2E));
            cv.drawPath(a, cp);
        }

        // إطار ذهبي رقيق
        Paint bp = new Paint(Paint.ANTI_ALIAS_FLAG);
        bp.setStyle(Paint.Style.STROKE);
        bp.setStrokeWidth(Math.max(1f, 1.2f * k));
        bp.setColor(alpha(m.gold, style == MINIMAL ? 0x40 : 0x8C));
        float ins = bp.getStrokeWidth() / 2;
        if (m.sk) WSkinArt.frame(cv, rect, k, m);
        else {
            if (classic(m)) cv.drawRoundRect(new RectF(ins, ins, w - ins, h - ins), rad - ins, rad - ins, bp);
            finishLook(cv, w, h, rad, k, m);
        }
        if (style == GLASS && classic(m) && !m.sk) {
            Paint hi = new Paint(Paint.ANTI_ALIAS_FLAG);
            hi.setShader(new LinearGradient(0, 0, 0, h * 0.45f, 0x22FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
            cv.drawRect(rect, hi);
        }
        return b;
    }

    /** خلفية سماء ليلية بلون الثيم مع نجوم ولمعات خفيفة (للساعة النجمية) */
    public static Bitmap starBg(Context c, Bundle opts, int defWdp, int defHdp, WidgetModel m) {
        if (m.sk) return skinPlain(c, opts, defWdp, defHdp, m, true);
        float d = c.getResources().getDisplayMetrics().density;
        int wdp = defWdp, hdp = defHdp;
        if (opts != null) {
            int a = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, 0), b = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 0);
            if (a > 0) wdp = a; if (b > 0) hdp = b;
        }
        int w = Math.max(1, Math.min(900, (int) (wdp * d * 0.75f))), h = Math.max(1, Math.min(700, (int) (hdp * d * 0.75f)));
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        int top = mix(m.c2, 0xFF000000, 0.25f), bot = mix(m.c1, 0xFF000000, 0.05f);
        p.setShader(gradShader(m, w, h, new LinearGradient(0, 0, w * 0.3f, h, top, bot, Shader.TileMode.CLAMP), 0.2f));
        float r = 22 * d * 0.75f;
        Path clipS = new Path();
        clipS.addRoundRect(new RectF(0, 0, w, h), r, r, Path.Direction.CW);
        cv.clipPath(clipS);
        fillBase(cv, new RectF(0, 0, w, h), p, m);
        p.setShader(new RadialGradient(w * 0.3f, h * 0.35f, Math.max(w, h) * 0.6f, alpha(m.gold, 40), 0, Shader.TileMode.CLAMP));
        cv.drawRoundRect(new RectF(0, 0, w, h), r, r, p);
        p.setShader(null);
        if (!"star".equals(m.orn)) ornament(cv, w, h, d * 0.75f, m, alpha(m.gold, 0x18), 50);
        java.util.Random rnd = new java.util.Random(7);
        for (int i = 0; i < 90; i++) {
            float x = rnd.nextFloat() * w, y = rnd.nextFloat() * h, s = (0.4f + rnd.nextFloat() * 1.1f) * d * 0.75f;
            p.setColor(alpha(0xFFFFFFFF, 60 + rnd.nextInt(150)));
            cv.drawCircle(x, y, s, p);
        }
        p.setStrokeWidth(1.1f * d);
        for (int i = 0; i < 6; i++) {
            float x = rnd.nextFloat() * w, y = rnd.nextFloat() * h, s = (3 + rnd.nextFloat() * 4) * d * 0.75f;
            p.setColor(alpha(0xFFFFFFFF, 170));
            cv.drawLine(x - s, y, x + s, y, p);
            cv.drawLine(x, y - s, x, y + s, p);
        }
        finishLook(cv, w, h, r, d * 0.75f, m);
        return bmp;
    }

    /** عمود التاريخ بالخط العربي (أميري) مع الرقم الكبير الشفاف خلف الشهر */
    public static Bitmap calliColumn(Context c, String wd, String grd, String grm, String hjd, String hjm) {
        int w = 360, h = 420;
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bmp);
        android.graphics.Typeface cal = android.graphics.Typeface.create(android.graphics.Typeface.SERIF, android.graphics.Typeface.BOLD);
        try { if (android.os.Build.VERSION.SDK_INT >= 26) cal = c.getResources().getFont(R.font.amiri_bold); } catch (Exception ignored) {}
        android.graphics.Typeface thin = android.graphics.Typeface.create("sans-serif-condensed", android.graphics.Typeface.BOLD);
        Paint num = new Paint(Paint.ANTI_ALIAS_FLAG);
        num.setTypeface(thin); num.setTextAlign(Paint.Align.CENTER); num.setTextSize(118); num.setColor(0x52FFFFFF);
        Paint tx = new Paint(Paint.ANTI_ALIAS_FLAG);
        tx.setTypeface(cal); tx.setTextAlign(Paint.Align.CENTER); tx.setColor(0xFFFFFFFF);
        tx.setShadowLayer(6, 0, 2, 0x55000000);
        float cx = w / 2f;
        String[] rows = {wd, grm, hjm};
        String[] nums = {"", grd, hjd};
        float[] ys = {h * 0.20f, h * 0.55f, h * 0.88f};
        for (int i = 0; i < 3; i++) {
            if (nums[i] != null && !nums[i].isEmpty()) cv.drawText(nums[i].replaceAll("[^0-9٠-٩]", ""), cx, ys[i] + 18, num);
            String s = rows[i] == null ? "" : rows[i];
            float size = 74;
            tx.setTextSize(size);
            while (tx.measureText(s) > w * 0.96f && size > 30) { size -= 4; tx.setTextSize(size); }
            cv.drawText(s, cx, ys[i], tx);
        }
        return bmp;
    }

    /** خلفية «حالة اليوم»: لوح داكن مائل للون الثيم */
    public static Bitmap todayBg(Context c, Bundle opts, WidgetModel m) {
        if (m.sk) return skinPlain(c, opts, 300, 300, m, false);
        float d = c.getResources().getDisplayMetrics().density;
        int wdp = 300, hdp = 300;
        if (opts != null) {
            int a = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, 0), b = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0);
            if (a > 0) wdp = a; if (b > 0) hdp = b;
        }
        int w = Math.max(1, Math.min(900, (int) (wdp * d * 0.7f))), h = Math.max(1, Math.min(900, (int) (hdp * d * 0.7f)));
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        // لون الثيم أو التدرّج المختار، بدرجة داكنة تناسب النص الأبيض
        int top = mix(m.c2, 0xFF0A0C10, m.custom ? 0.35f : 0.55f), bot = mix(m.c1, 0xFF0A0C10, m.custom ? 0.45f : 0.65f);
        p.setShader(gradShader(m, w, h, new LinearGradient(0, 0, 0, h, top, bot, Shader.TileMode.CLAMP), 0.4f));
        float r = 26 * d * 0.7f;
        RectF rc = new RectF(0, 0, w, h);
        Path clipT = new Path();
        clipT.addRoundRect(rc, r, r, Path.Direction.CW);
        cv.clipPath(clipT);
        fillBase(cv, rc, p, m);
        p.setShader(null);
        Paint gl = new Paint(Paint.ANTI_ALIAS_FLAG);
        gl.setShader(new RadialGradient(w * 0.8f, h * 0.05f, Math.max(w, h) * 0.6f, alpha(m.gold, 0x26), 0, Shader.TileMode.CLAMP));
        cv.drawRect(rc, gl);
        ornament(cv, w, h, d * 0.7f, m, alpha(m.gold, 0x16), 56);
        if (classic(m)) {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1.2f * d);
            p.setColor(alpha(m.gold, 0x55));
            cv.drawRoundRect(new RectF(1, 1, w - 1, h - 1), r, r, p);
        }
        finishLook(cv, w, h, r, d * 0.7f, m);
        return bmp;
    }


    /** خلفية بالمظهر فقط (للساعة النجمية وحالة اليوم والويدجت الجديدة) */
    public static Bitmap skinPlain(Context c, Bundle opts, int defWdp, int defHdp, WidgetModel m, boolean stars) {
        float d = c.getResources().getDisplayMetrics().density;
        int wdp = 0, hdp = 0;
        if (opts != null) {
            wdp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0);
            hdp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0);
        }
        if (wdp <= 0) wdp = defWdp;
        if (hdp <= 0) hdp = defHdp;
        float k = d * Math.min(1f, 900f / (Math.max(wdp, hdp) * d));
        int w = Math.max(40, (int) (wdp * k)), h = Math.max(40, (int) (hdp * k));
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        float rad = WSkinArt.rad(m, k);
        RectF rect = WSkinArt.inner(w, h, k, m);
        WSkinArt.outerShadow(cv, rect, rad, k, m);
        cv.save();
        cv.clipPath(WSkinArt.shape(rect, rad));
        WSkinArt.paint(cv, rect, k, m, null);
        if (stars) {
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            java.util.Random rnd = new java.util.Random(7);
            for (int i = 0; i < 70; i++) {
                p.setColor(alpha(m.text, 40 + rnd.nextInt(110)));
                cv.drawCircle(rnd.nextFloat() * w, rnd.nextFloat() * h, (0.4f + rnd.nextFloat() * 1.1f) * k, p);
            }
        }
        cv.restore();
        WSkinArt.frame(cv, rect, k, m);
        return b;
    }

    /** مسار أيقونة صلاة على شبكة ٢٤×٢٤ (نفس أيقونات التطبيق) */
    public static Bitmap prayerIcon(String k, int color, boolean filled, float scale) {
        int s = 120;
        Bitmap bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bmp);
        float u = s / 24f * Math.max(.6f, Math.min(1.3f, scale)) * .9f;
        cv.translate(s / 2f - 12 * u, s / 2f - 12 * u);
        drawIcon(cv, k, u, color, filled, 1.7f * u);
        return bmp;
    }

    static void drawIcon(Canvas cv, String k, float u, int color, boolean filled, float sw) {
        Paint ic = new Paint(Paint.ANTI_ALIAS_FLAG);
        ic.setStyle(Paint.Style.STROKE);
        ic.setStrokeCap(Paint.Cap.ROUND);
        ic.setStrokeJoin(Paint.Join.ROUND);
        ic.setStrokeWidth(sw);
        ic.setColor(color);
        Paint fp = new Paint(Paint.ANTI_ALIAS_FLAG);
        fp.setColor(alpha(color, 0xE6));
        if ("isha".equals(k)) {
            Path mo = new Path(); mo.addCircle(11.2f * u, 12.6f * u, 6.6f * u, Path.Direction.CW);
            Path cut = new Path(); cut.addCircle(15f * u, 9.6f * u, 5.6f * u, Path.Direction.CW);
            mo.op(cut, Path.Op.DIFFERENCE);
            if (filled) cv.drawPath(mo, fp); else cv.drawPath(mo, ic);
            return;
        }
        if ("dhuhr".equals(k)) {
            if (filled) cv.drawCircle(12 * u, 12 * u, 3.6f * u, fp);
            cv.drawCircle(12 * u, 12 * u, 3.6f * u, ic);
            for (int i = 0; i < 8; i++) {
                double a = Math.PI / 4 * i;
                float c1 = (float) Math.cos(a), s1 = (float) Math.sin(a);
                cv.drawLine(12 * u + c1 * 6.4f * u, 12 * u + s1 * 6.4f * u, 12 * u + c1 * 8.2f * u, 12 * u + s1 * 8.2f * u, ic);
            }
            return;
        }
        float hy = "maghrib".equals(k) || "sunrise".equals(k) ? 16 : ("asr".equals(k) ? 14 : 15);
        RectF arc = new RectF(7.5f * u, (hy - 4.5f) * u, 16.5f * u, (hy + 4.5f) * u);
        if (filled) cv.drawArc(arc, 180, 180, true, fp);
        cv.drawArc(arc, 180, 180, false, ic);
        cv.drawLine(5 * u, hy * u, 19 * u, hy * u, ic);
        if ("maghrib".equals(k) || "sunrise".equals(k)) {
            boolean up = "sunrise".equals(k);
            cv.drawLine(12 * u, (up ? 4.5f : 4.5f) * u, 12 * u, (up ? 9.5f : 10f) * u, ic);
            Path a = new Path();
            if (up) { a.moveTo(9.6f * u, 7 * u); a.lineTo(12 * u, 4.6f * u); a.lineTo(14.4f * u, 7 * u); }
            else { a.moveTo(9.6f * u, 8 * u); a.lineTo(12 * u, 10.4f * u); a.lineTo(14.4f * u, 8 * u); }
            cv.drawPath(a, ic);
            cv.drawLine(8 * u, 19 * u, 16 * u, 19 * u, ic);
        } else {
            float ry = hy - 8.5f;
            cv.drawLine(12 * u, ry * u, 12 * u, (ry + 2) * u, ic);
            cv.drawLine(6.3f * u, (ry + 2.8f) * u, 7.6f * u, (ry + 4) * u, ic);
            cv.drawLine(17.7f * u, (ry + 2.8f) * u, 16.4f * u, (ry + 4) * u, ic);
            if ("asr".equals(k)) {
                cv.drawLine(7 * u, 17 * u, 17 * u, 17 * u, ic);
                cv.drawLine(9 * u, 20 * u, 15 * u, 20 * u, ic);
            } else cv.drawLine(8 * u, 18 * u, 16 * u, 18 * u, ic);
        }
    }

    /** كبسولة زجاجية (خلفية عمود الصلاة) */
    public static Bitmap pill(int text, boolean on, int accent) {
        int w = 120, h = 330;
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        RectF r = new RectF(2, 2, w - 2, h - 2);
        p.setColor(alpha(text, on ? 0x1F : 0x10));
        cv.drawRoundRect(r, w / 2f, w / 2f, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2.5f);
        p.setColor(alpha(on ? accent : text, on ? 0xB0 : 0x5A));
        cv.drawRoundRect(r, w / 2f, w / 2f, p);
        return bmp;
    }

    /** دائرة الاسم والوقت داخل الكبسولة: مضيئة للصلاة القادمة */
    public static Bitmap pillCircle(int text, boolean on, int accent) {
        int s = 200;
        Bitmap bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        if (on) { p.setColor(accent); cv.drawCircle(s / 2f, s / 2f, s / 2f - 3, p); }
        else {
            p.setColor(alpha(text, 0x0F));
            cv.drawCircle(s / 2f, s / 2f, s / 2f - 3, p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3f); p.setColor(alpha(text, 0x55));
            cv.drawCircle(s / 2f, s / 2f, s / 2f - 3, p);
        }
        return bmp;
    }

    /** لوح داخلي شبه شفاف (حاوية الكبسولات) */
    public static Bitmap innerPanel(int text, float radiusDp) {
        int w = 600, h = 260;
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(alpha(text, 0x14));
        float r = Math.max(8, radiusDp * 2.2f);
        cv.drawRoundRect(new RectF(0, 0, w, h), r, r, p);
        return bmp;
    }

    /** صف الخط العربي: الشهر الميلادي | اليوم | الشهر الهجري (أميري) */
    public static Bitmap calliRow(Context c, String grm, String wd, String hjm, int color) {
        int w = 1200, h = 260;
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bmp);
        android.graphics.Typeface cal = android.graphics.Typeface.create(android.graphics.Typeface.SERIF, android.graphics.Typeface.BOLD);
        try { if (android.os.Build.VERSION.SDK_INT >= 26) cal = c.getResources().getFont(R.font.amiri_bold); } catch (Exception ignored) {}
        Paint tx = new Paint(Paint.ANTI_ALIAS_FLAG);
        tx.setTypeface(cal); tx.setTextAlign(Paint.Align.CENTER); tx.setColor(color);
        String[] words = {hjm == null ? "" : hjm, wd == null ? "" : wd, grm == null ? "" : grm}; // من اليسار لليمين: الهجري، اليوم، الميلادي
        float[] cx = {w * 0.17f, w * 0.5f, w * 0.83f};
        float[] base = {118, 150, 118};
        for (int i = 0; i < 3; i++) {
            float size = base[i];
            tx.setTextSize(size);
            float max = i == 1 ? w * 0.34f : w * 0.3f;
            while (tx.measureText(words[i]) > max && size > 40) { size -= 4; tx.setTextSize(size); }
            Paint.FontMetrics fm = tx.getFontMetrics();
            cv.drawText(words[i], cx[i], h / 2f - (fm.ascent + fm.descent) / 2f, tx);
        }
        Paint ln = new Paint(Paint.ANTI_ALIAS_FLAG);
        ln.setColor(alpha(color, 0x73));
        ln.setStrokeWidth(3f);
        cv.drawLine(w * 0.335f, h * 0.32f, w * 0.335f, h * 0.68f, ln);
        cv.drawLine(w * 0.665f, h * 0.32f, w * 0.665f, h * 0.68f, ln);
        return bmp;
    }

    /** شريط تقدم مستدير */
    public static int TRACK = 0x33FFFFFF, RING_TXT = 0xFFFFFFFF;

    public static Bitmap bar(float frac, int color) {
        int w = 400, h = 22;
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(TRACK);
        cv.drawRoundRect(new RectF(0, 0, w, h), h / 2f, h / 2f, p);
        p.setColor(color);
        float fw = Math.max(h, w * Math.max(0f, Math.min(1f, frac)));
        cv.drawRoundRect(new RectF(w - fw, 0, w, h), h / 2f, h / 2f, p); // يبدأ من اليمين (عربي)
        return bmp;
    }

    /** حلقة نسبة مئوية */
    public static Bitmap ring(float frac, int color) {
        int s = 300;
        Bitmap bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(22);
        p.setStrokeCap(Paint.Cap.ROUND);
        RectF rc = new RectF(24, 24, s - 24, s - 24);
        p.setColor(TRACK);
        cv.drawArc(rc, 0, 360, false, p);
        p.setColor(color);
        cv.drawArc(rc, -90, 360 * Math.max(0f, Math.min(1f, frac)), false, p);
        Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);
        t.setColor(RING_TXT);
        t.setTextAlign(Paint.Align.CENTER);
        t.setFakeBoldText(true);
        t.setTextSize(74);
        String num = String.valueOf(Math.round(frac * 100));
        float tw = t.measureText(num);
        Paint sm = new Paint(t); sm.setTextSize(36);
        cv.drawText(num, s / 2f - 12, s / 2f + 26, t);
        cv.drawText("%", s / 2f - 12 + tw / 2f + 18, s / 2f + 26, sm);
        return bmp;
    }

    /** حلقة صلاة مع أيقونتها: past = مكتملة، next = تمتلئ مع الوقت، up = قادمة (خافتة) — بألوان المظهر */
    public static Bitmap prayerRing(String k, float frac, String state, int accent) {
        return prayerRing(k, frac, state, accent, 0xFFFFFFFF, 0xFFFFFFFF, false, 1f);
    }

    public static Bitmap prayerRing(String k, float frac, String state, int accent, int text, int icon, boolean filled, float iconScale) {
        int s = 200;
        Bitmap bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bmp);
        float cx = s / 2f, cy = s / 2f, R = 84, sw = "next".equals(state) ? 15 : 12;
        Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        fill.setColor(alpha(text, "up".equals(state) ? 0x14 : 0x22));
        cv.drawCircle(cx, cy, R, fill);
        Paint tr = new Paint(Paint.ANTI_ALIAS_FLAG);
        tr.setStyle(Paint.Style.STROKE);
        tr.setStrokeWidth(sw);
        tr.setColor(alpha(text, 0x38));
        cv.drawCircle(cx, cy, R, tr);
        float f = "past".equals(state) ? 1f : "next".equals(state) ? Math.max(0.04f, Math.min(1f, frac)) : 0f;
        if (f > 0) {
            Paint ar = new Paint(Paint.ANTI_ALIAS_FLAG);
            ar.setStyle(Paint.Style.STROKE);
            ar.setStrokeWidth(sw);
            ar.setStrokeCap(Paint.Cap.ROUND);
            ar.setColor("next".equals(state) ? accent : alpha(text, 0xF0));
            cv.drawArc(new RectF(cx - R, cy - R, cx + R, cy + R), -90, 360 * f, false, ar);
        }
        float u = 4.2f * Math.max(.7f, Math.min(1.3f, iconScale));
        cv.save();
        cv.translate(cx - 12 * u, cy - 12 * u);
        drawIcon(cv, k, u, "up".equals(state) ? alpha(icon, 0xC0) : icon, filled, 8 * Math.max(.7f, Math.min(1.3f, iconScale)) * .95f);
        cv.restore();
        return bmp;
    }

    // ═══ ويدجت «فائدة اليوم ورحلة الصلاة» ═══
    static int[] widgetPx(Context c, Bundle opts, int defW, int defH, int maxSide) {
        float d = c.getResources().getDisplayMetrics().density;
        int wdp = 0, hdp = 0;
        if (opts != null) {
            wdp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0);
            hdp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0);
        }
        if (wdp <= 0) wdp = defW;
        if (hdp <= 0) hdp = defH;
        float k = d * Math.min(1f, maxSide / (Math.max(wdp, hdp) * d));
        return new int[]{Math.max(40, (int) (wdp * k)), Math.max(40, (int) (hdp * k)), Math.round(k * 1000)};
    }

    /** صورة المسجد (قص من المنتصف) + طبقة داكنة أو فاتحة + زوايا مستديرة */
    public static Bitmap arcBg(Context c, Bundle opts, WidgetModel m, String pick, boolean dark) {
        int[] px = widgetPx(c, opts, 330, 170, 720);
        int w = px[0], h = px[1];
        float k = px[2] / 1000f;
        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(out);
        float rad = (m.sk ? m.radius : 24) * k;
        Path clip = new Path();
        clip.addRoundRect(new RectF(0, 0, w, h), rad, rad, Path.Direction.CW);
        cv.clipPath(clip);
        Bitmap src = null;
        try {
            android.graphics.BitmapFactory.Options o = new android.graphics.BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            java.io.File f = null;
            int rid = 0;
            if (pick != null && pick.startsWith("u:")) f = new java.io.File(c.getFilesDir(), "wphoto_" + pick.substring(2) + ".jpg");
            else rid = c.getResources().getIdentifier("photo_" + (pick == null ? "fajr" : pick.replace("lib:", "")), "drawable", c.getPackageName());
            if (f != null && !f.exists()) { f = null; rid = c.getResources().getIdentifier("photo_fajr", "drawable", c.getPackageName()); }
            if (f != null) android.graphics.BitmapFactory.decodeFile(f.getAbsolutePath(), o); else if (rid != 0) android.graphics.BitmapFactory.decodeResource(c.getResources(), rid, o);
            int ss = 1;
            while (o.outWidth / (ss * 2) >= w && o.outHeight / (ss * 2) >= h) ss *= 2;
            android.graphics.BitmapFactory.Options o2 = new android.graphics.BitmapFactory.Options();
            o2.inSampleSize = ss;
            src = f != null ? android.graphics.BitmapFactory.decodeFile(f.getAbsolutePath(), o2) : rid != 0 ? android.graphics.BitmapFactory.decodeResource(c.getResources(), rid, o2) : null;
        } catch (Throwable ignored) {}
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        if (src != null) {
            float sc = Math.max(w / (float) src.getWidth(), h / (float) src.getHeight());
            float dw = src.getWidth() * sc, dh = src.getHeight() * sc;
            // نقطة تركيز رأسية لكل صورة من صور التطبيق (تظهر القبة/الكعبة/البرج كاملة)، وصور المستخدم مقصوصة مسبقاً على شكل الويدجت
            float fy = 0.5f;
            String pk = pick == null ? "" : pick.replace("lib:", "");
            if ("dhuhr".equals(pk)) fy = 0.4f; else if ("asr".equals(pk)) fy = 0.58f; else if ("maghrib".equals(pk)) fy = 0.36f; else if ("isha".equals(pk)) fy = 0.6f;
            float top = Math.max(h - dh, Math.min(0f, h / 2f - dh * fy));
            cv.drawBitmap(src, null, new RectF((w - dw) / 2f, top, (w + dw) / 2f, top + dh), p);
        } else {
            p.setShader(new LinearGradient(0, 0, 0, h, 0xFF0D1E3D, 0xFF1C3358, Shader.TileMode.CLAMP));
            cv.drawRect(0, 0, w, h, p);
            p.setShader(null);
        }
        // تظليل خفيف خلف النص فقط (أعلى وأسفل) لتبقى الصورة واضحة في الوسط
        if (dark) p.setShader(new LinearGradient(0, 0, 0, h, new int[]{0x61000000, 0x14000000, 0x1F000000, 0x80000000}, new float[]{0f, .42f, .62f, 1f}, Shader.TileMode.CLAMP));
        else p.setShader(new LinearGradient(0, 0, 0, h, new int[]{0x8CFFFFFF, 0x0FFFFFFF, 0x1AFFFFFF, 0x8CFFFFFF}, new float[]{0f, .42f, .62f, 1f}, Shader.TileMode.CLAMP));
        cv.drawRect(0, 0, w, h, p);
        return out;
    }

    /** زر دائري: قمر/شمس للوضع، وجرس للكتم */
    public static Bitmap arcButton(String kind, boolean dark) {
        int s = 120;
        Bitmap b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(dark ? 0x75000000 : 0xC8FFFFFF);
        cv.drawCircle(s / 2f, s / 2f, s / 2f - 2, p);
        int col = dark ? 0xFFFFFFFF : 0xFF12372A;
        p.setColor(col);
        float cx = s / 2f, cy = s / 2f;
        if ("moon".equals(kind)) {
            Path mo = new Path(); mo.addCircle(cx - 3, cy + 2, 26, Path.Direction.CW);
            Path cut = new Path(); cut.addCircle(cx + 11, cy - 9, 22, Path.Direction.CW);
            mo.op(cut, Path.Op.DIFFERENCE);
            cv.drawPath(mo, p);
        } else if ("sun".equals(kind)) {
            cv.drawCircle(cx, cy, 15, p);
            p.setStrokeWidth(6); p.setStrokeCap(Paint.Cap.ROUND);
            for (int i = 0; i < 8; i++) { double a = Math.PI / 4 * i; cv.drawLine(cx + (float) Math.cos(a) * 24, cy + (float) Math.sin(a) * 24, cx + (float) Math.cos(a) * 33, cy + (float) Math.sin(a) * 33, p); }
        } else {
            Path bell = new Path();
            bell.moveTo(cx - 24, cy + 16);
            bell.cubicTo(cx - 18, cy + 8, cx - 20, cy - 2, cx - 18, cy - 12);
            bell.cubicTo(cx - 15, cy - 26, cx + 15, cy - 26, cx + 18, cy - 12);
            bell.cubicTo(cx + 20, cy - 2, cx + 18, cy + 8, cx + 24, cy + 16);
            bell.close();
            cv.drawPath(bell, p);
            cv.drawCircle(cx, cy + 23, 6, p);
            cv.drawCircle(cx, cy - 27, 4, p);
            if ("bellOff".equals(kind)) {
                Paint sl = new Paint(Paint.ANTI_ALIAS_FLAG);
                sl.setStrokeWidth(7); sl.setStrokeCap(Paint.Cap.ROUND); sl.setColor(dark ? 0xFFFF8A80 : 0xFFB3261E);
                cv.drawLine(cx - 30, cy - 30, cx + 30, cy + 30, sl);
            }
        }
        return b;
    }

    /** مسار الصلوات من الفجر إلى العشاء: الجزء الماضي خط متصل، والقادم متقطع، ونقطة «الآن» */
    public static Bitmap arcPath(Context c, Bundle opts, WidgetModel m, boolean dark) {
        int[] px = widgetPx(c, opts, 330, 170, 900);
        int W = px[0], H = Math.max(60, (int) (px[1] * 0.46f));
        Bitmap b = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        org.json.JSONArray it = m.items();
        if (it == null) return b;
        String[] ks = {"fajr", "dhuhr", "asr", "maghrib", "isha"};
        long[] at = new long[5];
        String[] nm = new String[5], tm = new String[5];
        for (int i = 0; i < it.length(); i++) {
            org.json.JSONObject o = it.optJSONObject(i);
            if (o == null) continue;
            for (int j = 0; j < 5; j++) if (ks[j].equals(o.optString("k"))) { at[j] = o.optLong("at"); nm[j] = o.optString("name"); tm[j] = o.optString("sh", o.optString("s")); }
        }
        if (at[0] <= 0 || at[4] <= at[0]) return b;
        float s = H / 104f, pad = 24 * s, base = H * 0.62f, amp = H * 0.42f;
        long now = System.currentTimeMillis();
        int line = dark ? 0xFF9FE3C8 : 0xFF0F5132, dash = dark ? 0xC0FFFFFF : 0x8C0F281E, txt = dark ? 0xFFFFFFFF : 0xFF12372A, sub = dark ? 0xC0FFFFFF : 0xC012372A;
        float span = at[4] - at[0];
        float fn = Math.max(0f, Math.min(1f, (now - at[0]) / span));
        Path done = new Path(), rest = new Path();
        int N = 60;
        for (int i = 0; i <= N; i++) {
            float f = i / (float) N, x = W - pad - f * (W - 2 * pad), y = (float) (base - amp * Math.sin(Math.PI * f));
            if (f <= fn) { if (i == 0) done.moveTo(x, y); else done.lineTo(x, y); }
            if (f >= fn - 1f / N) { if (rest.isEmpty()) rest.moveTo(x, y); else rest.lineTo(x, y); }
        }
        Paint lp = new Paint(Paint.ANTI_ALIAS_FLAG);
        lp.setStyle(Paint.Style.STROKE); lp.setStrokeCap(Paint.Cap.ROUND);
        lp.setShadowLayer(2 * s, 0, s, dark ? 0x99000000 : 0x99FFFFFF);
        lp.setStrokeWidth(2.6f * s); lp.setColor(line);
        if (fn > 0) cv.drawPath(done, lp);
        lp.setStrokeWidth(2f * s); lp.setColor(dash);
        lp.setPathEffect(new android.graphics.DashPathEffect(new float[]{5 * s, 5 * s}, 0));
        if (fn < 1) cv.drawPath(rest, lp);
        lp.setPathEffect(null);
        int next = -1;
        for (int j = 0; j < 5; j++) if (at[j] > now) { next = j; break; }
        Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
        tp.setTextAlign(Paint.Align.CENTER);
        tp.setShadowLayer(2.5f * s, 0, s * .6f, dark ? 0xAA000000 : 0xCCFFFFFF);
        for (int j = 0; j < 5; j++) {
            float f = Math.max(0f, Math.min(1f, (at[j] - at[0]) / span));
            float x = W - pad - f * (W - 2 * pad), y = (float) (base - amp * Math.sin(Math.PI * f));
            boolean past = at[j] <= now, on = j == next;
            Paint dp = new Paint(Paint.ANTI_ALIAS_FLAG);
            if (past) { dp.setColor(line); cv.drawCircle(x, y, (on ? 6 : 4) * s, dp); }
            dp.setStyle(Paint.Style.STROKE); dp.setStrokeWidth((on ? 2.4f : 1.6f) * s); dp.setColor(on || past ? line : dash);
            cv.drawCircle(x, y, (on ? 6 : 4) * s, dp);
            tp.setFakeBoldText(true); tp.setTextSize((on ? 10.5f : 9.5f) * s); tp.setColor(on ? line : txt);
            cv.drawText(nm[j] == null ? "" : nm[j], x, y + 17 * s, tp);
            tp.setFakeBoldText(false); tp.setTextSize(8.5f * s); tp.setColor(sub);
            cv.drawText(tm[j] == null ? "" : tm[j], x, y + 29 * s, tp);
        }
        if (fn > 0 && fn < 1) {
            float x = W - pad - fn * (W - 2 * pad), y = (float) (base - amp * Math.sin(Math.PI * fn));
            Paint np = new Paint(Paint.ANTI_ALIAS_FLAG);
            np.setColor(0xFFF2D49B);
            np.setShadowLayer(4 * s, 0, 0, 0x88F2D49B);
            cv.drawCircle(x, y, 7 * s, np);
            np.setShadowLayer(0, 0, 0, 0);
            np.setStyle(Paint.Style.STROKE); np.setStrokeWidth(1.5f * s); np.setColor(0xCCFFFFFF);
            cv.drawCircle(x, y, 7 * s, np);
        }
        return b;
    }

}
