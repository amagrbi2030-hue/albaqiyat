package com.albaqiyat.app;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

/** أساس مشترك لجميع ودجات أوقات الصلاة */
public abstract class BaseWidget extends AppWidgetProvider {
    protected abstract String kind();

    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        for (int id : ids) WidgetHub.render(c, m, id, kind());
        AlarmScheduler.scheduleWidgetTick(c);
    }

    @Override
    public void onAppWidgetOptionsChanged(Context c, AppWidgetManager m, int id, Bundle o) {
        WidgetHub.render(c, m, id, kind());
    }

    @Override
    public void onEnabled(Context c) {
        AlarmScheduler.scheduleWidgetTick(c);
    }

    @Override
    public void onReceive(Context c, Intent i) {
        super.onReceive(c, i);
        String a = i.getAction();
        if (AlarmScheduler.ACTION_TICK.equals(a)) {
            WidgetHub.updateAll(c);
        } else if (WidgetHub.ACTION_MUTE.equals(a)) {
            boolean mu = !AlarmScheduler.prefs(c).getBoolean("muted", false);
            AlarmScheduler.prefs(c).edit().putBoolean("muted", mu).commit();
            WidgetHub.updateAll(c);
        }
    }
}
