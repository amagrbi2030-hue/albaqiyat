package com.albaqiyat.app;

public class WTimelineWidget extends BaseWidget {
    @Override
    protected String kind() { return "timeline"; }
}
