package com.albaqiyat.app;

public class WDaynightWidget extends BaseWidget {
    @Override
    protected String kind() { return "daynight"; }
}
