package com.albaqiyat.app;

import android.content.Context;
import android.graphics.Color;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

/** بيانات الودجت: الصلاة الحالية والقادمة ووقت الإقامة، محسوبة من الأوقات المحفوظة */
public class WidgetModel {
    public boolean ok = false;
    public String city = "";
    public JSONObject day;        // اليوم المعروض
    public JSONObject cur, next, after;
    public int curIdx = -1, nextIdx = -1; // داخل عناصر اليوم المعروض
    public boolean iqPhase = false;       // بين الأذان والإقامة
    public long target = 0, fromAt = 0;   // العدّ التنازلي ونقطة البداية لشريط التقدم
    public int c1 = 0xFF0F5132, c2 = 0xFF0B3A27, gold = 0xFFD8B45A;
    public boolean muted = false;
    public JSONObject alerts;

    static class Entry { JSONObject o; int day; int idx; Entry(JSONObject o, int d, int i) { this.o = o; day = d; idx = i; } }

    static int color(String s, int def) {
        try { return s == null || s.isEmpty() ? def : Color.parseColor(s); } catch (Exception e) { return def; }
    }

    public static WidgetModel load(Context c) {
        WidgetModel m = new WidgetModel();
        JSONObject w;
        try { w = new JSONObject(AlarmScheduler.prefs(c).getString("widget", "{}")); } catch (JSONException e) { w = new JSONObject(); }
        m.muted = AlarmScheduler.prefs(c).getBoolean("muted", false);
        m.city = w.optString("city", "");
        m.alerts = w.optJSONObject("alerts");
        JSONObject th = w.optJSONObject("theme");
        if (th != null) {
            m.c1 = color(th.optString("c1"), m.c1);
            m.c2 = color(th.optString("c2"), m.c2);
            m.gold = color(th.optString("gold"), m.gold);
        }
        JSONArray days = w.optJSONArray("days");
        if (days == null) return m;
        List<Entry> P = new ArrayList<>();
        for (int d = 0; d < days.length(); d++) {
            JSONObject dd = days.optJSONObject(d);
            JSONArray it = dd == null ? null : dd.optJSONArray("items");
            if (it == null) continue;
            for (int i = 0; i < it.length(); i++) {
                JSONObject o = it.optJSONObject(i);
                if (o != null && !"sunrise".equals(o.optString("k")) && o.optLong("at", 0) > 0) P.add(new Entry(o, d, i));
            }
        }
        long now = System.currentTimeMillis();
        int n = -1;
        for (int i = 0; i < P.size(); i++) if (P.get(i).o.optLong("at") > now) { n = i; break; }
        if (n < 0) return m;
        Entry nx = P.get(n);
        Entry cu = n > 0 ? P.get(n - 1) : null;
        m.next = nx.o;
        m.after = n + 1 < P.size() ? P.get(n + 1).o : null;
        m.cur = cu != null ? cu.o : null;
        long iq = cu != null ? cu.o.optLong("iq", 0) : 0;
        m.iqPhase = cu != null && iq > now;
        Entry shown = m.iqPhase ? cu : nx;
        m.day = days.optJSONObject(shown.day);
        if (m.iqPhase) {
            m.target = iq;
            m.fromAt = cu.o.optLong("at");
            m.curIdx = cu.idx;
            m.nextIdx = nx.day == cu.day ? nx.idx : -1;
        } else {
            m.target = nx.o.optLong("at");
            m.fromAt = cu != null ? (cu.o.optLong("iq", 0) > 0 ? cu.o.optLong("iq") : cu.o.optLong("at")) : now;
            m.nextIdx = nx.idx;
            m.curIdx = cu != null && cu.day == nx.day ? cu.idx : -1;
        }
        m.ok = true;
        return m;
    }

    /** أقرب لحظة يتغيّر فيها الودجت (أذان أو إقامة) */
    public static long nextChange(Context c) {
        WidgetModel m = load(c);
        if (!m.ok) return 0;
        return m.target;
    }

    public JSONArray items() { return day != null ? day.optJSONArray("items") : null; }

    public int progress() {
        long now = System.currentTimeMillis();
        long span = target - fromAt;
        if (span <= 0) return 0;
        long p = (now - fromAt) * 1000 / span;
        return (int) Math.max(0, Math.min(1000, p));
    }

    public boolean alertOn(String type, String k) {
        if (alerts == null) return true;
        JSONObject a = alerts.optJSONObject(type);
        return a != null && a.optBoolean(k, false);
    }
}
