package com.albaqiyat.app;

public class WGlassdayWidget extends BaseWidget {
    @Override
    protected String kind() { return "glassday"; }
}
