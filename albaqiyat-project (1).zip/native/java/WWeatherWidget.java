package com.albaqiyat.app;

public class WWeatherWidget extends BaseWidget {
    @Override
    protected String kind() { return "weather"; }
}
