package com.albaqiyat.app;

public class WGlassWidget extends BaseWidget {
    @Override
    protected String kind() { return "glass"; }
}
