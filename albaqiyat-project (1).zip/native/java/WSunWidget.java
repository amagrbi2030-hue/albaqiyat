package com.albaqiyat.app;

public class WSunWidget extends BaseWidget {
    @Override
    protected String kind() { return "sun"; }
}
