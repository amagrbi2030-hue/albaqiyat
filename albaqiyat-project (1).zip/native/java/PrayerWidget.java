package com.albaqiyat.app;

/** الودجت الشامل (الموصى به) — يستقبل أيضاً تحديثات الوقت وزر كتم الأذان */
public class PrayerWidget extends BaseWidget {
    @Override
    protected String kind() { return "full"; }
}
