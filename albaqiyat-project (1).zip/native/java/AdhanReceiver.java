package com.albaqiyat.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import org.json.JSONObject;

/** يستقبل منبّه وقت الصلاة، وكذلك إعادة تشغيل الهاتف أو تغيير الوقت لإعادة الجدولة */
public class AdhanReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent in) {
        String a = in.getAction();
        if (a == null || !AlarmScheduler.ACTION_ADHAN.equals(a)) {
            AlarmScheduler.scheduleAll(c);
            WidgetHub.updateAll(c);
            return;
        }
        WidgetHub.updateAll(c);
        JSONObject ev = AlarmScheduler.find(c, in.getIntExtra("id", -1));
        if (ev == null) return;
        String kind = ev.optString("kind", "adhan");
        if ("adhan".equals(kind)) IqamaNotice.post(c, ev);   // المتبقي للإقامة في الإشعارات
        else if ("iqama".equals(kind)) IqamaNotice.cancel(c);
        if (AlarmScheduler.prefs(c).getBoolean("muted", false)) return; // كتم من زر الودجت
        if (System.currentTimeMillis() - ev.optLong("at", 0) > 10 * 60 * 1000L) return;
        Intent s = new Intent(c, AdhanService.class);
        s.putExtra("ev", ev.toString());
        try {
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(s);
            else c.startService(s);
        } catch (Exception ignored) {}
    }
}
