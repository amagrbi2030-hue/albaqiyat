package com.albaqiyat.app;

public class WCrescentWidget extends BaseWidget {
    @Override
    protected String kind() { return "crescent"; }
}
