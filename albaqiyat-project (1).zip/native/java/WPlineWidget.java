package com.albaqiyat.app;

public class WPlineWidget extends BaseWidget {
    @Override
    protected String kind() { return "pline"; }
}
