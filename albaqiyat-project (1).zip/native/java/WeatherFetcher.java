package com.albaqiyat.app;

import android.content.Context;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;

/** جلب الطقس (Open-Meteo، دون مفتاح) عند توفر الإنترنت، وحفظه لعرضه في الودجت دون اتصال */
public class WeatherFetcher {
    static volatile boolean busy = false;

    static void maybeFetch(final Context ctx) {
        final Context c = ctx.getApplicationContext();
        long at = AlarmScheduler.prefs(c).getLong("wx_at", 0);
        if (busy || System.currentTimeMillis() - at < 30 * 60 * 1000L) return;
        JSONObject w;
        try { w = new JSONObject(AlarmScheduler.prefs(c).getString("widget", "{}")); } catch (Exception e) { return; }
        final double lat = w.optDouble("lat", Double.NaN), lng = w.optDouble("lng", Double.NaN);
        if (Double.isNaN(lat) || Double.isNaN(lng)) return;
        busy = true;
        new Thread(new Runnable() {
            public void run() {
                HttpURLConnection con = null;
                try {
                    String u = String.format(Locale.US,
                            "https://api.open-meteo.com/v1/forecast?latitude=%.4f&longitude=%.4f&current=temperature_2m,weather_code,is_day&daily=temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=1",
                            lat, lng);
                    con = (HttpURLConnection) new URL(u).openConnection();
                    con.setConnectTimeout(8000);
                    con.setReadTimeout(8000);
                    if (con.getResponseCode() != 200) return;
                    BufferedReader r = new BufferedReader(new InputStreamReader(con.getInputStream(), "UTF-8"));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = r.readLine()) != null) sb.append(line);
                    r.close();
                    JSONObject j = new JSONObject(sb.toString());
                    JSONObject cur = j.optJSONObject("current");
                    JSONObject d = j.optJSONObject("daily");
                    if (cur == null) return;
                    JSONObject out = new JSONObject();
                    out.put("t", cur.optDouble("temperature_2m"));
                    out.put("code", cur.optInt("weather_code"));
                    out.put("day", cur.optInt("is_day", 1));
                    if (d != null) {
                        out.put("max", d.optJSONArray("temperature_2m_max") != null ? d.optJSONArray("temperature_2m_max").optDouble(0) : Double.NaN);
                        out.put("min", d.optJSONArray("temperature_2m_min") != null ? d.optJSONArray("temperature_2m_min").optDouble(0) : Double.NaN);
                    }
                    AlarmScheduler.prefs(c).edit().putString("wx", out.toString()).putLong("wx_at", System.currentTimeMillis()).commit();
                    WidgetHub.renderAllOnly(c);
                } catch (Exception ignored) {
                } finally {
                    busy = false;
                    if (con != null) con.disconnect();
                }
            }
        }).start();
    }

    static String desc(int code) {
        if (code == 0) return "صافٍ";
        if (code == 1) return "صافٍ غالباً";
        if (code == 2) return "غائم جزئياً";
        if (code == 3) return "غائم";
        if (code == 45 || code == 48) return "ضباب";
        if (code >= 51 && code <= 57) return "رذاذ";
        if (code >= 61 && code <= 67) return "مطر";
        if (code >= 71 && code <= 77) return "ثلج";
        if (code >= 80 && code <= 82) return "زخات مطر";
        if (code >= 95) return "عاصفة رعدية";
        return "";
    }

    static String emoji(int code, boolean day) {
        if (code == 0) return day ? "☀️" : "🌙";
        if (code == 1 || code == 2) return day ? "🌤️" : "☁️";
        if (code == 3) return "☁️";
        if (code == 45 || code == 48) return "🌫️";
        if (code >= 51 && code <= 67) return "🌧️";
        if (code >= 71 && code <= 77) return "❄️";
        if (code >= 80 && code <= 82) return "🌦️";
        if (code >= 95) return "⛈️";
        return day ? "🌤️" : "🌙";
    }
}
