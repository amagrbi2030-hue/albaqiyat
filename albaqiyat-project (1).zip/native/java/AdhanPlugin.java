package com.albaqiyat.app;

import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import org.json.JSONObject;

/** جسر بين التطبيق ونظام أندرويد: جدولة الأذان، الودجت، الأذونات */
@CapacitorPlugin(name = "Adhan")
public class AdhanPlugin extends Plugin {

    @PluginMethod
    public void schedule(PluginCall call) {
        Context c = getContext();
        JSArray ev = call.getArray("events");
        JSObject w = call.getObject("widget");
        android.content.SharedPreferences.Editor e = AlarmScheduler.prefs(c).edit();
        e.putString("events", ev != null ? ev.toString() : "[]");
        if (w != null) e.putString("widget", w.toString());
        e.commit();
        int n = AlarmScheduler.scheduleAll(c);
        WidgetHub.updateAll(c);
        JSObject r = new JSObject();
        r.put("count", n);
        r.put("exact", AlarmScheduler.canExact(c));
        call.resolve(r);
    }

    @PluginMethod
    public void status(PluginCall call) {
        Context c = getContext();
        JSObject r = new JSObject();
        r.put("exact", AlarmScheduler.canExact(c));
        boolean fs = true;
        if (Build.VERSION.SDK_INT >= 34) {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            fs = nm != null && nm.canUseFullScreenIntent();
        }
        r.put("fullScreen", fs);
        r.put("overlay", Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(c));
        boolean bat = true;
        if (Build.VERSION.SDK_INT >= 23) {
            PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
            bat = pm != null && pm.isIgnoringBatteryOptimizations(c.getPackageName());
        }
        r.put("battery", bat);
        r.put("playing", AdhanService.isPlaying());
        call.resolve(r);
    }

    @PluginMethod
    public void openSettings(PluginCall call) {
        Context c = getContext();
        String which = call.getString("which", "");
        Uri pkg = Uri.parse("package:" + c.getPackageName());
        Intent i = null;
        if ("exact".equals(which) && Build.VERSION.SDK_INT >= 31) i = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, pkg);
        else if ("fullscreen".equals(which) && Build.VERSION.SDK_INT >= 34) i = new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, pkg);
        else if ("overlay".equals(which) && Build.VERSION.SDK_INT >= 23) i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkg);
        else if ("battery".equals(which) && Build.VERSION.SDK_INT >= 23) i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkg);
        if (i == null) i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            c.startActivity(i);
        } catch (Exception ex) {
            try {
                Intent d = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg);
                d.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                c.startActivity(d);
            } catch (Exception ignored) {}
        }
        call.resolve();
    }

    @PluginMethod
    public void stop(PluginCall call) {
        try {
            Intent s = new Intent(getContext(), AdhanService.class);
            s.setAction("STOP");
            getContext().startService(s);
        } catch (Exception ignored) {}
        call.resolve();
    }

    /** تجربة شاشة الأذان بعد ثوانٍ (لاختبار الصوت والشاشة) */
    @PluginMethod
    public void test(PluginCall call) {
        Context c = getContext();
        try {
            JSONObject ev = new JSONObject();
            long at = System.currentTimeMillis() + call.getInt("delay", 5) * 1000L;
            ev.put("id", 999999);
            ev.put("at", at);
            ev.put("kind", call.getString("kind", "adhan"));
            ev.put("prayer", call.getString("prayer", "fajr"));
            ev.put("name", call.getString("name", "الفجر"));
            ev.put("title", call.getString("title", "تجربة شاشة الأذان"));
            ev.put("body", call.getString("body", ""));
            ev.put("sound", call.getString("sound", "adhan_m1"));
            ev.put("time", call.getString("time", ""));
            ev.put("city", call.getString("city", ""));
            ev.put("who", call.getString("who", ""));
            ev.put("fadl", call.getString("fadl", ""));
            ev.put("iq", call.getDouble("iq", 0.0).longValue());
            ev.put("iqs", call.getString("iqs", ""));
            ev.put("fsrc", call.getString("fsrc", ""));
            ev.put("voice", call.getString("voice", "اقتربت الصلاة، الرجاء الاستعداد"));
            if ("adhan".equals(ev.optString("kind"))) IqamaNotice.post(c, ev);
            Intent s = new Intent(c, AdhanService.class);
            s.putExtra("ev", ev.toString());
            // تشغيل فوري ما دام التطبيق مفتوحاً
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(s);
            else c.startService(s);
        } catch (Exception ex) {
            call.reject(ex.getMessage());
            return;
        }
        call.resolve();
    }
}
