package com.albaqiyat.app;

public class WThreeWidget extends BaseWidget {
    @Override
    protected String kind() { return "three"; }
}
