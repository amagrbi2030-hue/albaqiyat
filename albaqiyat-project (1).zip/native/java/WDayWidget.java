package com.albaqiyat.app;

public class WDayWidget extends BaseWidget {
    @Override
    protected String kind() { return "day"; }
}
