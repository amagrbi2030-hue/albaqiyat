package com.albaqiyat.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import org.json.JSONObject;

/** إشعار ثابت يعرض الوقت المتبقي لإقامة الصلاة بعد الأذان، ويختفي عند الإقامة */
public class IqamaNotice {
    static final String CH = "iqama_countdown_v1";
    static final int NID = 4748;

    static final int NID_PRE = 4749;

    /** المتبقي للإقامة بعد الأذان */
    static void post(Context c, JSONObject ev) {
        String name = ev.optString("name", "");
        show(c, NID, ev.optLong("iq", 0), "⏱ الإقامة بعد — صلاة " + name, "إقامة صلاة " + name + " الساعة " + ev.optString("iqs", ""));
    }

    /** المتبقي للأذان قبل دخول الوقت بعشر دقائق */
    static void postPre(Context c, JSONObject ev) {
        String name = ev.optString("name", "");
        show(c, NID_PRE, ev.optLong("adhanAt", 0), "🕌 الأذان بعد — صلاة " + name, "أذان صلاة " + name + " الساعة " + ev.optString("adhanS", ev.optString("time", "")));
    }

    static void show(Context c, int nid, long iq, String title, String text) {
        long now = System.currentTimeMillis();
        if (iq <= now) return;
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(CH) == null) {
            NotificationChannel ch = new NotificationChannel(CH, "العدّ التنازلي للأذان والإقامة", NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("عدّ تنازلي من الأذان حتى الإقامة");
            ch.setSound(null, null);
            ch.enableVibration(false);
            ch.setShowBadge(false);
            ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            nm.createNotificationChannel(ch);
        }
        Intent li = c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
        if (li == null) li = new Intent(c, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(c, 3, li, AlarmScheduler.piFlags());
        int icon = c.getResources().getIdentifier("ic_stat_salah", "drawable", c.getPackageName());
        if (icon == 0) icon = android.R.drawable.ic_lock_idle_alarm;
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, CH) : new Notification.Builder(c);
        b.setSmallIcon(icon)
                .setContentTitle(title)
                .setContentText(text)
                .setColor(0xFFC69A3A)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setContentIntent(pi)
                .setWhen(iq)
                .setShowWhen(true);
        if (Build.VERSION.SDK_INT >= 24) {
            b.setUsesChronometer(true);
            b.setChronometerCountDown(true);
        }
        if (Build.VERSION.SDK_INT >= 26) b.setTimeoutAfter(iq - now + 1000);
        if (Build.VERSION.SDK_INT < 26) b.setPriority(Notification.PRIORITY_LOW);
        try { nm.notify(nid, b.build()); } catch (Exception ignored) {}
    }

    static void cancel(Context c) { cancel(c, NID); }

    static void cancel(Context c, int nid) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.cancel(nid);
    }
}
