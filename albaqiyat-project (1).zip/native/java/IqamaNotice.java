package com.albaqiyat.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import org.json.JSONObject;

/** إشعار ثابت يعرض الوقت المتبقي لإقامة الصلاة بعد الأذان، ويختفي عند الإقامة */
public class IqamaNotice {
    static final String CH = "iqama_countdown_v1";
    static final int NID = 4748;

    static void post(Context c, JSONObject ev) {
        long iq = ev.optLong("iq", 0);
        long now = System.currentTimeMillis();
        if (iq <= now) return;
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(CH) == null) {
            NotificationChannel ch = new NotificationChannel(CH, "المتبقي لإقامة الصلاة", NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("عدّ تنازلي من الأذان حتى الإقامة");
            ch.setSound(null, null);
            ch.enableVibration(false);
            ch.setShowBadge(false);
            ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            nm.createNotificationChannel(ch);
        }
        Intent li = c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
        if (li == null) li = new Intent(c, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(c, 3, li, AlarmScheduler.piFlags());
        int icon = c.getResources().getIdentifier("ic_stat_salah", "drawable", c.getPackageName());
        if (icon == 0) icon = android.R.drawable.ic_lock_idle_alarm;
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, CH) : new Notification.Builder(c);
        String name = ev.optString("name", "");
        b.setSmallIcon(icon)
                .setContentTitle("⏱ الإقامة بعد — صلاة " + name)
                .setContentText("إقامة صلاة " + name + " الساعة " + ev.optString("iqs", ""))
                .setColor(0xFFC69A3A)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setContentIntent(pi)
                .setWhen(iq)
                .setShowWhen(true);
        if (Build.VERSION.SDK_INT >= 24) {
            b.setUsesChronometer(true);
            b.setChronometerCountDown(true);
        }
        if (Build.VERSION.SDK_INT >= 26) b.setTimeoutAfter(iq - now + 1000);
        if (Build.VERSION.SDK_INT < 26) b.setPriority(Notification.PRIORITY_LOW);
        try { nm.notify(NID, b.build()); } catch (Exception ignored) {}
    }

    static void cancel(Context c) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.cancel(NID);
    }
}
