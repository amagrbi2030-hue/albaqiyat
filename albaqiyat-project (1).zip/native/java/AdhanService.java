package com.albaqiyat.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.media.VolumeProvider;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import java.util.Locale;
import org.json.JSONException;
import org.json.JSONObject;

/** يشغّل صوت الأذان/الإقامة على مستوى صوت المنبّه، ويعرض شاشة الأذان الكاملة،
 *  ويجعل أزرار الصوت في الجهاز تتحكم في مستوى الأذان أثناء تشغيله. */
public class AdhanService extends Service {
    static final String CH = "adhan_screen_v1";
    static final int NID = 4747;
    static volatile boolean playing = false;
    static volatile String currentEv = null;

    private MediaPlayer mp;
    private MediaSession ms;
    private TextToSpeech tts;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable autoStop = new Runnable() { public void run() { stopAll(); } };

    static boolean isPlaying() { return playing; }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent in, int flags, int startId) {
        if (in != null && "STOP".equals(in.getAction())) {
            stopAll();
            return START_NOT_STICKY;
        }
        String evStr = in != null ? in.getStringExtra("ev") : null;
        JSONObject ev;
        try {
            ev = new JSONObject(evStr == null ? "" : evStr);
        } catch (JSONException e) {
            stopSelf();
            return START_NOT_STICKY;
        }
        currentEv = evStr;
        ensureChannel();

        Intent full = new Intent(this, AdhanActivity.class);
        full.putExtra("ev", evStr);
        full.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent fpi = PendingIntent.getActivity(this, 1, full, AlarmScheduler.piFlags());
        Intent stop = new Intent(this, AdhanService.class);
        stop.setAction("STOP");
        PendingIntent spi = PendingIntent.getService(this, 2, stop, AlarmScheduler.piFlags());

        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CH) : new Notification.Builder(this);
        int icon = getResources().getIdentifier("ic_stat_salah", "drawable", getPackageName());
        if (icon == 0) icon = android.R.drawable.ic_lock_idle_alarm;
        String kind = ev.optString("kind", "adhan");
        b.setSmallIcon(icon)
                .setContentTitle(ev.optString("title", "حان وقت الصلاة"))
                .setContentText(ev.optString("body", ""))
                .setCategory(Notification.CATEGORY_ALARM)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setColor(0xFFC69A3A)
                .setOngoing(true)
                .setContentIntent(fpi)
                .setFullScreenIntent(fpi, true);
        // لا يوجد زر إيقاف في الإشعار: الإيقاف فقط من الزر المخصص في شاشة الأذان أو داخل التطبيق
        if (Build.VERSION.SDK_INT < 26) b.setPriority(Notification.PRIORITY_MAX);
        Notification n = b.build();
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
            else startForeground(NID, n);
        } catch (Exception e) {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(NID, n);
        }

        String snd = ev.optString("sound", "");
        if ("pre".equals(kind) && snd.isEmpty()) {
            // تنبيه صوتي رجالي: «اقتربت الصلاة، الرجاء الاستعداد»
            if (getResources().getIdentifier("pre_voice", "raw", getPackageName()) != 0) play("pre_voice");
            else speak(ev.optString("voice", "اقتربت الصلاة، الرجاء الاستعداد"));
        } else {
            play(snd);
        }

        // فتح الشاشة تلقائياً فوق التطبيقات (يتطلب إذن «الظهور فوق التطبيقات»)
        launchScreen(full);

        h.removeCallbacks(autoStop);
        h.postDelayed(autoStop, 12 * 60 * 1000L);
        return START_NOT_STICKY;
    }

    private void launchScreen(final Intent full) {
        try {
            if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) { startActivity(full); return; }
            // أندرويد 15+: يلزم وجود نافذة ظاهرة فوق التطبيقات لحظة فتح الشاشة
            final android.view.WindowManager wm = (android.view.WindowManager) getSystemService(Context.WINDOW_SERVICE);
            final android.view.View dot = new android.view.View(this);
            int type = Build.VERSION.SDK_INT >= 26 ? android.view.WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    : android.view.WindowManager.LayoutParams.TYPE_PHONE;
            android.view.WindowManager.LayoutParams lp = new android.view.WindowManager.LayoutParams(1, 1, type,
                    android.view.WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | android.view.WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                    android.graphics.PixelFormat.TRANSLUCENT);
            boolean added = false;
            try { if (wm != null) { wm.addView(dot, lp); added = true; } } catch (Exception ignored) {}
            final boolean wasAdded = added;
            h.postDelayed(new Runnable() { public void run() {
                try { startActivity(full); } catch (Exception ignored) {}
                h.postDelayed(new Runnable() { public void run() {
                    if (wasAdded) try { wm.removeView(dot); } catch (Exception ignored) {}
                } }, 1500);
            } }, 120);
        } catch (Exception e) {
            try { startActivity(full); } catch (Exception ignored) {}
        }
    }

    private void ensureChannel() {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null || nm.getNotificationChannel(CH) != null) return;
        NotificationChannel ch = new NotificationChannel(CH, "شاشة الأذان والإقامة", NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription("عرض شاشة الأذان والإقامة وتشغيل الصوت");
        ch.setSound(null, null);
        ch.enableVibration(true);
        ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(ch);
    }

    private void play(String sound) {
        releasePlayer();
        try {
            mp = new MediaPlayer();
            mp.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build());
            int rid = sound == null || sound.isEmpty() ? 0 : getResources().getIdentifier(sound, "raw", getPackageName());
            Uri u = rid != 0 ? Uri.parse("android.resource://" + getPackageName() + "/" + rid)
                    : RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            if (u == null) { playing = false; return; }
            mp.setDataSource(this, u);
            mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                public void onCompletion(MediaPlayer m) { onAudioDone(); }
            });
            mp.prepare();
            mp.start();
            playing = true;
            startVolumeSession();
        } catch (Exception e) {
            onAudioDone();
        }
    }

    /** نطق التنبيه بمحرك النطق في الهاتف إن لم يتوفر التسجيل الصوتي */
    private void speak(final String text) {
        try {
            tts = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
                @Override
                public void onInit(int status) {
                    if (status != TextToSpeech.SUCCESS || tts == null) { onAudioDone(); return; }
                    int r = tts.setLanguage(new Locale("ar"));
                    if (r < 0) { onAudioDone(); return; }
                    tts.setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());
                    tts.setSpeechRate(0.9f);
                    tts.setPitch(0.85f);
                    tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                        @Override public void onStart(String id) {}
                        @Override public void onDone(String id) { h.post(new Runnable() { public void run() { onAudioDone(); } }); }
                        @Override public void onError(String id) { h.post(new Runnable() { public void run() { onAudioDone(); } }); }
                    });
                    tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "pre");
                    playing = true;
                    startVolumeSession();
                }
            });
        } catch (Exception e) {
            onAudioDone();
        }
    }

    /** أزرار الصوت في الجهاز تتحكم في مستوى صوت الأذان (قناة المنبّه) أثناء التشغيل */
    private void startVolumeSession() {
        try {
            final AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            if (am == null) return;
            final int max = am.getStreamMaxVolume(AudioManager.STREAM_ALARM);
            ms = new MediaSession(this, "adhan");
            VolumeProvider vp = new VolumeProvider(VolumeProvider.VOLUME_CONTROL_ABSOLUTE, max, am.getStreamVolume(AudioManager.STREAM_ALARM)) {
                @Override
                public void onAdjustVolume(int direction) {
                    am.adjustStreamVolume(AudioManager.STREAM_ALARM, direction, AudioManager.FLAG_SHOW_UI);
                    setCurrentVolume(am.getStreamVolume(AudioManager.STREAM_ALARM));
                }
                @Override
                public void onSetVolumeTo(int volume) {
                    am.setStreamVolume(AudioManager.STREAM_ALARM, Math.max(0, Math.min(max, volume)), AudioManager.FLAG_SHOW_UI);
                    setCurrentVolume(am.getStreamVolume(AudioManager.STREAM_ALARM));
                }
            };
            ms.setPlaybackToRemote(vp);
            // أزرار الوسائط/السماعة لا توقف الأذان؛ أزرار الصوت تغيّر المستوى فقط
            ms.setCallback(new MediaSession.Callback() {});
            ms.setPlaybackState(new PlaybackState.Builder()
                    .setActions(0)
                    .setState(PlaybackState.STATE_PLAYING, 0, 1f)
                    .build());
            ms.setActive(true);
        } catch (Exception ignored) {}
    }

    private void onAudioDone() {
        releasePlayer();
        releaseSession();
        try {
            if (Build.VERSION.SDK_INT >= 24) stopForeground(Service.STOP_FOREGROUND_REMOVE);
            else stopForeground(true);
        } catch (Exception ignored) {}
        stopSelf();
    }

    private void releasePlayer() {
        playing = false;
        if (tts != null) {
            try { tts.stop(); tts.shutdown(); } catch (Exception ignored) {}
            tts = null;
        }
        if (mp != null) {
            try { mp.stop(); } catch (Exception ignored) {}
            try { mp.release(); } catch (Exception ignored) {}
            mp = null;
        }
    }

    private void releaseSession() {
        if (ms != null) {
            try { ms.setActive(false); ms.release(); } catch (Exception ignored) {}
            ms = null;
        }
    }

    void stopAll() {
        h.removeCallbacksAndMessages(null);
        onAudioDone();
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.cancel(NID);
        currentEv = null;
    }

    @Override
    public void onDestroy() {
        releasePlayer();
        releaseSession();
        h.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
