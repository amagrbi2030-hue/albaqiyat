package com.albaqiyat.app;

public class WMinimalWidget extends BaseWidget {
    @Override
    protected String kind() { return "minimal"; }
}
