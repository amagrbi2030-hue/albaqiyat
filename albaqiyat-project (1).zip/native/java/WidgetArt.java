package com.albaqiyat.app;

import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.Bundle;

/** رسم خلفيات الودجت بألوان الثيم: تدرّج + زخرفة نجوم ثمانية شبه شفافة + هلال ذهبي رقيق */
public class WidgetArt {
    public static final int THEME = 0, GLASS = 1, SKY = 2, MINIMAL = 3, PHASE = 4, MIHRAB = 5, ROYAL = 6, SUN = 7;

    static int alpha(int c, int a) { return (c & 0x00FFFFFF) | (a << 24); }

    static int mix(int a, int b, float t) {
        int r = (int) (Color.red(a) + (Color.red(b) - Color.red(a)) * t);
        int g = (int) (Color.green(a) + (Color.green(b) - Color.green(a)) * t);
        int bl = (int) (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t);
        return Color.rgb(r, g, bl);
    }

    static int[] sky(String k) {
        if ("fajr".equals(k)) return new int[]{0xFF1B2350, 0xFF6A4C7E};
        if ("dhuhr".equals(k)) return new int[]{0xFF1F5C8A, 0xFF4F8DB8};
        if ("asr".equals(k)) return new int[]{0xFF7A5222, 0xFFB98838};
        if ("maghrib".equals(k)) return new int[]{0xFF3A1E4A, 0xFFB0543C};
        return new int[]{0xFF07122A, 0xFF16304F};
    }

    static Path star8(float cx, float cy, float R) {
        Path p = new Path();
        float r = R * 0.72f;
        for (int i = 0; i < 16; i++) {
            double a = Math.PI / 8 * i - Math.PI / 2;
            float rad = i % 2 == 0 ? R : r;
            float x = (float) (cx + rad * Math.cos(a)), y = (float) (cy + rad * Math.sin(a));
            if (i == 0) p.moveTo(x, y); else p.lineTo(x, y);
        }
        p.close();
        return p;
    }

    static int[] phaseSky(String p) {
        if ("fajr".equals(p)) return new int[]{0xFF1B2452, 0xFF5B4A86, 0xFFD99A8C};
        if ("morning".equals(p)) return new int[]{0xFF3D7EC2, 0xFF7FB6E3, 0xFFF4D9A0};
        if ("dhuhr".equals(p)) return new int[]{0xFF1E6FB8, 0xFF4FA3DE, 0xFFA8D8F2};
        if ("sunset".equals(p)) return new int[]{0xFF3B2150, 0xFFB4513E, 0xFFF2A65A};
        return new int[]{0xFF050A1C, 0xFF0D1E3D, 0xFF1C3358};
    }

    /** خلفيات الويدجت الجديدة: سماء حسب الوقت، محراب، ملكي، شمس */
    public static Bitmap bg2(Context c, Bundle opts, int defWdp, int defHdp, int style, WidgetModel m) {
        float d = c.getResources().getDisplayMetrics().density;
        int wdp = 0, hdp = 0;
        if (opts != null) {
            wdp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0);
            hdp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0);
        }
        if (wdp <= 0) wdp = defWdp;
        if (hdp <= 0) hdp = defHdp;
        float scale = Math.min(1f, 900f / (Math.max(wdp, hdp) * d));
        float k = d * scale;
        int w = Math.max(40, (int) (wdp * k)), h = Math.max(40, (int) (hdp * k));
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        float rad = 24 * k;
        RectF rect = new RectF(0, 0, w, h);
        Path clip = new Path();
        clip.addRoundRect(rect, rad, rad, Path.Direction.CW);
        cv.clipPath(clip);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        int gold = m.gold;
        boolean night = "night".equals(m.phase);

        if (style == PHASE || style == SUN) {
            int[] sk = phaseSky(m.phase);
            p.setShader(new LinearGradient(0, 0, 0, h, sk, null, Shader.TileMode.CLAMP));
            cv.drawRect(rect, p);
            if (night) {
                Paint st = new Paint(Paint.ANTI_ALIAS_FLAG);
                java.util.Random rnd = new java.util.Random(7);
                for (int i = 0; i < 46; i++) {
                    st.setColor(alpha(0xFFFFFFFF, 60 + rnd.nextInt(140)));
                    cv.drawCircle(rnd.nextFloat() * w, rnd.nextFloat() * h * 0.75f, (0.6f + rnd.nextFloat() * 1.3f) * k, st);
                }
            }
        } else if (style == ROYAL) {
            p.setShader(new LinearGradient(0, 0, w, h, new int[]{0xFF06281B, 0xFF0B3A27, 0xFF125536}, null, Shader.TileMode.CLAMP));
            cv.drawRect(rect, p);
            gold = 0xFFD8B45A;
        } else { // MIHRAB
            p.setShader(new LinearGradient(0, 0, w, h, mix(m.c2, 0xFF000000, 0.25f), m.c1, Shader.TileMode.CLAMP));
            cv.drawRect(rect, p);
        }

        // زخرفة نجوم ثمانية خافتة
        if (style == ROYAL || style == MIHRAB) {
            Paint sp = new Paint(Paint.ANTI_ALIAS_FLAG);
            sp.setStyle(Paint.Style.STROKE);
            sp.setStrokeWidth(Math.max(1f, 0.9f * k));
            sp.setColor(alpha(gold, 0x1A));
            float step = 40 * k;
            for (float y = -step / 2; y < h + step; y += step)
                for (float x = (((int) (y / step)) % 2 == 0 ? 0 : step / 2); x < w + step; x += step)
                    cv.drawPath(star8(x, y, step * 0.38f), sp);
        }
        // توهّج
        Paint g = new Paint(Paint.ANTI_ALIAS_FLAG);
        g.setShader(new RadialGradient(w * 0.5f, h * 0.42f, Math.max(w, h) * 0.55f, alpha(night ? 0xFFFFFFFF : gold, night ? 0x10 : 0x2A), 0, Shader.TileMode.CLAMP));
        cv.drawRect(rect, g);

        if (style == MIHRAB) {
            // قوس المحراب المزدوج
            Paint ap = new Paint(Paint.ANTI_ALIAS_FLAG);
            ap.setStyle(Paint.Style.STROKE);
            ap.setStrokeWidth(Math.max(1.2f, 1.6f * k));
            ap.setColor(alpha(gold, 0xB0));
            for (int j = 0; j < 2; j++) {
                float in = (12 + j * 9) * k;
                float top = (20 + j * 9) * k;
                Path a = new Path();
                a.moveTo(in, h - in);
                a.lineTo(in, h * 0.42f);
                a.cubicTo(in, h * 0.2f, w * 0.38f, top + h * 0.06f, w / 2f, top);
                a.cubicTo(w * 0.62f, top + h * 0.06f, w - in, h * 0.2f, w - in, h * 0.42f);
                a.lineTo(w - in, h - in);
                if (j == 1) ap.setColor(alpha(gold, 0x55));
                cv.drawPath(a, ap);
            }
            Paint sf = new Paint(Paint.ANTI_ALIAS_FLAG);
            sf.setColor(alpha(gold, 0xC0));
            cv.drawPath(star8(w / 2f, 12 * k, 6 * k), sf);
        }

        if (style == ROYAL) {
            // هلال في الزاوية + إطار مزدوج
            float R = Math.min(w, h) * 0.13f;
            float cx = w - R * 1.6f, cy = R * 1.6f;
            Path a = new Path(); a.addCircle(cx, cy, R, Path.Direction.CW);
            Path bb = new Path(); bb.addCircle(cx - R * 0.42f, cy - R * 0.2f, R * 0.88f, Path.Direction.CW);
            a.op(bb, Path.Op.DIFFERENCE);
            Paint cp = new Paint(Paint.ANTI_ALIAS_FLAG);
            cp.setColor(alpha(gold, 0x99));
            cv.drawPath(a, cp);
            Paint ip = new Paint(Paint.ANTI_ALIAS_FLAG);
            ip.setStyle(Paint.Style.STROKE);
            ip.setStrokeWidth(Math.max(1f, 0.8f * k));
            ip.setColor(alpha(gold, 0x55));
            float ins2 = 7 * k;
            cv.drawRoundRect(new RectF(ins2, ins2, w - ins2, h - ins2), rad - ins2, rad - ins2, ip);
        }

        if (style == SUN) {
            // قوس الشمس من الشروق إلى الغروب
            float ax = 22 * k, ay = h * 0.62f, aw = w - 2 * ax, ah = h * 0.42f;
            RectF arc = new RectF(ax, ay - ah, ax + aw, ay + ah);
            Paint ap = new Paint(Paint.ANTI_ALIAS_FLAG);
            ap.setStyle(Paint.Style.STROKE);
            ap.setStrokeWidth(Math.max(1.2f, 1.5f * k));
            ap.setColor(alpha(0xFFFFFFFF, 0x66));
            ap.setPathEffect(new android.graphics.DashPathEffect(new float[]{5 * k, 5 * k}, 0));
            cv.drawArc(arc, 180, 180, false, ap);
            Paint hz = new Paint(Paint.ANTI_ALIAS_FLAG);
            hz.setColor(alpha(gold, 0x88));
            hz.setStrokeWidth(Math.max(1f, 1f * k));
            cv.drawLine(ax - 8 * k, ay, ax + aw + 8 * k, ay, hz);
            long now = System.currentTimeMillis();
            float f;
            boolean day = m.sunrise > 0 && m.sunset > m.sunrise && now >= m.sunrise && now <= m.sunset;
            if (day) f = (now - m.sunrise) / (float) (m.sunset - m.sunrise);
            else f = 0.5f;
            double ang = Math.PI * (1 - f); // من اليسار إلى اليمين
            float sx = (float) (ax + aw / 2 + Math.cos(ang) * aw / 2);
            float sy = (float) (ay - Math.sin(ang) * ah);
            Paint sun = new Paint(Paint.ANTI_ALIAS_FLAG);
            if (day) {
                sun.setShader(new RadialGradient(sx, sy, 22 * k, new int[]{0xFFFFF4C2, 0xFFF6C447, 0x00F6C447}, new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP));
                cv.drawCircle(sx, sy, 22 * k, sun);
            } else {
                Path mo = new Path(); mo.addCircle(sx, sy, 10 * k, Path.Direction.CW);
                Path cut = new Path(); cut.addCircle(sx + 5 * k, sy - 3 * k, 9 * k, Path.Direction.CW);
                mo.op(cut, Path.Op.DIFFERENCE);
                sun.setColor(0xFFF3E7B8);
                cv.drawPath(mo, sun);
            }
        }

        Paint bp = new Paint(Paint.ANTI_ALIAS_FLAG);
        bp.setStyle(Paint.Style.STROKE);
        bp.setStrokeWidth(Math.max(1f, 1.2f * k));
        bp.setColor(alpha(gold, style == PHASE || style == SUN ? 0x55 : 0x99));
        float ins = bp.getStrokeWidth() / 2;
        cv.drawRoundRect(new RectF(ins, ins, w - ins, h - ins), rad - ins, rad - ins, bp);
        return b;
    }

    public static Bitmap bg(Context c, Bundle opts, int defWdp, int defHdp, int style, WidgetModel m, String skyKey, boolean crescent) {
        float d = c.getResources().getDisplayMetrics().density;
        int wdp = 0, hdp = 0;
        if (opts != null) {
            wdp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0);
            hdp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0);
        }
        if (wdp <= 0) wdp = defWdp;
        if (hdp <= 0) hdp = defHdp;
        float scale = Math.min(1f, 900f / (Math.max(wdp, hdp) * d));
        float k = d * scale;
        int w = Math.max(40, (int) (wdp * k)), h = Math.max(40, (int) (hdp * k));
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        float rad = 24 * k;
        RectF rect = new RectF(0, 0, w, h);
        Path clip = new Path();
        clip.addRoundRect(rect, rad, rad, Path.Direction.CW);
        cv.clipPath(clip);

        int c1, c2;
        if (style == GLASS) { c1 = alpha(mix(m.c2, 0xFF000000, 0.35f), 0xC8); c2 = alpha(mix(m.c1, 0xFF000000, 0.2f), 0xB0); }
        else if (style == SKY) { int[] s = sky(skyKey); c1 = s[0]; c2 = s[1]; }
        else if (style == MINIMAL) { c1 = m.c1; c2 = mix(m.c1, m.c2, 0.6f); }
        else { c1 = mix(m.c2, 0xFF000000, 0.15f); c2 = m.c1; }
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new LinearGradient(0, 0, w, h, c1, c2, Shader.TileMode.CLAMP));
        cv.drawRect(rect, p);

        // توهّج ذهبي ناعم
        Paint g = new Paint(Paint.ANTI_ALIAS_FLAG);
        g.setShader(new RadialGradient(w * 0.85f, h * 0.1f, Math.max(w, h) * 0.6f, alpha(m.gold, style == MINIMAL ? 0x18 : 0x30), 0, Shader.TileMode.CLAMP));
        cv.drawRect(rect, g);

        // زخرفة نجوم ثمانية
        if (style != MINIMAL) {
            Paint sp = new Paint(Paint.ANTI_ALIAS_FLAG);
            sp.setStyle(Paint.Style.STROKE);
            sp.setStrokeWidth(Math.max(1f, 1.1f * k));
            sp.setColor(alpha(m.gold, style == GLASS ? 0x1C : 0x16));
            float step = 54 * k;
            for (float y = -step / 2; y < h + step; y += step)
                for (float x = (((int) (y / step)) % 2 == 0 ? 0 : step / 2); x < w + step; x += step)
                    cv.drawPath(star8(x, y, step * 0.36f), sp);
        }

        // هلال ذهبي رقيق
        if (crescent) {
            float R = Math.min(w, h) * 0.32f;
            float cx = w * 0.12f, cy = h * 0.22f;
            Path a = new Path(); a.addCircle(cx, cy, R, Path.Direction.CW);
            Path bb = new Path(); bb.addCircle(cx + R * 0.42f, cy - R * 0.18f, R * 0.92f, Path.Direction.CW);
            a.op(bb, Path.Op.DIFFERENCE);
            Paint cp = new Paint(Paint.ANTI_ALIAS_FLAG);
            cp.setColor(alpha(m.gold, 0x2E));
            cv.drawPath(a, cp);
        }

        // إطار ذهبي رقيق
        Paint bp = new Paint(Paint.ANTI_ALIAS_FLAG);
        bp.setStyle(Paint.Style.STROKE);
        bp.setStrokeWidth(Math.max(1f, 1.2f * k));
        bp.setColor(alpha(m.gold, style == MINIMAL ? 0x40 : 0x8C));
        float ins = bp.getStrokeWidth() / 2;
        cv.drawRoundRect(new RectF(ins, ins, w - ins, h - ins), rad - ins, rad - ins, bp);
        if (style == GLASS) {
            Paint hi = new Paint(Paint.ANTI_ALIAS_FLAG);
            hi.setShader(new LinearGradient(0, 0, 0, h * 0.45f, 0x22FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
            cv.drawRect(rect, hi);
        }
        return b;
    }
}
