package com.albaqiyat.app;

import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.Bundle;

/** رسم خلفيات الودجت بألوان الثيم: تدرّج + زخرفة نجوم ثمانية شبه شفافة + هلال ذهبي رقيق */
public class WidgetArt {
    public static final int THEME = 0, GLASS = 1, SKY = 2, MINIMAL = 3;

    static int alpha(int c, int a) { return (c & 0x00FFFFFF) | (a << 24); }

    static int mix(int a, int b, float t) {
        int r = (int) (Color.red(a) + (Color.red(b) - Color.red(a)) * t);
        int g = (int) (Color.green(a) + (Color.green(b) - Color.green(a)) * t);
        int bl = (int) (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t);
        return Color.rgb(r, g, bl);
    }

    static int[] sky(String k) {
        if ("fajr".equals(k)) return new int[]{0xFF1B2350, 0xFF6A4C7E};
        if ("dhuhr".equals(k)) return new int[]{0xFF1F5C8A, 0xFF4F8DB8};
        if ("asr".equals(k)) return new int[]{0xFF7A5222, 0xFFB98838};
        if ("maghrib".equals(k)) return new int[]{0xFF3A1E4A, 0xFFB0543C};
        return new int[]{0xFF07122A, 0xFF16304F};
    }

    static Path star8(float cx, float cy, float R) {
        Path p = new Path();
        float r = R * 0.72f;
        for (int i = 0; i < 16; i++) {
            double a = Math.PI / 8 * i - Math.PI / 2;
            float rad = i % 2 == 0 ? R : r;
            float x = (float) (cx + rad * Math.cos(a)), y = (float) (cy + rad * Math.sin(a));
            if (i == 0) p.moveTo(x, y); else p.lineTo(x, y);
        }
        p.close();
        return p;
    }

    public static Bitmap bg(Context c, Bundle opts, int defWdp, int defHdp, int style, WidgetModel m, String skyKey, boolean crescent) {
        float d = c.getResources().getDisplayMetrics().density;
        int wdp = 0, hdp = 0;
        if (opts != null) {
            wdp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0);
            hdp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0);
        }
        if (wdp <= 0) wdp = defWdp;
        if (hdp <= 0) hdp = defHdp;
        float scale = Math.min(1f, 900f / (Math.max(wdp, hdp) * d));
        float k = d * scale;
        int w = Math.max(40, (int) (wdp * k)), h = Math.max(40, (int) (hdp * k));
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        float rad = 24 * k;
        RectF rect = new RectF(0, 0, w, h);
        Path clip = new Path();
        clip.addRoundRect(rect, rad, rad, Path.Direction.CW);
        cv.clipPath(clip);

        int c1, c2;
        if (style == GLASS) { c1 = alpha(mix(m.c2, 0xFF000000, 0.35f), 0xC8); c2 = alpha(mix(m.c1, 0xFF000000, 0.2f), 0xB0); }
        else if (style == SKY) { int[] s = sky(skyKey); c1 = s[0]; c2 = s[1]; }
        else if (style == MINIMAL) { c1 = m.c1; c2 = mix(m.c1, m.c2, 0.6f); }
        else { c1 = mix(m.c2, 0xFF000000, 0.15f); c2 = m.c1; }
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new LinearGradient(0, 0, w, h, c1, c2, Shader.TileMode.CLAMP));
        cv.drawRect(rect, p);

        // توهّج ذهبي ناعم
        Paint g = new Paint(Paint.ANTI_ALIAS_FLAG);
        g.setShader(new RadialGradient(w * 0.85f, h * 0.1f, Math.max(w, h) * 0.6f, alpha(m.gold, style == MINIMAL ? 0x18 : 0x30), 0, Shader.TileMode.CLAMP));
        cv.drawRect(rect, g);

        // زخرفة نجوم ثمانية
        if (style != MINIMAL) {
            Paint sp = new Paint(Paint.ANTI_ALIAS_FLAG);
            sp.setStyle(Paint.Style.STROKE);
            sp.setStrokeWidth(Math.max(1f, 1.1f * k));
            sp.setColor(alpha(m.gold, style == GLASS ? 0x1C : 0x16));
            float step = 54 * k;
            for (float y = -step / 2; y < h + step; y += step)
                for (float x = (((int) (y / step)) % 2 == 0 ? 0 : step / 2); x < w + step; x += step)
                    cv.drawPath(star8(x, y, step * 0.36f), sp);
        }

        // هلال ذهبي رقيق
        if (crescent) {
            float R = Math.min(w, h) * 0.32f;
            float cx = w * 0.12f, cy = h * 0.22f;
            Path a = new Path(); a.addCircle(cx, cy, R, Path.Direction.CW);
            Path bb = new Path(); bb.addCircle(cx + R * 0.42f, cy - R * 0.18f, R * 0.92f, Path.Direction.CW);
            a.op(bb, Path.Op.DIFFERENCE);
            Paint cp = new Paint(Paint.ANTI_ALIAS_FLAG);
            cp.setColor(alpha(m.gold, 0x2E));
            cv.drawPath(a, cp);
        }

        // إطار ذهبي رقيق
        Paint bp = new Paint(Paint.ANTI_ALIAS_FLAG);
        bp.setStyle(Paint.Style.STROKE);
        bp.setStrokeWidth(Math.max(1f, 1.2f * k));
        bp.setColor(alpha(m.gold, style == MINIMAL ? 0x40 : 0x8C));
        float ins = bp.getStrokeWidth() / 2;
        cv.drawRoundRect(new RectF(ins, ins, w - ins, h - ins), rad - ins, rad - ins, bp);
        if (style == GLASS) {
            Paint hi = new Paint(Paint.ANTI_ALIAS_FLAG);
            hi.setShader(new LinearGradient(0, 0, 0, h * 0.45f, 0x22FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
            cv.drawRect(rect, hi);
        }
        return b;
    }
}
