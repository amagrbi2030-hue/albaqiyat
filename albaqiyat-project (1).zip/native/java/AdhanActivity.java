package com.albaqiyat.app;

import android.app.Activity;
import android.app.KeyguardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import org.json.JSONObject;

/** شاشة الأذان/الإقامة الكاملة خارج التطبيق، بصورة خاصة لكل صلاة */
public class AdhanActivity extends Activity {
    private final Handler h = new Handler(Looper.getMainLooper());
    private AudioManager am;
    private SeekBar vol;
    private Button stopBtn;
    private String kind = "adhan";
    private static final int GOLD = 0xFFF3D98B;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        }
        Window w = getWindow();
        w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 21) {
            w.setStatusBarColor(Color.TRANSPARENT);
            w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
        setVolumeControlStream(AudioManager.STREAM_ALARM);
        am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        build(getIntent());
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        build(i);
    }

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private static int[] sky(String p) {
        switch (p) {
            case "fajr": return new int[]{0xFF0B1E3F, 0xFF3B3F78, 0xFFC97B8E};
            case "dhuhr": return new int[]{0xFF1C5C8C, 0xFF4E95C2, 0xFFE9D9A6};
            case "asr": return new int[]{0xFF6E4A1E, 0xFFC38A3A, 0xFFF1D592};
            case "maghrib": return new int[]{0xFF2B1640, 0xFFB24A3A, 0xFFF0A35E};
            default: return new int[]{0xFF050B1A, 0xFF0D2340, 0xFF1F3B5C};
        }
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        t.setTypeface(Typeface.create(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL));
        t.setShadowLayer(dp(6), 0, dp(1), 0xCC000000);
        return t;
    }

    private GradientDrawable round(int fill, int stroke, float radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radius));
        if (stroke != 0) g.setStroke(dp(1.2f), stroke);
        return g;
    }

    private void build(Intent in) {
        JSONObject ev;
        try { ev = new JSONObject(in.getStringExtra("ev") == null ? "{}" : in.getStringExtra("ev")); }
        catch (Exception e) { ev = new JSONObject(); }
        String prayer = ev.optString("prayer", "fajr");
        kind = ev.optString("kind", "adhan");

        FrameLayout root = new FrameLayout(this);
        if (Build.VERSION.SDK_INT >= 17) root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        ImageView bg = new ImageView(this);
        bg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        int rid = getResources().getIdentifier("bg_" + prayer, "drawable", getPackageName());
        if (rid != 0) bg.setImageResource(rid);
        else bg.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, sky(prayer)));
        root.addView(bg, new FrameLayout.LayoutParams(-1, -1));

        View shade = new View(this);
        shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0x33000000, 0x00000000, 0x22000000, 0x66000000}));
        root.addView(shade, new FrameLayout.LayoutParams(-1, -1));

        // الصورة كاملة في الأعلى (دون قص)، والنصوص والأزرار تحتها
        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        root.addView(main, new FrameLayout.LayoutParams(-1, -1));
        int ph = getResources().getIdentifier("photo_" + prayer, "drawable", getPackageName());
        if (ph != 0) {
            ImageView photo = new ImageView(this);
            photo.setImageResource(ph);
            photo.setScaleType(ImageView.ScaleType.FIT_CENTER);
            photo.setAdjustViewBounds(true);
            LinearLayout.LayoutParams lph = new LinearLayout.LayoutParams(-1, 0, 1f);
            lph.setMargins(dp(14), dp(34), dp(14), dp(4));
            if (Build.VERSION.SDK_INT >= 21) photo.setElevation(dp(10));
            main.addView(photo, lph);
        } else {
            main.addView(new View(this), new LinearLayout.LayoutParams(-1, 0, 1f));
        }

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(dp(18), dp(16), dp(18), dp(18));
        // لوح زجاجي شفاف خلف النصوص والأزرار
        GradientDrawable glass = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0x40FFFFFF, 0x26FFFFFF, 0x33000000});
        glass.setCornerRadius(dp(28));
        glass.setStroke(dp(1.2f), 0x66FFFFFF);
        col.setBackground(glass);
        LinearLayout.LayoutParams lcol = new LinearLayout.LayoutParams(-1, -2);
        lcol.setMargins(dp(12), dp(6), dp(12), dp(18));
        main.addView(col, lcol);

        String label = "pre".equals(kind) ? "بعد ١٠ دقائق يحين الأذان" : ("iqama".equals(kind) ? "حان وقت الإقامة" : "حان الآن وقت الأذان");
        TextView pill = text("✦  " + label + "  ✦", 15, GOLD, true);
        pill.setBackground(round(0x33000000, 0xCCF3D98B, 99));
        pill.setPadding(dp(18), dp(8), dp(18), dp(8));
        LinearLayout.LayoutParams lpPill = new LinearLayout.LayoutParams(-2, -2);
        lpPill.bottomMargin = dp(8);
        col.addView(pill, lpPill);

        col.addView(text("صلاة " + ev.optString("name", ""), 36, Color.WHITE, true));
        TextView tm = text(ev.optString("time", ""), 26, GOLD, true);
        col.addView(tm);
        String city = ev.optString("city", "");
        if (!city.isEmpty()) col.addView(text(city, 15, 0xDDFFFFFF, false));
        String who = ev.optString("who", "");
        if (!who.isEmpty()) {
            TextView wt = text(("iqama".equals(kind) ? "الإقامة: " : "المؤذن: ") + who, 14, 0xCCFFFFFF, false);
            LinearLayout.LayoutParams lw = new LinearLayout.LayoutParams(-2, -2);
            lw.topMargin = dp(4);
            col.addView(wt, lw);
        }

        // فضل الصلاة
        String fadl = ev.optString("fadl", "");
        if ("pre".equals(kind)) {
            TextView pm = text("اقتربت الصلاة، الرجاء الاستعداد", 17, Color.WHITE, true);
            LinearLayout.LayoutParams lpm = new LinearLayout.LayoutParams(-2, -2);
            lpm.topMargin = dp(10);
            col.addView(pm, lpm);
        }
        if (!fadl.isEmpty()) {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setBackground(round(0x2EFFFFFF, 0x88F3D98B, 18));
            card.setPadding(dp(16), dp(12), dp(16), dp(12));
            TextView fh = text("✦ فضل الصلاة ✦", 12, GOLD, true);
            card.addView(fh, new LinearLayout.LayoutParams(-1, -2));
            TextView ft = text(fadl, 15, Color.WHITE, false);
            ft.setLineSpacing(dp(3), 1f);
            LinearLayout.LayoutParams lft = new LinearLayout.LayoutParams(-1, -2);
            lft.topMargin = dp(6);
            card.addView(ft, lft);
            String fs = ev.optString("fsrc", "");
            if (!fs.isEmpty()) {
                TextView fsv = text(fs, 11, 0xB3FFFFFF, false);
                LinearLayout.LayoutParams lfs = new LinearLayout.LayoutParams(-1, -2);
                lfs.topMargin = dp(4);
                card.addView(fsv, lfs);
            }
            LinearLayout.LayoutParams lc0 = new LinearLayout.LayoutParams(-1, -2);
            lc0.topMargin = dp(10);
            col.addView(card, lc0);
        }

        // مستوى الصوت
        LinearLayout vrow = new LinearLayout(this);
        vrow.setOrientation(LinearLayout.HORIZONTAL);
        vrow.setGravity(Gravity.CENTER_VERTICAL);
        vrow.setBackground(round(0x26FFFFFF, 0x66FFFFFF, 22));
        vrow.setPadding(dp(10), dp(6), dp(10), dp(6));
        Button minus = smallBtn("−");
        Button plus = smallBtn("+");
        vol = new SeekBar(this);
        final int max = am != null ? am.getStreamMaxVolume(AudioManager.STREAM_ALARM) : 7;
        vol.setMax(max);
        if (am != null) vol.setProgress(am.getStreamVolume(AudioManager.STREAM_ALARM));
        vol.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean user) {
                if (user && am != null) am.setStreamVolume(AudioManager.STREAM_ALARM, p, 0);
            }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });
        minus.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { adjust(AudioManager.ADJUST_LOWER); } });
        plus.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { adjust(AudioManager.ADJUST_RAISE); } });
        vrow.addView(plus, new LinearLayout.LayoutParams(dp(44), dp(44)));
        vrow.addView(vol, new LinearLayout.LayoutParams(0, -2, 1));
        vrow.addView(minus, new LinearLayout.LayoutParams(dp(44), dp(44)));
        LinearLayout.LayoutParams lv = new LinearLayout.LayoutParams(-1, -2);
        lv.topMargin = dp(26);
        TextView vl = text("🔊 مستوى الصوت — أو استخدم أزرار الصوت في الجهاز", 12, 0xBBFFFFFF, false);
        LinearLayout.LayoutParams lvl = new LinearLayout.LayoutParams(-2, -2);
        lvl.topMargin = dp(10);
        col.addView(vl, lvl);
        LinearLayout.LayoutParams lv2 = new LinearLayout.LayoutParams(-1, -2);
        lv2.topMargin = dp(8);
        col.addView(vrow, lv2);

        // الأزرار
        stopBtn = new Button(this);
        stopBtn.setText("pre".equals(kind) ? "حسناً" : ("iqama".equals(kind) ? "إيقاف الإقامة" : "إيقاف الأذان"));
        stopBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        stopBtn.setTypeface(Typeface.DEFAULT_BOLD);
        stopBtn.setTextColor(0xFF2A1C04);
        stopBtn.setAllCaps(false);
        GradientDrawable gold = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFFB8892E, 0xFFF3D98B, 0xFFC69A3A});
        gold.setCornerRadius(dp(99));
        stopBtn.setBackground(gold);
        stopBtn.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { stopAndClose(); } });
        LinearLayout.LayoutParams lb = new LinearLayout.LayoutParams(-1, dp(54));
        lb.topMargin = dp(12);
        col.addView(stopBtn, lb);

        Button close = new Button(this);
        close.setText("إغلاق الشاشة");
        close.setAllCaps(false);
        close.setTextColor(Color.WHITE);
        close.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        close.setBackground(round(0x26FFFFFF, 0x99FFFFFF, 99));
        close.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { finish(); } });
        LinearLayout.LayoutParams lc = new LinearLayout.LayoutParams(-1, dp(46));
        lc.topMargin = dp(8);
        col.addView(close, lc);

        setContentView(root);
        h.removeCallbacksAndMessages(null);
        h.post(tick);
    }

    private Button smallBtn(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        b.setTextColor(GOLD);
        b.setPadding(0, 0, 0, 0);
        b.setBackground(round(0x26FFFFFF, 0x99F3D98B, 99));
        return b;
    }

    private void adjust(int dir) {
        if (am == null) return;
        am.adjustStreamVolume(AudioManager.STREAM_ALARM, dir, AudioManager.FLAG_SHOW_UI);
        if (vol != null) vol.setProgress(am.getStreamVolume(AudioManager.STREAM_ALARM));
    }

    private final Runnable tick = new Runnable() {
        public void run() {
            if (am != null && vol != null) vol.setProgress(am.getStreamVolume(AudioManager.STREAM_ALARM));
            if (stopBtn != null && !AdhanService.isPlaying()) stopBtn.setText("إغلاق");
            h.postDelayed(this, 600);
        }
    };

    private void stopAndClose() {
        try {
            Intent s = new Intent(this, AdhanService.class);
            s.setAction("STOP");
            startService(s);
        } catch (Exception ignored) {}
        finish();
    }

    @Override
    protected void onDestroy() {
        h.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
