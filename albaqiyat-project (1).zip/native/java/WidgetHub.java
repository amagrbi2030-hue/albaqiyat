package com.albaqiyat.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;

/** رسم جميع أشكال ودجت أوقات الصلاة */
public class WidgetHub {
    static final String ACTION_MUTE = "com.albaqiyat.app.WIDGET_MUTE";
    static final Class<?>[] CLS = {PrayerWidget.class, WNextWidget.class, WCrescentWidget.class, WTimelineWidget.class,
            WMosqueWidget.class, WGlassWidget.class, WMinimalWidget.class,
            WDayWidget.class, WSkyWidget.class, WMihrabWidget.class, WGlassdayWidget.class, WSunWidget.class, WDualWidget.class,
            WPlineWidget.class, WDaynightWidget.class, WFulldayWidget.class, WWeatherWidget.class, WThreeWidget.class, WRoyalWidget.class};
    static final String[] KINDS = {"full", "next", "crescent", "timeline", "mosque", "glass", "minimal",
            "day", "sky", "mihrab", "glassday", "sun", "dual", "pline", "daynight", "fullday", "weather", "three", "royal"};
    static final int[] NOW = {R.id.w_now0, R.id.w_now1, R.id.w_now2, R.id.w_now3, R.id.w_now4};

    static final int[] CELL = {R.id.w_c0, R.id.w_c1, R.id.w_c2, R.id.w_c3, R.id.w_c4, R.id.w_c5};
    static final int[] NAME = {R.id.w_n0, R.id.w_n1, R.id.w_n2, R.id.w_n3, R.id.w_n4, R.id.w_n5};
    static final int[] TIME = {R.id.w_t0, R.id.w_t1, R.id.w_t2, R.id.w_t3, R.id.w_t4, R.id.w_t5};
    static final int[] DOT = {R.id.w_d0, R.id.w_d1, R.id.w_d2, R.id.w_d3, R.id.w_d4, R.id.w_d5};
    static final int GOLD_TXT = 0xFFF3D98B, WHITE = 0xFFFFFFFF, SOFT = 0xBFFFFFFF, DIM = 0x80FFFFFF;

    static boolean any(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        for (Class<?> k : CLS) {
            int[] ids = m.getAppWidgetIds(new ComponentName(c, k));
            if (ids != null && ids.length > 0) return true;
        }
        return false;
    }

    static void updateAll(Context c) {
        renderAllOnly(c);
        try { WeatherFetcher.maybeFetch(c); } catch (Exception ignored) {}
    }

    static void renderAllOnly(Context c) {
        try {
            AppWidgetManager m = AppWidgetManager.getInstance(c);
            for (int i = 0; i < CLS.length; i++) {
                int[] ids = m.getAppWidgetIds(new ComponentName(c, CLS[i]));
                if (ids == null) continue;
                for (int id : ids) render(c, m, id, KINDS[i]);
            }
        } catch (Exception ignored) {}
        AlarmScheduler.scheduleWidgetTick(c);
    }

    static String nm(JSONObject o) { return o == null ? "" : o.optString("name", ""); }
    static String tm(JSONObject o) { return o == null ? "" : o.optString("s", ""); }
    static String tmShort(JSONObject o) { return o == null ? "" : o.optString("sh", o.optString("s", "")); }

    /** الصلوات الخمس من عناصر اليوم (دون الشروق) مع مواضعها الأصلية */
    static int[] five(JSONArray it) {
        int[] r = new int[5];
        int j = 0;
        if (it != null) for (int i = 0; i < it.length() && j < 5; i++) {
            JSONObject o = it.optJSONObject(i);
            if (o != null && !"sunrise".equals(o.optString("k"))) r[j++] = i;
        }
        for (; j < 5; j++) r[j] = -1;
        return r;
    }

    static void countdown(RemoteViews v, WidgetModel m) {
        if (Build.VERSION.SDK_INT >= 24 && m.ok) {
            v.setViewVisibility(R.id.w_cd, View.VISIBLE);
            v.setChronometer(R.id.w_cd, SystemClock.elapsedRealtime() + (m.target - System.currentTimeMillis()), null, true);
            v.setChronometerCountDown(R.id.w_cd, true);
        } else {
            v.setViewVisibility(R.id.w_cd, View.GONE);
        }
    }

    static PendingIntent openApp(Context c) {
        Intent li = c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
        if (li == null) li = new Intent(c, MainActivity.class);
        return PendingIntent.getActivity(c, 0, li, AlarmScheduler.piFlags());
    }

    static PendingIntent mute(Context c) {
        Intent i = new Intent(c, PrayerWidget.class);
        i.setAction(ACTION_MUTE);
        return PendingIntent.getBroadcast(c, 99002, i, AlarmScheduler.piFlags());
    }

    static void render(Context c, AppWidgetManager mgr, int id, String kind) {
        try {
            WidgetModel m = WidgetModel.load(c);
            Bundle opts = mgr.getAppWidgetOptions(id);
            RemoteViews v;
            switch (kind) {
                case "next": v = next(c, m, opts); break;
                case "crescent": v = crescent(c, m, opts); break;
                case "timeline": v = timeline(c, m, opts); break;
                case "mosque": v = mosque(c, m, opts); break;
                case "glass": v = glass(c, m, opts); break;
                case "minimal": v = minimal(c, m, opts); break;
                case "day": case "sky": case "mihrab": case "glassday": case "sun": case "dual":
                case "pline": case "daynight": case "fullday": case "weather": case "three": case "royal":
                    v = generic(c, m, opts, kind); break;
                default: v = full(c, m, opts);
            }
            v.setOnClickPendingIntent(R.id.w_root, openApp(c));
            if (!m.ok) {
                v.setViewVisibility(R.id.w_content, View.GONE);
                v.setViewVisibility(R.id.w_empty, View.VISIBLE);
            } else {
                v.setViewVisibility(R.id.w_content, View.VISIBLE);
                v.setViewVisibility(R.id.w_empty, View.GONE);
            }
            mgr.updateAppWidget(id, v);
        } catch (Exception ignored) {}
    }

    static void t(RemoteViews v, int id, String s) { v.setTextViewText(id, s == null ? "" : s); }

    // ── الأشكال الجديدة: تعبئة موحّدة (الحقول غير الموجودة في التصميم تُتجاهل تلقائياً) ──
    static RemoteViews generic(Context c, WidgetModel m, Bundle o, String kind) {
        int lay; int style; int dw, dh; boolean v2 = false, cres = false;
        switch (kind) {
            case "day": lay = R.layout.widget_day; style = WidgetArt.THEME; dw = 300; dh = 320; cres = true; break;
            case "sky": lay = R.layout.widget_sky; style = WidgetArt.PHASE; dw = 230; dh = 230; v2 = true; break;
            case "mihrab": lay = R.layout.widget_mihrab; style = WidgetArt.MIHRAB; dw = 220; dh = 300; v2 = true; break;
            case "glassday": lay = R.layout.widget_glassday; style = WidgetArt.GLASS; dw = 220; dh = 300; cres = true; break;
            case "sun": lay = R.layout.widget_sun; style = WidgetArt.SUN; dw = 300; dh = 220; v2 = true; break;
            case "dual": lay = R.layout.widget_dual; style = WidgetArt.THEME; dw = 160; dh = 180; break;
            case "pline": lay = R.layout.widget_pline; style = WidgetArt.THEME; dw = 320; dh = 170; break;
            case "daynight": lay = R.layout.widget_daynight; style = WidgetArt.PHASE; dw = 230; dh = 230; v2 = true; break;
            case "fullday": lay = R.layout.widget_fullday; style = WidgetArt.THEME; dw = 300; dh = 400; cres = true; break;
            case "weather": lay = R.layout.widget_weather; style = WidgetArt.PHASE; dw = 230; dh = 250; v2 = true; break;
            case "three": lay = R.layout.widget_three; style = WidgetArt.GLASS; dw = 300; dh = 320; cres = true; break;
            default: lay = R.layout.widget_royal; style = WidgetArt.ROYAL; dw = 300; dh = 320; v2 = true;
        }
        RemoteViews v = new RemoteViews(c.getPackageName(), lay);
        v.setImageViewBitmap(R.id.w_bg, v2 ? WidgetArt.bg2(c, o, dw, dh, style, m) : WidgetArt.bg(c, o, dw, dh, style, m, null, cres));
        if (!m.ok) return v;
        String wd = m.d("wd"), hj = m.d("hj"), gr = m.d("gr");
        t(v, R.id.w_wd, wd); t(v, R.id.w_hj, hj); t(v, R.id.w_gr, gr);
        t(v, R.id.w_hjd, m.d("hjd")); t(v, R.id.w_hjm, m.d("hjm")); t(v, R.id.w_hjy, m.d("hjy"));
        t(v, R.id.w_grd, m.d("grd")); t(v, R.id.w_grm, m.d("grm")); t(v, R.id.w_gry, m.d("gry"));
        t(v, R.id.w_wdhj, wd + " " + hj); t(v, R.id.w_wdgr, wd + " " + gr); t(v, R.id.w_wdp, "📅 " + wd);
        t(v, R.id.w_city, m.city); t(v, R.id.w_cityp, "📍 " + m.city);
        t(v, R.id.w_temp, m.wx ? m.temp : "؟°");
        t(v, R.id.w_wdesc, m.wx ? m.wdesc : "لا يوجد اتصال");
        t(v, R.id.w_wemoji, m.wx ? m.wemoji : "؟");
        t(v, R.id.w_wxs, "royal".equals(kind) ? ((m.wx ? m.wemoji : "؟") + "\n" + (m.wx ? m.temp : "؟°")) : ((m.wx ? m.wemoji + " " + m.temp : "؟°")));
        t(v, R.id.w_minmax, m.wx && !m.minmax.isEmpty() ? m.minmax : "العظمى ؟° | الصغرى ؟°");
        t(v, R.id.w_wxline, m.wx ? m.wemoji + " " + m.temp + " — " + m.wdesc : "؟° — لا يوجد اتصال");
        t(v, R.id.w_wxcity, (m.wx ? m.wemoji + " " + m.temp : "؟°") + " — " + m.city);
        JSONObject sp = shownPrayer(m);
        String tt = m.iqPhase ? sp.optString("iqs", "") : tm(sp);
        t(v, R.id.w_lbl, m.iqPhase ? "وقت الإقامة" : "الصلاة القادمة");
        t(v, R.id.w_name, (m.iqPhase ? "إقامة " : "") + nm(sp));
        t(v, R.id.w_nameic, "🕌 " + (m.iqPhase ? "إقامة " : "") + nm(sp));
        t(v, R.id.w_time, tt);
        String nl = ("dual".equals(kind) || "sky".equals(kind) || "daynight".equals(kind)) ? nm(sp) + " " + tt : "🕌 " + nm(sp) + " — " + tt;
        if (m.iqPhase) nl = "⏱ إقامة " + nm(sp) + " " + tt;
        t(v, R.id.w_next_line, nl);
        t(v, R.id.w_cdl, "fullday".equals(kind) ? (m.iqPhase ? "إقامة " + nm(sp) + " بعد " : nm(sp) + " بعد ") : label(m) + " ");
        countdown(v, m);
        v.setProgressBar(R.id.w_prog, 1000, m.progress(), false);
        t(v, R.id.w_rise, "الشروق " + tm(m.item("sunrise")));
        t(v, R.id.w_set, "الغروب " + tm(m.item("maghrib")));
        t(v, R.id.w_fajr, "الفجر " + tm(m.item("fajr")));
        t(v, R.id.w_isha, "العشاء " + tm(m.item("isha")));
        if ("sun".equals(kind)) t(v, R.id.w_temp, m.wx ? m.temp + " C" : "؟°");
        boolean day = m.isDay();
        t(v, R.id.w_greet, day ? "صباح الخير" : "مساء الخير");
        t(v, R.id.w_gemoji, "fajr".equals(m.phase) ? "🌅" : day ? "☀️" : ("sunset".equals(m.phase) ? "🌇" : "🌙"));
        JSONArray it = m.items();
        long now = System.currentTimeMillis();
        if ("fullday".equals(kind)) {
            for (int i = 0; i < 6; i++) {
                JSONObject p = it != null && i < it.length() ? it.optJSONObject(i) : null;
                t(v, NAME[i], nm(p)); t(v, TIME[i], tm(p));
                boolean hl = i == (m.iqPhase ? m.curIdx : m.nextIdx);
                v.setInt(CELL[i], "setBackgroundResource", hl ? R.drawable.w_hl : R.drawable.w_none);
                v.setTextColor(NAME[i], hl ? GOLD_TXT : SOFT);
                v.setTextColor(TIME[i], hl ? GOLD_TXT : WHITE);
            }
        } else {
            int[] f = five(it);
            boolean dots = "pline".equals(kind) || "royal".equals(kind);
            for (int j = 0; j < 5; j++) {
                JSONObject p = f[j] >= 0 ? it.optJSONObject(f[j]) : null;
                t(v, NAME[j], nm(p)); t(v, TIME[j], tmShort(p));
                boolean isNext = f[j] >= 0 && f[j] == m.nextIdx && !m.iqPhase;
                boolean isCur = f[j] >= 0 && f[j] == m.curIdx;
                boolean past = p != null && p.optLong("at") <= now;
                v.setTextColor(NAME[j], isNext ? GOLD_TXT : (isCur ? WHITE : (past && dots ? DIM : SOFT)));
                v.setTextColor(TIME[j], isNext ? GOLD_TXT : (past && dots && !isCur ? DIM : WHITE));
                if (dots) {
                    v.setImageViewResource(DOT[j], isCur ? R.drawable.w_dot_cur : (isNext ? R.drawable.w_dot_next : (past ? R.drawable.w_dot_past : R.drawable.w_dot_off)));
                    v.setViewVisibility(NOW[j], isCur || (m.curIdx < 0 && isNext) ? View.VISIBLE : View.INVISIBLE);
                } else {
                    v.setInt(CELL[j], "setBackgroundResource", isNext ? R.drawable.w_hl : (isCur ? R.drawable.w_cur : R.drawable.w_cell));
                }
            }
        }
        return v;
    }

    static String label(WidgetModel m) { return m.iqPhase ? "الإقامة بعد" : "متبقي"; }
    static JSONObject shownPrayer(WidgetModel m) { return m.iqPhase ? m.cur : m.next; }

    // ── ١. الشامل (الموصى به) ──
    static RemoteViews full(Context c, WidgetModel m, Bundle o) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_full);
        v.setImageViewBitmap(R.id.w_bg, WidgetArt.bg(c, o, 300, 300, WidgetArt.THEME, m, null, true));
        if (!m.ok) return v;
        JSONObject sp = shownPrayer(m);
        v.setTextViewText(R.id.w_city, m.city);
        v.setTextViewText(R.id.w_date, m.day != null ? m.day.optString("greg", "") : "");
        v.setTextViewText(R.id.w_lbl, m.iqPhase ? "وقت الإقامة" : "الصلاة القادمة");
        v.setTextViewText(R.id.w_name, nm(sp));
        v.setTextViewText(R.id.w_time, m.iqPhase ? sp.optString("iqs", "") : tm(sp));
        v.setTextViewText(R.id.w_cdl, label(m) + " ");
        countdown(v, m);
        JSONArray it = m.items();
        int[] f = five(it);
        for (int j = 0; j < 5; j++) {
            JSONObject p = f[j] >= 0 ? it.optJSONObject(f[j]) : null;
            v.setTextViewText(NAME[j], nm(p));
            v.setTextViewText(TIME[j], tmShort(p));
            boolean isNext = f[j] >= 0 && f[j] == m.nextIdx && !m.iqPhase;
            boolean isCur = f[j] >= 0 && f[j] == m.curIdx;
            v.setInt(CELL[j], "setBackgroundResource", isNext ? R.drawable.w_hl : (isCur ? R.drawable.w_cur : R.drawable.w_cell));
            v.setTextColor(NAME[j], isNext ? GOLD_TXT : (isCur ? WHITE : SOFT));
            v.setTextColor(TIME[j], isNext ? GOLD_TXT : WHITE);
        }
        String k = sp != null ? sp.optString("k") : "";
        v.setTextViewText(R.id.w_adh, m.muted ? "🔕 الأذان صامت" : ("🔔 الأذان " + (m.alertOn("adhan", k) ? "مفعّل" : "معطّل")));
        v.setTextViewText(R.id.w_iq, "⏱ الإقامة " + (m.iqPhase ? "بعد قليل" : (m.alertOn("iqama", k) ? "مفعّلة" : "معطّلة")));
        v.setTextViewText(R.id.w_bell, m.muted ? "🔕" : "🔔");
        v.setOnClickPendingIntent(R.id.w_bell, mute(c));
        return v;
    }

    // ── ٢. الصلاة القادمة الفاخر ──
    static RemoteViews next(Context c, WidgetModel m, Bundle o) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_next);
        v.setImageViewBitmap(R.id.w_bg, WidgetArt.bg(c, o, 300, 160, WidgetArt.GLASS, m, null, true));
        if (!m.ok) return v;
        JSONObject sp = shownPrayer(m);
        v.setTextViewText(R.id.w_lbl, m.iqPhase ? "✦ وقت الإقامة" : "✦ الصلاة القادمة");
        v.setTextViewText(R.id.w_name, nm(sp));
        v.setTextViewText(R.id.w_time, "🕐 " + (m.iqPhase ? sp.optString("iqs", "") : tm(sp)));
        v.setTextViewText(R.id.w_cdl, label(m) + " ");
        countdown(v, m);
        v.setProgressBar(R.id.w_prog, 1000, m.progress(), false);
        v.setTextViewText(R.id.w_from, m.iqPhase ? "الأذان" : (m.cur != null ? nm(m.cur) : ""));
        v.setTextViewText(R.id.w_to, m.iqPhase ? "الإقامة" : nm(m.next));
        return v;
    }

    // ── ٣. الهلال والصلوات ──
    static RemoteViews crescent(Context c, WidgetModel m, Bundle o) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_crescent);
        JSONObject sp = shownPrayer(m);
        String skyKey = m.cur != null ? m.cur.optString("k") : (sp != null ? sp.optString("k") : "isha");
        v.setImageViewBitmap(R.id.w_bg, WidgetArt.bg(c, o, 230, 230, WidgetArt.SKY, m, skyKey, true));
        if (!m.ok) return v;
        v.setTextViewText(R.id.w_time, m.iqPhase ? sp.optString("iqsh", sp.optString("iqs", "")) : tmShort(sp));
        v.setTextViewText(R.id.w_name, m.iqPhase ? "إقامة " + nm(sp) : nm(sp));
        countdown(v, m);
        JSONArray it = m.items();
        int[] f = five(it);
        for (int j = 0; j < 5; j++) {
            JSONObject p = f[j] >= 0 ? it.optJSONObject(f[j]) : null;
            v.setTextViewText(NAME[j], nm(p));
            boolean isCur = f[j] >= 0 && f[j] == m.curIdx;
            boolean isNext = f[j] >= 0 && f[j] == m.nextIdx && !m.iqPhase;
            v.setTextColor(NAME[j], isNext ? GOLD_TXT : (isCur ? WHITE : SOFT));
            v.setInt(CELL[j], "setBackgroundResource", isCur ? R.drawable.w_cur : (isNext ? R.drawable.w_hl : R.drawable.w_none));
        }
        return v;
    }

    // ── ٤. رحلة اليوم ──
    static RemoteViews timeline(Context c, WidgetModel m, Bundle o) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_timeline);
        v.setImageViewBitmap(R.id.w_bg, WidgetArt.bg(c, o, 320, 140, WidgetArt.THEME, m, null, false));
        if (!m.ok) return v;
        JSONObject sp = shownPrayer(m);
        v.setTextViewText(R.id.w_name, (m.iqPhase ? "إقامة " : "القادمة: ") + nm(sp) + "  " + (m.iqPhase ? sp.optString("iqs", "") : tm(sp)));
        v.setTextViewText(R.id.w_cdl, label(m) + " ");
        countdown(v, m);
        JSONArray it = m.items();
        long now = System.currentTimeMillis();
        for (int i = 0; i < 6; i++) {
            JSONObject p = it != null && i < it.length() ? it.optJSONObject(i) : null;
            v.setTextViewText(NAME[i], nm(p));
            v.setTextViewText(TIME[i], tmShort(p));
            boolean isCur = i == m.curIdx, isNext = i == m.nextIdx && !m.iqPhase;
            boolean past = p != null && p.optLong("at") <= now;
            v.setImageViewResource(DOT[i], isCur ? R.drawable.w_dot_cur : (isNext ? R.drawable.w_dot_next : (past ? R.drawable.w_dot_past : R.drawable.w_dot_off)));
            v.setTextColor(NAME[i], isNext ? GOLD_TXT : (isCur ? WHITE : (past ? DIM : SOFT)));
            v.setTextColor(TIME[i], isNext ? GOLD_TXT : (past && !isCur ? DIM : WHITE));
        }
        return v;
    }

    // ── ٥. المسجد المصغر ──
    static RemoteViews mosque(Context c, WidgetModel m, Bundle o) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_mosque);
        v.setImageViewBitmap(R.id.w_bg, WidgetArt.bg(c, o, 200, 250, WidgetArt.THEME, m, null, false));
        v.setInt(R.id.w_icon, "setColorFilter", m.gold);
        v.setTextViewText(R.id.w_bell, m.muted ? "🔕" : "🔔");
        v.setOnClickPendingIntent(R.id.w_bell, mute(c));
        if (!m.ok) return v;
        JSONObject sp = shownPrayer(m);
        v.setTextViewText(R.id.w_city, m.city);
        v.setTextViewText(R.id.w_date, m.day != null ? m.day.optString("greg", "") : "");
        v.setTextViewText(R.id.w_name, m.iqPhase ? "إقامة " + nm(sp) : nm(sp));
        v.setTextViewText(R.id.w_time, m.iqPhase ? sp.optString("iqs", "") : tm(sp));
        JSONObject then = m.iqPhase ? m.next : m.after;
        v.setTextViewText(R.id.w_then, then != null ? "ثم " + nm(then) + "  " + tm(then) : "");
        return v;
    }

    // ── ٦. الزجاج الفاخر ──
    static RemoteViews glass(Context c, WidgetModel m, Bundle o) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_glass);
        v.setImageViewBitmap(R.id.w_bg, WidgetArt.bg(c, o, 220, 270, WidgetArt.GLASS, m, null, true));
        if (!m.ok) return v;
        JSONArray it = m.items();
        int[] f = five(it);
        for (int j = 0; j < 5; j++) {
            JSONObject p = f[j] >= 0 ? it.optJSONObject(f[j]) : null;
            v.setTextViewText(NAME[j], nm(p));
            v.setTextViewText(TIME[j], tm(p));
            boolean isNext = f[j] >= 0 && f[j] == m.nextIdx && !m.iqPhase;
            boolean isCur = f[j] >= 0 && f[j] == m.curIdx;
            v.setInt(CELL[j], "setBackgroundResource", isNext ? R.drawable.w_hl : (isCur ? R.drawable.w_cur : R.drawable.w_none));
            v.setTextColor(NAME[j], isNext ? GOLD_TXT : SOFT);
            v.setTextColor(TIME[j], isNext ? GOLD_TXT : WHITE);
        }
        JSONObject sp = shownPrayer(m);
        v.setTextViewText(R.id.w_cdl, (m.iqPhase ? "إقامة " + nm(sp) + " بعد " : nm(sp) + " بعد "));
        countdown(v, m);
        return v;
    }

    // ── ٧. الصلاة التالية (بسيط) ──
    static RemoteViews minimal(Context c, WidgetModel m, Bundle o) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_minimal);
        v.setImageViewBitmap(R.id.w_bg, WidgetArt.bg(c, o, 170, 170, WidgetArt.MINIMAL, m, null, false));
        if (!m.ok) return v;
        JSONObject sp = shownPrayer(m);
        v.setTextViewText(R.id.w_name, m.iqPhase ? "إقامة " + nm(sp) : nm(sp));
        v.setTextViewText(R.id.w_time, m.iqPhase ? sp.optString("iqs", "") : tm(sp));
        v.setTextViewText(R.id.w_cdl, label(m) + " ");
        countdown(v, m);
        JSONObject then = m.iqPhase ? m.next : m.after;
        v.setTextViewText(R.id.w_then, then != null ? nm(then) + "  " + tm(then) : "");
        return v;
    }
}
