package com.albaqiyat.app;

public class WMosqueWidget extends BaseWidget {
    @Override
    protected String kind() { return "mosque"; }
}
