package com.albaqiyat.app;

public class WMihrabWidget extends BaseWidget {
    @Override
    protected String kind() { return "mihrab"; }
}
