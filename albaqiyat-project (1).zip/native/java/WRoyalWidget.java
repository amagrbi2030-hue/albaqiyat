package com.albaqiyat.app;

public class WRoyalWidget extends BaseWidget {
    @Override
    protected String kind() { return "royal"; }
}
