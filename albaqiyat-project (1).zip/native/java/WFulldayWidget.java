package com.albaqiyat.app;

public class WFulldayWidget extends BaseWidget {
    @Override
    protected String kind() { return "fullday"; }
}
