package com.albaqiyat.app;

public class WDualWidget extends BaseWidget {
    @Override
    protected String kind() { return "dual"; }
}
