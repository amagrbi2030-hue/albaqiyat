package com.albaqiyat.app;

public class WSkyWidget extends BaseWidget {
    @Override
    protected String kind() { return "sky"; }
}
