package com.albaqiyat.app;

public class WNextWidget extends BaseWidget {
    @Override
    protected String kind() { return "next"; }
}
