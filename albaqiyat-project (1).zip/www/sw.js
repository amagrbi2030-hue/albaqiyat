/* الباقيات الصالحات — يحفظ التطبيق على الجهاز ليعمل دون إنترنت.
   عند تحديث index.html على الموقع غيّر رقم الإصدار هنا (v1 → v2) ليُحدَّث على الأجهزة. */
const CACHE = 'albaqiyat-v9';
const ASSETS = ['./', './manifest.webmanifest', './icon-192.png', './icon-512.png', './apple-touch-icon.png',
  './audio/adhan_m1.mp3','./audio/adhan_m2.mp3','./audio/adhan_m3.mp3','./audio/adhan_m4.mp3','./audio/adhan_m5.mp3','./audio/iqama_q1.mp3','./audio/iqama_q2.mp3','./audio/iqama_q3.mp3','./audio/iqama_q4.mp3'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys()
    .then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))
    .then(() => self.clients.claim()));
});
/* من الذاكرة أولاً (يفتح فوراً ودون إنترنت)، ثم يحدّث النسخة المحفوظة بهدوء إن توفر الاتصال */
self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET' || new URL(req.url).origin !== location.origin) return;
  const key = req.mode === 'navigate' ? './' : req;
  e.respondWith(caches.open(CACHE).then(async cache => {
    const hit = await cache.match(key, { ignoreSearch: true });
    const net = fetch(req).then(res => {
      if (res && res.ok) cache.put(key, res.clone());
      return res;
    }).catch(() => null);
    if (hit) { e.waitUntil(net); return hit; }
    return (await net) || new Response('غير متصل', { status: 503, headers: { 'Content-Type': 'text/plain; charset=utf-8' } });
  }));
});
