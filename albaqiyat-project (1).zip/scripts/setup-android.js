// يجهّز مشروع أندرويد بعد «npx cap add android»:
// 1) ينسخ أصوات الأذان والإقامة (من www/audio) إلى res/raw لتُستخدم كأصوات للإشعارات
// 2) يجعل صوت الإشعار يعمل على قناة «المنبّه» (عالٍ وواضح) بدل قناة الإشعارات المنخفضة
// 3) ينسخ أيقونة الإشعار الصغيرة
// 4) يضيف الأذونات اللازمة للتنبيهات الدقيقة والعمل بعد إعادة التشغيل والموقع
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const main = path.join(root, 'android', 'app', 'src', 'main');
if (!fs.existsSync(main)) { console.error('✗ مجلد android غير موجود. شغّل أولاً: npx cap add android'); process.exit(1); }

const raw = path.join(main, 'res', 'raw');
fs.mkdirSync(raw, { recursive: true });
const audioDir = path.join(root, 'www', 'audio');
for (const f of fs.readdirSync(audioDir)) {
  if (f.endsWith('.mp3')) fs.copyFileSync(path.join(audioDir, f), path.join(raw, f));
}

// صوت الأذان على مستوى صوت المنبّه بدل الإشعارات
const chMgr = path.join(root, 'node_modules', '@capacitor', 'local-notifications', 'android', 'src', 'main', 'java',
  'com', 'capacitorjs', 'plugins', 'localnotifications', 'NotificationChannelManager.java');
if (fs.existsSync(chMgr)) {
  let j = fs.readFileSync(chMgr, 'utf8');
  if (j.includes('AudioAttributes.USAGE_NOTIFICATION')) {
    j = j.replace(/AudioAttributes\.USAGE_NOTIFICATION\b/g, 'AudioAttributes.USAGE_ALARM');
    fs.writeFileSync(chMgr, j);
    console.log('✓ صوت الأذان يعمل الآن على مستوى صوت المنبّه');
  }
} else {
  console.warn('! لم يُعثر على ملف قنوات الإشعارات — سيبقى الصوت على مستوى الإشعارات');
}
// تنبيه صوتي رجالي قبل الأذان بعشر دقائق: «اقتربت الصلاة، الرجاء الاستعداد»
// يُولَّد مرة واحدة أثناء البناء (يحتاج إنترنت خادم البناء فقط)، وإن تعذّر يستخدم الهاتف محرك النطق العربي.
const voiceSrc = path.join(root, 'www', 'audio', 'pre_voice.mp3');
const voiceOut = path.join(raw, 'pre_voice.mp3');
if (fs.existsSync(voiceSrc)) fs.copyFileSync(voiceSrc, voiceOut);
else {
  try {
    const { execSync } = require('child_process');
    execSync('python3 -m pip install -q --user --break-system-packages edge-tts', { stdio: 'inherit', timeout: 180000 });
    execSync(`python3 -m edge_tts --voice ar-SA-HamedNeural --rate=-8% --text "اقتربت الصلاة، الرجاء الاستعداد" --write-media "${voiceOut}"`, { stdio: 'inherit', timeout: 90000 });
    if (!fs.existsSync(voiceOut) || fs.statSync(voiceOut).size < 2000) throw new Error('empty');
    console.log('✓ تم توليد التنبيه الصوتي الرجالي');
  } catch (e) {
    try { fs.unlinkSync(voiceOut); } catch (_) {}
    console.warn('! تعذّر توليد التنبيه الصوتي، سيُستخدم محرك النطق في الهاتف');
  }
}

// يمنع أداة تقليص الموارد من حذف الأصوات لأنها لا تُستدعى من الكود مباشرة
fs.writeFileSync(path.join(raw, 'keep.xml'),
  '<?xml version="1.0" encoding="utf-8"?>\n<resources xmlns:tools="http://schemas.android.com/tools" tools:keep="@raw/*" />\n');

const drw = path.join(main, 'res', 'drawable');
fs.mkdirSync(drw, { recursive: true });
fs.copyFileSync(path.join(root, 'res', 'drawable', 'ic_stat_salah.xml'), path.join(drw, 'ic_stat_salah.xml'));

// ── الكود الأصلي: شاشة الأذان الكاملة، تشغيل الصوت، الودجت، الجدولة ──
function copyDir(src, dst) {
  if (!fs.existsSync(src)) return;
  fs.mkdirSync(dst, { recursive: true });
  for (const f of fs.readdirSync(src)) {
    const a = path.join(src, f), b = path.join(dst, f);
    if (fs.statSync(a).isDirectory()) copyDir(a, b); else fs.copyFileSync(a, b);
  }
}
const javaDir = path.join(main, 'java', 'com', 'albaqiyat', 'app');
fs.mkdirSync(javaDir, { recursive: true });
copyDir(path.join(root, 'native', 'java'), javaDir);
copyDir(path.join(root, 'native', 'res'), path.join(main, 'res'));
// صور شاشة الأذان لكل صلاة (اختيارية): images/fajr.jpg … isha.jpg
const imgDir = path.join(root, 'images');
if (fs.existsSync(imgDir)) {
  const nodpi = path.join(main, 'res', 'drawable-nodpi');
  fs.mkdirSync(nodpi, { recursive: true });
  for (const f of fs.readdirSync(imgDir)) {
    // fajr.jpg = الصورة كاملة، fajr_bg.jpg = خلفية ضبابية من نفس الصورة
    const m = f.toLowerCase().match(/^(fajr|dhuhr|asr|maghrib|isha)(_bg)?\.(jpe?g|png|webp)$/);
    if (m) fs.copyFileSync(path.join(imgDir, f), path.join(nodpi, (m[2] ? 'bg_' : 'photo_') + m[1] + '.' + (m[3] === 'jpeg' ? 'jpg' : m[3])));
  }
}

const mf = path.join(main, 'AndroidManifest.xml');
let xml = fs.readFileSync(mf, 'utf8');
const perms = [
  'android.permission.POST_NOTIFICATIONS',
  'android.permission.SCHEDULE_EXACT_ALARM',
  'android.permission.USE_EXACT_ALARM',
  'android.permission.RECEIVE_BOOT_COMPLETED',
  'android.permission.WAKE_LOCK',
  'android.permission.VIBRATE',
  'android.permission.ACCESS_COARSE_LOCATION',
  'android.permission.ACCESS_FINE_LOCATION',
  'android.permission.FOREGROUND_SERVICE',
  'android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK',
  'android.permission.USE_FULL_SCREEN_INTENT',
  'android.permission.SYSTEM_ALERT_WINDOW',
  'android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS'
];
const add = perms.filter(p => !xml.includes(`"${p}"`)).map(p => `    <uses-permission android:name="${p}" />`).join('\n');
if (add) xml = xml.replace(/<\/manifest>\s*$/, `${add}\n</manifest>\n`);
const comps = `
        <receiver android:name=".AdhanReceiver" android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED" />
                <action android:name="android.intent.action.MY_PACKAGE_REPLACED" />
                <action android:name="android.intent.action.TIME_SET" />
                <action android:name="android.intent.action.TIMEZONE_CHANGED" />
            </intent-filter>
        </receiver>
        <receiver android:name=".PrayerWidget" android:exported="true" android:label="@string/adhan_widget_name">
            <intent-filter>
                <action android:name="android.appwidget.action.APPWIDGET_UPDATE" />
            </intent-filter>
            <meta-data android:name="android.appwidget.provider" android:resource="@xml/prayer_widget_info" />
        </receiver>
        <receiver android:name=".WNextWidget" android:exported="true" android:label="@string/w_next_name">
            <intent-filter>
                <action android:name="android.appwidget.action.APPWIDGET_UPDATE" />
            </intent-filter>
            <meta-data android:name="android.appwidget.provider" android:resource="@xml/w_next_info" />
        </receiver>
        <receiver android:name=".WCrescentWidget" android:exported="true" android:label="@string/w_crescent_name">
            <intent-filter>
                <action android:name="android.appwidget.action.APPWIDGET_UPDATE" />
            </intent-filter>
            <meta-data android:name="android.appwidget.provider" android:resource="@xml/w_crescent_info" />
        </receiver>
        <receiver android:name=".WTimelineWidget" android:exported="true" android:label="@string/w_timeline_name">
            <intent-filter>
                <action android:name="android.appwidget.action.APPWIDGET_UPDATE" />
            </intent-filter>
            <meta-data android:name="android.appwidget.provider" android:resource="@xml/w_timeline_info" />
        </receiver>
        <receiver android:name=".WMosqueWidget" android:exported="true" android:label="@string/w_mosque_name">
            <intent-filter>
                <action android:name="android.appwidget.action.APPWIDGET_UPDATE" />
            </intent-filter>
            <meta-data android:name="android.appwidget.provider" android:resource="@xml/w_mosque_info" />
        </receiver>
        <receiver android:name=".WGlassWidget" android:exported="true" android:label="@string/w_glass_name">
            <intent-filter>
                <action android:name="android.appwidget.action.APPWIDGET_UPDATE" />
            </intent-filter>
            <meta-data android:name="android.appwidget.provider" android:resource="@xml/w_glass_info" />
        </receiver>
        <receiver android:name=".WMinimalWidget" android:exported="true" android:label="@string/w_minimal_name">
            <intent-filter>
                <action android:name="android.appwidget.action.APPWIDGET_UPDATE" />
            </intent-filter>
            <meta-data android:name="android.appwidget.provider" android:resource="@xml/w_minimal_info" />
        </receiver>
        <service android:name=".AdhanService" android:exported="false" android:foregroundServiceType="mediaPlayback" />
        <activity android:name=".AdhanActivity" android:exported="false"
            android:showWhenLocked="true" android:turnScreenOn="true"
            android:excludeFromRecents="true" android:launchMode="singleTop"
            android:taskAffinity="com.albaqiyat.app.adhan"
            android:theme="@android:style/Theme.Black.NoTitleBar.Fullscreen" />
`;
if (!xml.includes('.AdhanService')) xml = xml.replace(/<\/application>/, comps + '    </application>');
fs.writeFileSync(mf, xml);
console.log('✓ تم تجهيز مشروع أندرويد: الأصوات والأيقونة والأذونات وشاشة الأذان والودجت');
